﻿var currentFormUniqueId;
var currentFormWebPartId;
var currentLocation = window.location.href;
var formURL;// = "/sites/wpcb/mswpo/SiteAssets/MSWPO/CDSS/Level3/PrimaryStation/PSLevel3CDSSForm.html";

(function () {
    // jQuery library is required in this sample 
    document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/JQuery/jquery-1.11.0.min.js"><\/script>');
    document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/JQuery/jquery-ui.js"> </script>');
                                
    document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/JQuery/jquery.loading-indicator.min.js"> </script>');
    document.write('<link href="/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/JQuery/jquery.loading-indicator.css" type="text/css" rel="stylesheet" />');
    //Populate the tab-3 of the Competencies section of the CDSS Form
   // document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/CDSS/Level3/Shared/Level3CDSSPreRender.js"> </script>');

    if (document.location.href.indexOf('Primary')) {
        console.log('get value from here');
        formURL = '/sites/wpcb/mswpo/SiteAssets/MSWPO/CDSS/Level3/PrimaryStation/PSLevel3CDSSForm.html';
    }


    function _registerAccordionViewTemplate() {
        // Create object that have the context information about the field that we want to change it's output render  
        var cdssFormContext = {};
        cdssFormContext.Templates = {};

        // Add OnPostRender event handler to add accordion click events and style 

        cdssFormContext.OnPreRender = CDSSFormOnPreRender;
        cdssFormContext.OnPostRender = CDSSFormOnPostRender;

        SPClientTemplates.TemplateManager.RegisterTemplateOverrides(cdssFormContext);
    }
    function CDSSFormOnPreRender(ctx) {
        if (!currentFormUniqueId) {
            //Get the current form Unique ID
            currentFormUniqueId = ctx.FormUniqueId;

            //Get the Current from WebPart Id
            currentFormWebPartId = "WebPart" + ctx.FormUniqueId;

            jQuery(document).ready(function () {
                //Add the new HTML created for accordion at the top of the web part
                $.get(formURL, function (data, status) {
                    jQuery("#" + currentFormWebPartId).prepend(data);
                });
            });
        }
    }
    function CDSSFormOnPostRender(ctx) {

    }
    ExecuteOrDelayUntilScriptLoaded(_registerAccordionViewTemplate, 'clienttemplates.js');
})();

