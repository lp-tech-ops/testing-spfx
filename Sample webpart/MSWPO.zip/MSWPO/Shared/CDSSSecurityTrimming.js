﻿var MSWPOAccessManagementList = "B441CA50-2EFB-425F-BF1B-E66EE18806B0"; //MSWPO Access Management Configuration
var operatorLookUpList = "F032B017-5260-492F-B72A-1A7E7FC31A23"; //Operator LookUp List

//Operators by Shift.
SP.SOD.executeFunc('sp.js', 'SP.ClientContext', GetCurrentUserRole);

//Get the current role of the logged in User
function GetCurrentUserRole() {
    var currentUserTitle = '';
    var currentUserRole = '';
    //Get the current user and get his title: i.e. First Name Last Name
    var fetchCurrentUser = GetCurrentUserInfo();
    fetchCurrentUser.done(function (result) {
        var returnedValue = result;
        //Get Current User Title
        currentUserTitle = returnedValue[1];
        //Call the actual method that retrieve the User Role
        var fetchCurrentRole = RetrieveCurrentUserRoleInfo(currentUserTitle);
        fetchCurrentRole.done(function (result) {
            var returnedRole = result;
            debugger;
            switch (returnedRole) {
                case 'Operator': //Deny Access
                    var operatorName = $("input[title='Employee Name Required Field']").val();
                    if (operatorName != currentUserTitle) {
                        fnAccessDeniedMessage('You do not have access to view this information.', 'Error:', 490, 125);
                    }
                    else {
                        var edit = document.getElementById("Ribbon.ListForm.Edit.Commit.Publish-Large");
                        edit.style.display = "none";
                        $("input[value$='Save']").attr('disabled', true);
                    }
                    break;
                case 'Supervisors': //Has access
                    var supervisorSignOffDate = $('input[Title="Sign Off by Supervisor Date"]').val();

                    if (!supervisorSignOffDate) {
                        $("#notifyOPSManager").show();
                        $("#certifyOperator").hide();
                        $("input[title='Sign Off by Supervisor']").prop('disabled', false);
                        $("input[title='Sign Off by Supervisor Date']").prop('disabled', false);
                        $("input[title='Sign Off by Supervisor Date']").parent().next().closest('td').find("img:first").css('display', 'block');

                        $("input[title='Sign Off by Operations Manager']").prop('disabled', true);
                        $("input[title='Sign Off by Operations Manager Date']").prop('disabled', true);
                        $("input[title='Sign Off by Operations Manager Date']").parent().next().closest('td').find("img:first").css('display', 'none');
                    }
                    break;
                case 'MSWPOAdmin': //Has access
                    $("#notifyOPSManager").hide();
                    $("#certifyOperator").hide();
                    $("input[title='Sign Off by Supervisor']").prop('disabled', true);
                    $("input[title='Sign Off by Supervisor Date']").prop('disabled', true);
                    $("input[title='Sign Off by Supervisor Date']").parent().next().closest('td').find("img:first").css('display', 'none');

                    $("input[title='Sign Off by Operations Manager']").prop('disabled', true);
                    $("input[title='Sign Off by Operations Manager Date']").prop('disabled', true);
                    $("input[title='Sign Off by Operations Manager Date']").parent().next().closest('td').find("img:first").css('display', 'none');
                    break;
                case 'Trainer': //Deny Access
                    fnAccessDeniedMessage('You do not have access to view this information.', 'Error:', 490, 125);
                    break;
                case 'Management': //Has access
                    var OPSMgrSignedOffDate = $("input[title='Sign Off by Operations Manager Date']").val();

                    if (!OPSMgrSignedOffDate) {
                        $("#notifyOPSManager").hide();
                        $("#certifyOperator").show();
                        //Disable operator certification sign off
                        $("input[title='Sign Off by Supervisor']").prop('disabled', true);
                        $("input[title='Sign Off by Supervisor Date']").prop('disabled', true);
                        $("input[title='Sign Off by Supervisor Date']").parent().next().closest('td').find("img:first").css('display', 'block');

                        $("input[title='Sign Off by Operations Manager']").prop('disabled', false);
                        $("input[title='Sign Off by Operations Manager Date']").prop('disabled', false);
                        $("input[title='Sign Off by Operations Manager Date']").parent().next().closest('td').find("img:first").css('display', 'block');
                    }
                    break;
                case 'Trainer-Operator'://Deny Access
                    var operatorName = $("input[title='Employee Name Required Field']").val();
                    if (operatorName != currentUserTitle) {
                        fnAccessDeniedMessage('You do not have access to view this information.', 'Error:', 490, 125);
                    }
                   // fnAccessDeniedMessage('You do not have access to view this information.', 'Error:', 490, 125);
                    break;
                case 'Visitor'://Deny Access
                    fnAccessDeniedMessage('You do not have access to view this information.', 'Error:', 490, 125);
                    break;
                default:
                    break;
            }
        });
        fetchCurrentRole.fail(function (result) {
            var error = result;
            console.log(error);
        });

    });
    fetchCurrentUser.fail(function (result) {
        var error = result;
        console.log(error);
    });
}

//This methods fetches current user email and title
function GetCurrentUserInfo() {

    var d = $.Deferred();
    var context = new SP.ClientContext.get_current();
    var web = context.get_web();
    var currentUser = web.get_currentUser();
    currentUser.retrieve();
    context.load(web);

    var o = { d: d, web: web };
    context.executeQueryAsync(Function.createDelegate(o, onQuerySucceeded), Function.createDelegate(o, onQueryFailed));

    return d.promise();

    function onQuerySucceeded(sender, args) {
        var returnArray = [];

        var currentUser = this.web.get_currentUser();
        var email = currentUser.get_email();
        var Title = currentUser.get_title();
        returnArray[0] = email;
        returnArray[1] = Title;

        //var id = currentUser.get_id();
        //var loginName = currentUser.get_loginName();

        //Construch the array to be returned.
        this.d.resolve(returnArray);

        console.log('Email is ' + email);
        console.log('Title is ' + Title);
    }
    function onQueryFailed(sender, args) {
        alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}

//Method that returns actual role of the logged in user.
function RetrieveCurrentUserRoleInfo(currentUserTitle) {

    var d1 = $.Deferred();

    //Following are basic sharepoint JSOM Operations and are self-explanatory
    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web().get_lists().getById(MSWPOAccessManagementList); // Call Operator Certification and Employee Data
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml();

    var currentUserRoleInfo = oList.getItems(camlQuery);
    clientContext.load(currentUserRoleInfo);

    var o = { d1: d1, currentUserRoleInfo: currentUserRoleInfo, currentUserTitle: currentUserTitle };
    clientContext.executeQueryAsync(Function.createDelegate(o, onretrieveOperatorInfoQuerySucceeded), Function.createDelegate(o, onretrieveOperatorInfoQueryFailed));

    return d1.promise();

    function onretrieveOperatorInfoQuerySucceeded() {

        var totalGroupRoleInfoCount = this.currentUserRoleInfo.get_count();

        var resolvedGroupName = '';

        if (totalGroupRoleInfoCount == 0) {
            console.log("Something went wrong, could not fetch group and role info.");
        } else {
            console.log("Fetched Group and Role info.");
            var totalGroupRoleInfoItemEnumerator = currentUserRoleInfo.getEnumerator();
            while (totalGroupRoleInfoItemEnumerator.moveNext()) {
                var oListItem = totalGroupRoleInfoItemEnumerator.get_current();
                var members = oListItem.get_item('Group_x0020_Members');
                var groupName = oListItem.get_item('Title');
                if (!!members) {
                    console.log(members);
                    if (members.length > 0) {
                        for (var i = 0; i < members.length; i++) {
                            var title = members[i].get_lookupValue();
                            if (title == this.currentUserTitle) {
                                if (resolvedGroupName == "Supervisors") {
                                    break;
                                }
                                resolvedGroupName = groupName;
                            }
                        }
                    }
                }
            }
            //Prepare to return on success.
            if (resolvedGroupName) { // user found in one of the roles
                if (resolvedGroupName == 'Trainer') {
                    //Check if the Trainer is also an operator
                    var checkOperatorFetchValue = CheckIfOperator(currentUserTitle);
                    checkOperatorFetchValue.done(function (result) {
                        var returnedValue = result;
                        if (returnedValue == 'true') { //recognized as operator
                            d1.resolve('Trainer-Operator');
                        }
                        else {
                            d1.resolve('Trainer');
                        }
                    });
                    checkOperatorFetchValue.fail(function (result) {
                        var error = result;
                        console.log(error);
                    });
                }
                else {
                    //All groups except for Trainer
                    d1.resolve(resolvedGroupName);
                }
            }
            else { //Check if the logged in user is operator
                var checkOperatorFetchValue = CheckIfOperator(currentUserTitle);

                checkOperatorFetchValue.done(function (result) {
                    var returnedValue = result;

                    if (returnedValue == 'true') { //recognized as operator
                        d1.resolve('Operator');
                    }
                    else {
                        d1.resolve('Visitor');
                    }

                });
                checkOperatorFetchValue.fail(function (result) {
                    var error = result;
                    console.log(error);
                });
            }
        }
    }
    function onretrieveOperatorInfoQueryFailed() {
        console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}

function CheckIfOperator(currentUserTitle) {

    var d = $.Deferred();
    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web().get_lists().getById(operatorLookUpList);

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(
        '<View><Query> <Where> <Eq> <FieldRef Name=\'Operator_x0020_Name\' \/> <Value Type=\'Text\'>' + currentUserTitle + '<\/Value> <\/Eq> <\/Where> <\/Query></View>'
    );
    var currentUserInfo = oList.getItems(camlQuery);
    clientContext.load(currentUserInfo);

    var o = { d: d, currentUserInfo: currentUserInfo, currentUserTitle: currentUserTitle };
    clientContext.executeQueryAsync(Function.createDelegate(o, onretrieveOperatorInfoQuerySucceeded), Function.createDelegate(o, onretrieveOperatorInfoQueryFailed));

    return d.promise();

    function onretrieveOperatorInfoQuerySucceeded() {
        var totalResultCount = currentUserInfo.get_count();
        if (totalResultCount == 0) {
            console.log("User found in Operator Certification and Employee Data");
            d.resolve('false');
        } else {
            console.log("User found in Operator Certification and Employee Data");
            d.resolve('true');
        }
    }
    function onretrieveOperatorInfoQueryFailed() {
        console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}

function fnAccessDeniedMessage(messageBoxHTML, messagetitle, width, height) {
    $("#wrapper").css('display', 'none');
    $("#h1Title").css('display', 'none');
    $('.expandCollpase').css('display', 'none');
    $("#dialog-message").html(messageBoxHTML);
    $("#dialog-message").dialog({
        modal: true,
        title: messagetitle,
        width: '600px',
        dialogClass: 'main-dialog-class',
        buttons: {
            Ok: function () {
                $(this).dialog("close");
                window.location.href = "/sites/wpcb/mswpo/SitePages/MSWPOLandingPage.aspx";
            }
        }
    });
}
