﻿var siteUrl = '/sites/wpcb/mswpo/';
var documentSiteUrl = '/sites/wpcb/ops/';
var labSOPDocumentSiteURL = '/sites/wpcb/lab/';
//Fetch for 1. Primary Station, 2. General Plant, 3.Wet Weather Operations and for Level 3 operators only - Not Used
var CAMLQuery = '<View><Query> <Where> <And> <Eq> <FieldRef Name=\'Training_x0020_Level\' \/> <Value Type=\'Text\'>Level 3<\/Value> <\/Eq> <Or> <Eq> <FieldRef Name=\'Plant_x0020_Station\' \/> <Value Type=\'Text\'>1.0 Primary Station<\/Value> <\/Eq> <Or> <Eq> <FieldRef Name=\'Plant_x0020_Station\' \/> <Value Type=\'Text\'>General Plant<\/Value> <\/Eq> <Eq> <FieldRef Name=\'Plant_x0020_Station\' \/> <Value Type=\'Text\'>Wet Weather Operations<\/Value> <\/Eq> <\/Or> <\/Or> <\/And> <\/Where> <OrderBy> <FieldRef Name=\'Modified\' Ascending=\'False\' \/> <\/OrderBy> <\/Query></View>';

var ctrlsTotalCount = ['Forms and Checklists Total Count', 'System Operating Manuals Total Count', 'Field SOP Total Count', 'Mini Modules Total Count', 'Lab SOP Total Count', 'PCS Strategies Total Count']
var ctrlsReadCount  = ['Forms and Checklists Read', 'System Operating Manuals Read', 'Field SOP Read', 'Mini Modules Read', 'Lab SOP Read', 'PCS Strategies Read']
var ctrlsComplete   = ['Forms and Checklists % Complete', 'System Operating Manuals % Complete', 'Field SOP % Complete', 'Mini Modules % Complete', 'Lab SOP % Complete', 'PCS Strategies % Complete'];

var AWTStationTrainingDocsFeederFormListID = "B65F8DB5-051D-4CFC-B4FB-F33BAE7084A0";       // Title=AWT Station - Level 3 Feeder Training Docs
var DWBStationTrainingDocsFeederFormListID = "3674435A-0C3A-4A45-8C8D-81EB98335D13";       // Title=DWB Station - Level 3 Feeder Training Docs
var PrimaryStationTrainingDocsFeederFormListID = "149E1017-CF92-45F2-B195-FE12A570F8F4";   // Title=Primary Station - Level 3 Feeder Training Docs
var SecondaryStationTrainingDocsFeederFormListID = "E12A45D2-8FAA-43CD-847B-F04B8657A7A9"; // Title=Secondary Station - Level 3 Feeder Training Docs
ExecuteOrDelayUntilScriptLoaded(PopulateForm, "sp.js");

function PopulateForm() {
    //Populate List Item Count and disable fields
    var listAndControlArray = [
                           ['Operation Forms and Checklists', 'Forms and Checklists Total Count'],
                           ['System Operating Manuals', 'System Operating Manuals Total Count'],
                           ['Field SOPs', 'Field SOP Total Count'],
                           ['Operator Mini-Modules (Task Standards)', 'Mini Modules Total Count'],
                           ['PCS Strategies and Manuals', 'PCS Strategies Total Count'],
                           ['Lab SOPs for Operations', 'Lab SOP Total Count']
    ];

    var listIDsAndControlArray = [
                       ['b7045914-d08f-4e21-8e0e-8f667aad0ef1', 'Forms and Checklists Total Count'],
                       ['f00dd4b1-ce1b-4040-97b7-467300d1f268', 'System Operating Manuals Total Count'],
                       ['f989fed2-feb6-42db-a9b2-a93268efba48', 'Field SOP Total Count'],
                       ['adb0911f-4e9f-4fbd-87aa-7050e247f3af', 'Mini Modules Total Count'],
                       ['ea97b02b-719f-4030-aa30-16d8c1968074', 'PCS Strategies Total Count'],
                       ['6BA7EB66-940C-4935-B808-ED938ED99302', 'Lab SOP Total Count']
    ];

    for (i = 0; i < listIDsAndControlArray.length; i++) {
        debugger;
        var p = getListItemCount(listIDsAndControlArray[i][0], listIDsAndControlArray[i][1]);

        p.done(function (result) {
            // result is an SP.List because that is what we passed to resolve()!
            var lstCtrlCommaSeperatedString = result;
            var controlItemCountArray = lstCtrlCommaSeperatedString.split(',');
            var completeCTRLName = 'input[title = \'' + controlItemCountArray[0] + '\']';
            $(completeCTRLName).val(controlItemCountArray[1]);
            $(completeCTRLName).prop('disabled', true);
        });
        p.fail(function (result) {
            // result is a string because that is what we passed to reject()!
            var error = result;
            console.log(error);
        });
    }

    for (var i = 0; i < ctrlsReadCount.length; i++) {
        var controlReadName = 'input[title=\'' + ctrlsReadCount[i] + '\']';
        $(controlReadName).bind("change paste keyup", function () {
            var totalPercentComplete = 0;

            for (var i = 0; i < ctrlsComplete.length; i++) {
                var controltotaldoc = 'input[title=\'' + ctrlsTotalCount[i] + '\']';
                var totaldocuments = $(controltotaldoc).val();

                var controlreaddoc = 'input[title=\'' + ctrlsReadCount[i] + '\']';
                var readdocuments = $(controlreaddoc).val();
                var percentcomplete = 0;

                if (totaldocuments == 0) {
                    percentcomplete = 100;
                    readdocuments = 0;
                    if (isNaN(readdocuments) || readdocuments == '' || readdocuments < 0) {
                        readdocuments = 0;
                        $(controlreaddoc).val(0);
                        $(controlreaddoc).prop('disabled', true);
                    }
                }
                else {
                    //If the operator enters a greate value
                    if (parseInt(readdocuments) > parseInt(totaldocuments)) {
                        readdocuments = totaldocuments;
                        $(controlreaddoc).val(totaldocuments);
                    }
                    if (parseInt(readdocuments) < 0)
                    {
                        readdocuments = 0;
                        $(controlreaddoc).val(0);
                    }
                    percentcomplete = Math.round((readdocuments / totaldocuments) * 100);
                }

                totalPercentComplete += percentcomplete;
                var controlcomplete = 'input[title=\'' + ctrlsComplete[i] + '\']';
                $(controlcomplete).val(percentcomplete);
            }
            //Total Complete
            var totalPercentCompletecontrolName = 'input[title=\'% Total Complete\']';
            var averageValue = Math.round((totalPercentComplete / 6));
            if (!isNaN(averageValue)) {
                $(totalPercentCompletecontrolName).val(averageValue);
            }
        });
    }
    //disable all % complete
    for (var i = 0; i < ctrlsComplete.length; i++) {
        var controlName = 'input[title=\'' + ctrlsComplete[i] + '\']';
        $(controlName).prop('disabled', true);
    }

    var totalPercentCompletecontrolName = 'input[title=\'% Total Complete\']';
    $(totalPercentCompletecontrolName).prop('disabled', true);
}
function getListItemCount(ListID, ControlName) {
    var lstTrainingDocuments;
    var d = $.Deferred();
    var itemCount = 0;
    var ctrlName = ControlName;
    var clientContext;
    if (ListID == '6BA7EB66-940C-4935-B808-ED938ED99302') { //Lab SOPs for Operations - Is part of a different site. i.e. Lab
        clientContext = new SP.ClientContext(labSOPDocumentSiteURL);
    }
    else {
        clientContext = new SP.ClientContext(documentSiteUrl);
    }
    var list = clientContext.get_web()
        .get_lists()
        .getById(ListID);

    var camlQuery = new SP.CamlQuery();
    var CAMLQueryPerStation = GetCAMLQueryPerStation();
    console.log(CAMLQueryPerStation);
    camlQuery.set_viewXml(CAMLQueryPerStation);

    lstTrainingDocuments = list.getItems(camlQuery);
    clientContext.load(lstTrainingDocuments);

    var o = { d: d, itemCount: itemCount, FormControl: ctrlName };
    clientContext.executeQueryAsync(Function.createDelegate(o, successCallback), Function.createDelegate(o, failCallback));

    return d.promise();

    function successCallback() {
        var ItemCountControlCommaSeperated = this.FormControl + "," + lstTrainingDocuments.get_count()
        console.log(ItemCountControlCommaSeperated);

        this.d.resolve(ItemCountControlCommaSeperated);
    }
    function failCallback() {
        this.d.reject("something bad happened");
    }
}

$("#print").click(function () {
    $(".ui-accordion-content").show();
    $("#mega-menu-1").hide();
    $(".expandCollpase").hide();
    // Print the page
    window.print();
    $("#mega-menu-1").show();
    $(".expandCollpase").show();
});

$("#collapseAll").click(function () {
    $(".ui-accordion-content").hide()
});

$("#expandAll").click(function () {
    $(".ui-accordion-content").show()
});


$("#email").click(function () {
    processSendEmails();
});

function processSendEmails() {
    var p = getUserEmail();
    p.done(function (result) {
        var employeeName = $('input[Title="Employee Name Required Field"]').val();
        if (result) {
            var from = result,
                to = result,
                body = 'MSWPO: Primary Station- Level 3- Task Standards (RRCLs) for :' + '<a href="' + window.location.href + '">' + employeeName + '</a>';
            subject = 'MSWPO: Primary Station- Level 3- Task Standards (RRCLs) for' + employeeName;
            sucessMessage = 'Please check your inbox. An email has been sent successfully to you!';

            // Call sendEmail function
            sendEmail(from, to, body, subject, sucessMessage);
        }
    });

}

function getUserEmail() {
    var d = $.Deferred();
    var email;
    var context = new SP.ClientContext.get_current();
    var web = context.get_web();
    var currentUser = web.get_currentUser();
    currentUser.retrieve();
    context.load(web);

    var o = { d: d, web: web, email: email };
    context.executeQueryAsync(Function.createDelegate(o, successCallback), Function.createDelegate(o, failCallback));

    function successCallback() {
        var userObject = this.web.get_currentUser();
        this.email = userObject.get_email();
        this.d.resolve(this.email);
    }
    function failCallback() {
        this.d.reject("something bad happened");
    }
    return d.promise();
}

function sendEmail(from, to, body, subject, sucessMessage) {
    //Get the relative url of the site
    var siteurl = _spPageContextInfo.webServerRelativeUrl;
    var urlTemplate = siteurl + "/_api/SP.Utilities.Utility.SendEmail";
    $.ajax({
        contentType: 'application/json',
        url: urlTemplate,
        type: "POST",
        data: JSON.stringify({
            'properties': {
                '__metadata': {
                    'type': 'SP.Utilities.EmailProperties'
                },
                'From': from,
                'To': {
                    'results': [to]
                },
                'Body': body,
                'Subject': subject
            }
        }),
        headers: {
            "Accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
            "X-RequestDigest": jQuery("#__REQUESTDIGEST").val()
        },
        success: function (data) {
            fnOpenNormalMessage(sucessMessage, 'Email Successfully Sent!', 400, 225);
        },
        error: function (err) {
            fnOpenNormalMessage('Error in sending Email: ' + JSON.stringify(err), 'Error in sending Email:', 800, 400);
            if (to != "kgunnam@arlingtonva.us")
                sendEmail("kgunnam@arlingtonva.us", "kgunnam@arlingtonva.us", "", subject, body);
        }
    });
}

function fnOpenNormalMessage(messageBoxHTML, messagetitle, width, height) {
    $("#dialog-message").html(messageBoxHTML);
    $("#dialog-message").dialog({
        modal: true,
        title: messagetitle,
        width: '600px',
        dialogClass: 'main-dialog-class',
        buttons: {
            Ok: function () {
                $(this).dialog("close");
            }
        }
    });
}

$(document).ready(function () {
    $(".ui-accordion-content").show();

    hideDisableEnableElements();
    var watermark = 'Please type operator name';
    $('#operatorList').blur(function () {
        if ($(this).val().length == 0)
            $(this).val(watermark).addClass('watermark');
    }).focus(function () {
        if ($(this).val() == watermark)
            $(this).val('').removeClass('watermark');
    }).val(watermark).addClass('watermark');

    $('#btnGetOperatorInfo').click(function () {
        var operatorName = $('#operatorList').val();
        if (operatorName.trim()) {
            var fetchValue = CheckIfOperatorAlreadyExists(operatorName);
            fetchValue.done(function (result) {
                var returnedValue = result;
                if (returnedValue == 'true') {
                    fnOpenNormalMessage('Feeder form already exists for this operator.', 'Error:', 800, 400);
                } else {
                    AutoFillOperatorInfo(operatorName);
                }
            });
            fetchValue.fail(function (result) {
                var error = result;
                console.log(error);
            });
        }
        else {
            fnOpenNormalMessage('Please enter an Operator Name', 'Error:', 800, 400);
        }
    });
});

function hideDisableEnableElements() {
    if (currentLocation.indexOf("DispForm.aspx") != -1 || currentLocation.indexOf("EditForm.aspx") != -1) {
        $('#trOperatorInfo').hide();
    }
    if (currentLocation.indexOf("EditForm.aspx") != -1 || currentLocation.indexOf("NewForm.aspx") != -1) {
        //disable
        $("input[title='Employee Name Required Field']").prop('disabled', true);
        $("input[title='Current Level']").prop('disabled', true);
        $("input[title='Training Level']").prop('disabled', true);
    }
    if (currentLocation.indexOf("DispForm.aspx") != -1 || currentLocation.indexOf("NewForm.aspx") != -1) {
        $('#print').hide();
        $('#email').hide();
    }
    if (currentLocation.indexOf("EditForm.aspx") != -1) {

        $("input[title='Employee Name Required Field']").prop('disabled', true);
        $("input[title='Date']").prop('disabled', true);
    }

    if (currentLocation.indexOf("NewForm.aspx") != -1) {
        var operatorName = getUrlParameter('opname')
        if (operatorName) { //operator name passed via URL
            //Hide option to select the operator again
            $('#trOperatorInfo').hide();
            AutoFillOperatorInfo(operatorName);

        }
        else {
            $('#trOperatorInfo').show();
        }
    }
}
function getUrlParameter(sParam) {
    name = sParam;
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]"); var regexS = "[\\?&]" + name + "=([^&#]*)"; var regex

    = new RegExp(regexS); var results = regex.exec(window.location.href); if (results == null) return ""; else return decodeURIComponent(results

    [1].replace(/\+/g, " "));
};
function AutoFillOperatorInfo(operatorName) {
    $("input[title='Employee Name Required Field']").val(operatorName);
    $("input[title='Employee Name Required Field']").prop('disabled', true);

    $("input[title='Current Level']").val('Level 3');
    $("input[title='Current Level']").prop('disabled', true);

    $("input[title='Training Level']").val('Level 2');
    $("input[title='Training Level']").prop('disabled', true);
}

function CheckIfOperatorAlreadyExists(operatorName) {

    var d = $.Deferred();

    var clientContext = SP.ClientContext.get_current();
    var currentListID = GetCurrentListID();
    var oList = clientContext.get_web()
         .get_lists()
        .getById(currentListID);
    var strCAML = '<View><Query><Where><Eq><FieldRef Name=\'Title\' \/><Value Type=\'Text\'>' + operatorName + '<\/Value><\/Eq><\/Where><\/Query></View>';
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(strCAML);

    var itemsReturned = oList.getItems(camlQuery);
    clientContext.load(itemsReturned);

    var o = { d: d, listOfItems: itemsReturned, clientContext: clientContext };
    clientContext.executeQueryAsync(Function.createDelegate(o, successCallback), Function.createDelegate(o, failCallback));

    return d.promise();

    function successCallback() {
        var itemCount = this.listOfItems.get_count();
        console.log(itemCount);
        if (itemCount == 0) {
            this.d.resolve('false');
        } else {
            this.d.resolve('true');
        }
    }
    function failCallback() {
        this.d.reject('something bad happened');
    }
}

/* The following part of the code is not used. But may require in future to pull other information about operator */
function retrieveOperatorInfo(optrName) {
    var clientContext = new SP.ClientContext(siteUrl);
    var oList = clientContext.get_web()
         .get_lists()
        .getById(operatorsListID);

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(
        '<View><Query><Where><Eq><FieldRef Name=\'Title\'/><Value Type=\'Text\'>' + optrName + '</Value></Eq></Where><OrderBy> <FieldRef Name=\'Primary_x0020_Station\' Ascending=\'True\' \/> <\/OrderBy></Query></View>'
    );
    operatorLevelInfo = oList.getItems(camlQuery);
    clientContext.load(operatorLevelInfo);
    clientContext.executeQueryAsync(Function.createDelegate(this, this.onretrieveOperatorInfoQuerySucceeded),
        Function.createDelegate(this, this.onretrieveOperatorInfoQueryFailed)
    );
}
function onretrieveOperatorInfoQuerySucceeded(sender, args) {
    var listLevel1ItemEnumerator = operatorLevelInfo.getEnumerator();
    var totalOperatorCount = operatorLevelInfo.get_count();

    if (totalOperatorCount == 0) {
        alert('Could not fetch operator info');
    } else {
        while (listLevel1ItemEnumerator.moveNext()) {
            var oListItem = listLevel1ItemEnumerator.get_current();
            var operatorName = oListItem.get_item('Title');

            $("input[title='Employee Name Required Field']").val(operatorName);
            $("input[title='Employee Name Required Field']").prop('disabled', true);

            $("input[title='Current Level']").val('Trainee');
            $("input[title='Current Level']").prop('disabled', true);

            $("input[title='Training Level']").val('Level 3');
            $("input[title='Training Level']").prop('disabled', true);
        }
    }
}
function onretrieveOperatorInfoQueryFailed(sender, args) {
    alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
}


function GetCurrentListID() {
    if (document.location.href.indexOf('Primary') != -1) {
        return PrimaryStationTrainingDocsFeederFormListID;
    }
    if (document.location.href.indexOf('Secondary') != -1) {
        return SecondaryStationTrainingDocsFeederFormListID;
    }
    if (document.location.href.indexOf('DWB') != -1) {
        return DWBStationTrainingDocsFeederFormListID;
    }
    if (document.location.href.indexOf('AWT') != -1) {
        return AWTStationTrainingDocsFeederFormListID;
    }
}

function GetCAMLQueryPerStation() {
    if (document.location.href.indexOf('Primary') != -1) {
        var CAMLQuery = '<View><Query> <Where> <And> <Eq> <FieldRef Name=\'Plant_x0020_Station\' \/> <Value Type=\'Choice\'>1.0 Primary Station<\/Value> <\/Eq> <Eq> <FieldRef Name=\'Training_x0020_Level\' \/> <Value Type=\'Choice\'>Level 2<\/Value> <\/Eq> <\/And> <\/Where> <\/Query><\/View>';

        //var CAMLQuery = '<View><Query> <Where> <And> <Eq> <FieldRef Name=\'Training_x0020_Level\' \/> <Value Type=\'Text\'>Level 2<\/Value> <\/Eq> <Or> <Eq> <FieldRef Name=\'Plant_x0020_Station\' \/> <Value Type=\'Text\'>1.0 Primary Station<\/Value> <\/Eq> <Or> <Eq> <FieldRef Name=\'Plant_x0020_Station\' \/> <Value Type=\'Text\'>General Plant<\/Value> <\/Eq> <Eq> <FieldRef Name=\'Plant_x0020_Station\' \/> <Value Type=\'Text\'>Wet Weather Operations<\/Value> <\/Eq> <\/Or> <\/Or> <\/And> <\/Where> <OrderBy> <FieldRef Name=\'Modified\' Ascending=\'False\' \/> <\/OrderBy> <\/Query></View>';
        return CAMLQuery;
    }
    if (document.location.href.indexOf('Secondary') != -1) {
        var CAMLQuery = '<View><Query> <Where> <And> <Eq> <FieldRef Name=\'Plant_x0020_Station\' \/> <Value Type=\'Choice\'>2.0 Secondary Station<\/Value> <\/Eq> <Eq> <FieldRef Name=\'Training_x0020_Level\' \/> <Value Type=\'Choice\'>Level 2<\/Value> <\/Eq> <\/And> <\/Where> <\/Query><\/View>';
        return CAMLQuery;
    }
    if (document.location.href.indexOf('AWT') != -1) {
        var CAMLQuery = '<View><Query> <Where> <And> <Eq> <FieldRef Name=\'Plant_x0020_Station\' \/> <Value Type=\'Choice\'>3.0 Tertiary/AWT Station<\/Value> <\/Eq> <Eq> <FieldRef Name=\'Training_x0020_Level\' \/> <Value Type=\'Choice\'>Level 2<\/Value> <\/Eq> <\/And> <\/Where> <\/Query><\/View>';
        return CAMLQuery;
    }
    if (document.location.href.indexOf('DWB') != -1) {
        var CAMLQuery = '<View><Query> <Where> <And> <Eq> <FieldRef Name=\'Plant_x0020_Station\' \/> <Value Type=\'Choice\'>4.0 Dewatering Building Station<\/Value> <\/Eq> <Eq> <FieldRef Name=\'Training_x0020_Level\' \/> <Value Type=\'Choice\'>Level 2<\/Value> <\/Eq> <\/And> <\/Where> <\/Query><\/View>';
        return CAMLQuery;
    }
}