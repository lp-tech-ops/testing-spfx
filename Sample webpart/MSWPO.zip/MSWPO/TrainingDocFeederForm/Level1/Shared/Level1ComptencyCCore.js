/*
Author: Susheel Dakoju
Date: 07/14/2016
Description:This is the JSLink File. Based on the location populates the HTML needed.
JSLINK Format: //~site/SiteAssets/MSWPO/TaskStandardsFeederForm/Level1ComptencyCCore.js
*/

//Global Variables.
var currentFormUniqueId;
var currentFormWebPartId;

(function () {
    // jQuery library is required in this sample 
    // Fallback to loading jQuery from a CDN path if the local is unavailable 
    // jQuery library is required in this sample 
    document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/JQuery/jquery-1.11.0.min.js"><\/script>');
    document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/JQuery/jquery-ui.js"> </script>');
    document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/JQuery/jquery.loading-indicator.min.js"> </script>');
    document.write('<link href="/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/JQuery/jquery.loading-indicator.css" type="text/css" rel="stylesheet" />');
    //Training Docs Or Competency 3 Prerender File
    document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/TrainingDocFeederForm/Level1/Shared/Level1ComptencyCPreRender.js"> </script>');

    ExecuteOrDelayUntilScriptLoaded(_registerAccordionViewTemplate, 'clienttemplates.js');

    //Register Prerender and Postrender templates.
    function _registerAccordionViewTemplate() {
        // Create object that have the context information about the field that we want to change it's output render  
        var trainingDocsFeederFormContext = {};
        trainingDocsFeederFormContext.Templates = {};
        // Add OnPostRender event handler to add accordion click events and style 
        trainingDocsFeederFormContext.OnPreRender = trainingDocsFeederFormOnPreRender;
        trainingDocsFeederFormContext.OnPostRender = trainingDocsFeederFormPostRender;
        //Override Templates
        SPClientTemplates.TemplateManager.RegisterTemplateOverrides(trainingDocsFeederFormContext);
    }
    function trainingDocsFeederFormOnPreRender(ctx) {
        if (!currentFormUniqueId) {
            //Get the current form Unique ID
            currentFormUniqueId = ctx.FormUniqueId;

            //Get the Current from WebPart Id
            currentFormWebPartId = "WebPart" + ctx.FormUniqueId;

            jQuery(document).ready(function () {
                var formURL = GetFormURL();
                //Add the new HTML created for accordion at the top of the web part
                $.get(formURL, function (data, status) {
                    jQuery("#" + currentFormWebPartId).prepend(data);
                });
            });
        }
    }
    function trainingDocsFeederFormPostRender(ctx) {
        //TODO: Left place holder if needed to use for extending functionality
    }
})();

//Based on the current location get the html page to load
function GetFormURL() {
    if (document.location.href.indexOf('Primary') != -1) {
        return '/sites/wpcb/mswpo/SiteAssets/MSWPO/TrainingDocFeederForm/Level1/PSLevel1ComptencyCForm.html';
    }
    if (document.location.href.indexOf('Secondary') != -1) {
        return '/sites/wpcb/mswpo/SiteAssets/MSWPO/TrainingDocFeederForm/Level1/SSLevel1ComptencyCForm.html';
    }
    if (document.location.href.indexOf('DWB') != -1) {
        return '/sites/wpcb/mswpo/SiteAssets/MSWPO/TrainingDocFeederForm/Level1/DWBLevel1ComptencyCForm.html';
    }
    if (document.location.href.indexOf('AWT') != -1) {
        return '/sites/wpcb/mswpo/SiteAssets/MSWPO/TrainingDocFeederForm/Level1/AWTLevel1ComptencyCForm.html';
    }
    if (document.location.href.indexOf('All') != -1) {
        return '/sites/wpcb/mswpo/SiteAssets/MSWPO/TrainingDocFeederForm/Level1/AllStationsLevel1ComptencyCForm.html';
    }

}