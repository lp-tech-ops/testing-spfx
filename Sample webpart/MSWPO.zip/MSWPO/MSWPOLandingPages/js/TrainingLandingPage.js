﻿var siteUrl = '/sites/wpcb/mswpo/';

MSWPOSafetyTrainingCompletionListID = "9E08D4B1-10E4-4E14-8E02-31C3379732C0"; //MSWPO Safety Training Completion List: Operator_x0020_Look_x0020_up
operatorCetrificationEmployeeDataListID = '68C451AE-426B-4CFA-B2DC-B101D8D115DF'; //Operator Certification and Employee Data: System_x0020_Defined_x0020_Opera
operatorLookUpList = "F032B017-5260-492F-B72A-1A7E7FC31A23"; //Operator LookUp List

var docitemsReturned;
var operatorLevelInfo;
var operatorInfo;
var MSWPOSafetyTrainingCompleteListInfo;


//Populates the operator dropdow
SP.SOD.executeFunc('sp.js', 'SP.ClientContext', PopulateOperatorList);

//Populate the Having Trouble Modal
SP.SOD.executeFunc('sp.js', 'SP.ClientContext', PopulateHavingTroubleModal);

//Populates the Safety Training Summary and Basic Info
$("#ddlSelectOperator").change(function () {
    var selectedOperator = $("#ddlSelectOperator").val();
    GetOperatorInfo(selectedOperator);
});


/***** 1. Start fill operators dropdown list *****/
function PopulateOperatorList() {

    //Added to make it work with opname url param as well.
    var optrName = getUrlParameter('opname');

    /*** Call to populate the Operators ***/
    var fetchValue = GetOperators();

    fetchValue.done(function (result) {
        var returnedValue = result; //returns the array of operators

        if (returnedValue.length > 0) {

            var option = ''
            //Loop throught array and create option element for each operator
            for (var i = 0; i < returnedValue.length; i++) {

                if (optrName == returnedValue[i]) {

                    option += '<option value="' + returnedValue[i] + '" selected="true">' + returnedValue[i] + '</option>';
                }
                else {

                    option += '<option value="' + returnedValue[i] + '">' + returnedValue[i] + '</option>';
                }
            }
            //Add all operators to drop down.
            $('#ddlSelectOperator').append(option);

            //Empty values means that the page loaded for the first time with URL Parameter.
            GetOperatorInfo('');
        }
    });
    fetchValue.fail(function (result) {
        var error = result;
        console.log(error);
    });
}

/// Populates the list of operators 
function GetOperators() {
    //Get the sharepoint context based on the SiteUrl
    var clientContext = new SP.ClientContext.get_current();

    var d = $.Deferred();

    //Find the list to fetch the operators based on the GUID
    var oList = clientContext.get_web()
        .get_lists()
        .getById(operatorLookUpList);

    //Create a CAML Query: Pulls all operator excluding supervisors
    var camlQuery = new SP.CamlQuery();
    var strCAMLQuery = '<View><Query><Where><Eq><FieldRef Name=\'Job_x0020_Title\' \/> <Value Type=\'Choice\'>Operator<\/Value><\/Eq><\/Where><OrderBy><FieldRef Name=\'Operator_x0020_Name\' Ascending=\'True\' \/><\/OrderBy><\/Query></View>';
    camlQuery.set_viewXml(strCAMLQuery);

    //Fetch the operator information using the CAML Query.
    operatorInfo = oList.getItems(camlQuery);
    clientContext.load(operatorInfo);

    //Make the asychronous call.
    var o = { d: d, operatorInfo: operatorInfo };
    clientContext.executeQueryAsync(Function.createDelegate(o, OnOperatorListQuerySucceeded), Function.createDelegate(o, onretrieveOperatorListQueryFailed));

    return d.promise();

    //Query Succeeded.
    function OnOperatorListQuerySucceeded() {

        var listItemEnumerator = operatorInfo.getEnumerator();
        var totalOperatorCount = operatorInfo.get_count();
        var availableOperators = [];

        if (totalOperatorCount == 0) {
            console('Could not fetch operator info form Operator Look up list');
        }
        else {

            console.log('Sucessfully fetched operators to populate operator dropdown list and reutrned Operatorcount > 0')

            //loop through returned items and create array
            while (listItemEnumerator.moveNext()) {
                var oListItem = listItemEnumerator.get_current();
                //Fetch the operator title.
                var operatorName = oListItem.get_item('Operator_x0020_Name');
                //Check if the operator is already in the array and avoid if ture.
                if (jQuery.inArray(operatorName, availableOperators) == -1) {
                    availableOperators.push(operatorName); //-->Push to array
                }
            }
        }
        //Prepare array to return on success.
        this.d.resolve(availableOperators);
    }

    //Query Failed.
    function onretrieveOperatorListQueryFailed() {
        console.log('Request failed in GetOperators');
    }
}
/// Populates the list of operators 

/***** 1. Start Retrieve Operator Info *****/
function GetOperatorInfo(operatorName) {
    var optrName;
    if (operatorName) {
        optrName = operatorName
    }
    else {
        optrName = getUrlParameter('opname');
        if (!optrName) {
            optrName = $("#ddlSelectOperator option:first-child").val();
        }
        else {
            $('#ddlSelectOperator[value="' + optrName + '"]').attr('selected', true);
        }
    }
    if (optrName) {

        //Fetch operator info
        var fetchValue = RetrieveOperatorInfo(optrName)

        fetchValue.done(function (result) {
            var returnedValue = result;
            var returnedArray = returnedValue.toString().split(",");
            //There is no CDSS Form
            if (returnedArray.length > 0) {
                //Get the values from the returned Array
                var operatorName = returnedArray[0];
                var validHireDate = returnedArray[1];
                var diffYears = returnedArray[2];
                var OPSLicenseLevel = returnedArray[3];
                var Shift = returnedArray[4];
                var ShiftSupervisor = returnedArray[5];

                //$('#h2OPName').html(welcomeMessage);
                $('#basicInfoName').html(operatorName);
                $('#basicInfoHireDate').html(validHireDate);
                if (diffYears > 0) {
                    $('#basicInfoTimeInYears').html(diffYears + ' Years');
                }
                else {
                    $('#basicInfoTimeInYears').html('< 1 Year');
                }
                $('#basicInfoOPSLicenseLevel').html(OPSLicenseLevel);
                $('#basicInfoShift').html(Shift);
                $('#basicInfoShiftSupervisor').html(ShiftSupervisor);

                PopulateSafetyTrainingInfo(optrName);
                PopulateSafetySummary(optrName);
            }
        });
        fetchValue.fail(function (result) {
            var error = result;
            console.log(error);
        });
    }
}
function RetrieveOperatorInfo(optrName) {
    //1. Create client context based on the URL
    //Using JQUERY Deferred
    var d = $.Deferred();

    var clientContext = new SP.ClientContext.get_current();

    var oList = clientContext.get_web().get_lists().getById(operatorCetrificationEmployeeDataListID);

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(
        '<View><Query> <Where> <Eq> <FieldRef Name=\'System_x0020_Defined_x0020_Opera\' \/> <Value Type=\'Lookup\'>' + optrName + '<\/Value> <\/Eq> <\/Where> <\/Query></View>'
    );
    operatorLevelInfo = oList.getItems(camlQuery);
    clientContext.load(operatorLevelInfo);

    var o = { d: d, operatorLevelInfo: operatorLevelInfo, optrName: optrName };
    clientContext.executeQueryAsync(Function.createDelegate(o, onretrieveOperatorInfoQuerySucceeded), Function.createDelegate(o, onretrieveOperatorInfoQueryFailed));

    return d.promise();

    function onretrieveOperatorInfoQuerySucceeded() {
        var totalOperatorCount = operatorLevelInfo.get_count();
        if (totalOperatorCount == 0) {
            console.log("Something went wrong, could not fetch operator info.");
            //fnOpenNormalMessage('Something went wrong, could not fetch operator info.', 'Error', 150, 40)
        } else {
            console.log("Fetched operator info.");

            //Populate Operator Name
            var welcomeMessage = 'MSWPO Profile for ' + this.optrName;

            var listLevel1ItemEnumerator = operatorLevelInfo.getEnumerator();

            while (listLevel1ItemEnumerator.moveNext()) {

                var oListItem = listLevel1ItemEnumerator.get_current();
                //1. Operator Name
                var operatorName = oListItem.get_item('System_x0020_Defined_x0020_Opera').get_lookupValue();
                //2. Hire Date
                var HireDate = oListItem.get_item('Hire_x0020_Date');
                var frmtHireDate = new Date(HireDate);
                var validHireDate = (frmtHireDate.getMonth() + 1) + "/" + frmtHireDate.getDate() + "/" + frmtHireDate.getFullYear();
                //3. Time in Years
                var hireDate = new Date(validHireDate);
                var todaysDate = new Date(GetTodayDateinMMDDYYYY());
                var timeDiff = Math.abs(todaysDate.getTime() - hireDate.getTime());
                var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
                var diffYears = Math.round(diffDays / 365);
                //4. OPSLicense Level
                var OPSLicenseLevel = oListItem.get_item('OPS_x0020_License_x0020_Level');
                //5. Shift
                var Shift = oListItem.get_item('Shift');
                //6. Shif Supervisor
                var ShiftSupervisor = oListItem.get_item('Shift_x0020_Supervisor');
            }

            //Prepare array to return on success.
            var resultArray = [operatorName, validHireDate, diffYears, OPSLicenseLevel, Shift, ShiftSupervisor]
            this.d.resolve(resultArray);
        }
    }
    function onretrieveOperatorInfoQueryFailed() {
        console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}
/*****1. End Retrieve Operator Info *****/

/***** 2. Start Gets Safety Summary of operator from current and past year *****/
function PopulateSafetyTrainingInfo(operatorName) {
    if (operatorName) {
        var fetchValue = RetrieveMSWPOSafetyTrainingInfo(operatorName);
        //Make changes based on the result.
        fetchValue.done(function (result) {
            var returnedValue = result;

            var pastYear = returnedValue[0];
            var currentYear = returnedValue[1];
            if (pastYear == null || pastYear == undefined || pastYear == NaN) {
                pastYear = 0;
            }
            if (currentYear == null || currentYear == undefined) {
                currentYear = 0;
            }
            if (returnedValue != null) {

                var chartDataPoints = [
                { y: pastYear, label: "Past Year", indexLabel: "{y} %" },
                { y: currentYear, label: "Current Year", indexLabel: "{y} %" }
                ];
                var chart = new CanvasJS.Chart("chartContainer",
                {
                    title: {
                        text: "%Safety Training",
                        fontColor: "#fff",
                        fontFamily: "Lato",
                        fontSize: 15,
                        padding: 8,
                        margin: 15,
                        backgroundColor: "#9B234B",
                        borderThickness: 1,
                        cornerRadius: 5,
                        fontWeight: "bolder"
                    },
                    animationEnabled: true,
                    theme: "theme2",
                    width: 220,
                    height: 230,
                    axisY: {
                        title: "% Complete",
                        labelFontSize: 15,
                        maximum: 100
                    },
                    axisX: {
                        labelFontSize: 12
                    },
                    legend: {
                        verticalAlign: "bottom",
                        horizontalAlign: "center"
                    },
                    theme: "theme2",
                    data: [
                    {
                        type: "column",
                        indexLabelFontFamily: "Lato",
                        legendMarkerColor: "grey",
                        indexLabelFontColor: "red",
                        indexLabelLineColor: "red",
                        toolTipContent: "{y} %",
                        dataPoints: chartDataPoints
                    }
                    ]
                });
                chart.render();
            }

        });
    }
}
function RetrieveMSWPOSafetyTrainingInfo(operatorName) {
    //Using JQUERY Deferred
    var d = $.Deferred();
    //If in edit form
    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web()
        .get_lists()
        .getById(MSWPOSafetyTrainingCompletionListID);

    var camlQuery = new SP.CamlQuery();
    var CAMLQuery = '<View><Query> <Where> <Eq> <FieldRef Name=\'Operator_x0020_Look_x0020_up\' \/> <Value Type=\'Text\'>' + operatorName + '<\/Value> <\/Eq> <\/Where> <\/Query></View>';
    camlQuery.set_viewXml(CAMLQuery);

    MSWPOSafetyTrainingCompleteListInfo = oList.getItems(camlQuery);
    clientContext.load(MSWPOSafetyTrainingCompleteListInfo);

    var o = { d: d, MSWPOSafetyTrainingCompleteListInfo: MSWPOSafetyTrainingCompleteListInfo };
    clientContext.executeQueryAsync(Function.createDelegate(o, onretrieveMSWPOSafetTrainingInfoSuccess), Function.createDelegate(o, onretrieveMSWPOSafetTrainingInfoFailed));
    return d.promise();

    function onretrieveMSWPOSafetTrainingInfoSuccess() {

        var MSWPOSafetyTrainingCompleteListInfoEnumerator = this.MSWPOSafetyTrainingCompleteListInfo.getEnumerator();
        var resultCount = this.MSWPOSafetyTrainingCompleteListInfo.get_count();
        var TotalCompleted;
        var pastCurrentYearArray = [];
        if (resultCount > 0) {
            while (MSWPOSafetyTrainingCompleteListInfoEnumerator.moveNext()) {
                var currentYear = new Date().getFullYear();
                var pastYear = currentYear - 1;

                var oListItem = MSWPOSafetyTrainingCompleteListInfoEnumerator.get_current();
                var yearFromList = oListItem.get_item('Year');

                //Total Training Complete
                TotalCompleted = oListItem.get_item('_x0025__x0020_Total_x0020_Safety');

                if (currentYear == yearFromList) {
                    pastCurrentYearArray.push(parseInt(TotalCompleted));
                }
                if (pastYear == yearFromList) {
                    pastCurrentYearArray.push(parseInt(TotalCompleted));
                }

            }
            return this.d.resolve(pastCurrentYearArray);
        }
    }
    function onretrieveMSWPOSafetTrainingInfoFailed() {
        console.log('Request failed!');
    }
}
/***** 2. END Gets Safety Summary of operator from current and past year *****/

/***** 3. Start Retrieve Operator Safety Training Summary: All Years *****/
function PopulateSafetySummary(operatorName) {

    if (operatorName) {
        var fetchValue = RetrieveMSWPOSafetySummaryInfo(operatorName);
        //Make changes based on the result.
        fetchValue.done(function (result) {
            var returnedValue = result;

            //Populate the datable
            var table = $('#tblSafetySummary').DataTable();
            table.destroy(); //helps to clear the data table when dropdown changes.
            table = $('#tblSafetySummary').DataTable({
                data: returnedValue,
                paging: false,
                searching: false
            });
        });
    }

}
function RetrieveMSWPOSafetySummaryInfo(operatorName) {

    var d = $.Deferred();

    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web()
        .get_lists()
        .getById(MSWPOSafetyTrainingCompletionListID);

    var camlQuery = new SP.CamlQuery();
    var CAMLQuery = '<View><Query> <Where> <Eq> <FieldRef Name=\'Operator_x0020_Look_x0020_up\' \/> <Value Type=\'Text\'>' + operatorName + '<\/Value> <\/Eq> <\/Where> <\/Query></View>';
    camlQuery.set_viewXml(CAMLQuery);

    MSWPOSafetyTrainingCompleteListInfo = oList.getItems(camlQuery);
    clientContext.load(MSWPOSafetyTrainingCompleteListInfo);

    var o = { d: d, MSWPOSafetyTrainingCompleteListInfo: MSWPOSafetyTrainingCompleteListInfo };
    clientContext.executeQueryAsync(Function.createDelegate(o, onretrieveMSWPOSafetyTrainingInfoSuccess), Function.createDelegate(o, onretrieveMSWPOSafetyTrainingInfoFailed));

    return d.promise();

    function onretrieveMSWPOSafetyTrainingInfoSuccess() {
        var MSWPOSafetyTrainingCompleteListInfoEnumerator = this.MSWPOSafetyTrainingCompleteListInfo.getEnumerator();
        var resultCount = this.MSWPOSafetyTrainingCompleteListInfo.get_count();

        var TotalCompleted;
        var OnlineCompleted;
        var facetoCompleted;
        var YearPercentCompleteSummary = [];

        if (resultCount > 0) {
            while (MSWPOSafetyTrainingCompleteListInfoEnumerator.moveNext()) {
                var oListItem = MSWPOSafetyTrainingCompleteListInfoEnumerator.get_current();
                var yearFromList = oListItem.get_item('Year');
                facetoCompleted = oListItem.get_item('_x0025_Face_x0020_to_x0020_Face_');
                OnlineCompleted = oListItem.get_item('_x0025_Online_x0020_Completed');
                TotalCompleted = oListItem.get_item('_x0025__x0020_Total_x0020_Safety');
                YearPercentCompleteSummary.push([yearFromList, facetoCompleted, OnlineCompleted, TotalCompleted]);
            }
            return this.d.resolve(YearPercentCompleteSummary);
        }
    }
    function onretrieveMSWPOSafetyTrainingInfoFailed() {
        console.log('Request failed!');
    }
}
/***** 3. END Retrieve Operator Safety Training Summary: All Years *****/

/***** Start Send Email *****/
/***** Start: Populate Having Trouble Modal *****/
function PopulateHavingTroubleModal() {

    //Prepare for email
    var fromAddress = "sdakoju@arlingtonva.us";

    //1. To Address
    var toAddress = "Helpdesk@arlingtonva.us;";

    //2. CC Address
    var ccAddress = '';

    var currentURL = window.location.href;


    var ccAddressfetchValue = GetCurrentUserEmailInfo();
    //Make changes based on the result.
    ccAddressfetchValue.done(function (result) {
        var returnedValue = result;
        if (returnedValue) {
            ccAddress = returnedValue[0];
            $("#HavingTroubleModalEmailCC").attr('value', ccAddress);

            //3. Email Body
            var supervisorORLoggedInUserName = returnedValue[1];
            var body = "Hi, <br/> <label style=\"font-family:'Segoe UI';font-size:1.0em !important\"> I am having trouble using MSWPO Application.<br/><br/> URL: <a href='" + currentURL + "' style='color:blue !important;'>" + currentURL + "</a><br/><br/>Can you please notify dts-sharepointteam@arlingtonva.us? <br/><br/> (Describe your issue) <br/><br/> Thank you, <br/>" + supervisorORLoggedInUserName + "<label>";
            body = "<HTML><HEAD> <META name=GENERATOR content=\"MSHTML 10.00.9200.16843\"><\/HEAD><BODY>" + body + "<\/BODY><\/HTML>"
            $("#HavingTroubleModalEmailBody").html(body);

        }
    });

    //3. Email Body (if the email body is not populated from the above)
    var supervisorORLoggedInUserName = $("#HavingTroubleModalEmailBody").val();
    if (supervisorORLoggedInUserName == '') {
        var body = "Hi, <br/> <label style=\"font-family:'Segoe UI';font-size:1.0em !important\"> I am having trouble using MSWPO Application.<br/><br/><a href='" + currentURL + "'>Click Here</a><br/><br/>Can you please notify dts-sharepointteam@arlingtonva.us? <br/><br/> (Describe your issue) <br/><br/> Thank you <label>";
        body = "<HTML><HEAD> <META name=GENERATOR content=\"MSHTML 10.00.9200.16843\"><\/HEAD><BODY>" + body + "<\/BODY><\/HTML>"
        $("#HavingTroubleModalEmailBody").html(body);
    }

    //4. Subject
    var subject = "MSWPO: Technical Issue";
    $("#HavingTroubleModalEmailSubject").attr('value', subject);

    //5. Show the modal
    // $('#HavingTroubleModal').modal('show', { backdrop: 'static' });
}

function GetCurrentUserEmailInfo() {
    var d = $.Deferred();

    var context = new SP.ClientContext.get_current();
    var web = context.get_web();
    var currentUser = web.get_currentUser();
    currentUser.retrieve();
    context.load(web);

    var o = { d: d, web: web };
    context.executeQueryAsync(Function.createDelegate(o, onQuerySucceeded), Function.createDelegate(o, onQueryFailed));

    return d.promise();

    function onQuerySucceeded(sender, args) {
        var returnArray = [];
        var currentUser = this.web.get_currentUser();
        var email = currentUser.get_email();
        var Title = currentUser.get_title();
        returnArray[0] = email;
        returnArray[1] = Title;
        //var id = userObject.get_id();
        // var loginName = userObject.get_loginName();
        this.d.resolve(returnArray);
    }
    function onQueryFailed(sender, args) {
        alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}
function SendOperatorEmail(ModalToPopup) {
    var fromAddress = "sdakoju@arlingtonva.us"; //This will NOT appear as from address
    var toAddress = $("#" + ModalToPopup + "EmailTo").val();
    var ccAddress = $("#" + ModalToPopup + "EmailCC").val().split(',');
    var subject = $("#" + ModalToPopup + "EmailSubject").val();
    var body = $("#" + ModalToPopup + "EmailBody").html();
    var isSuccess = SendEmail(fromAddress, toAddress, ccAddress, subject, body);
    if (isSuccess == false) {
        alert('Email Sending Failed!');
        //TODO: Close Pop up window
    }
    else { alert('Email Sending Successfully!'); }
}

function SendEmail(fromAddress, toAddress, ccAddress, subject, body) {
    //Get the relative url of the site
    var siteurl = _spPageContextInfo.webServerRelativeUrl;
    var urlTemplate = siteurl + "/_api/SP.Utilities.Utility.SendEmail";
    $.ajax({
        contentType: 'application/json',
        url: urlTemplate,
        type: "POST",
        data: JSON.stringify({
            'properties': {
                '__metadata': { 'type': 'SP.Utilities.EmailProperties' },
                'From': fromAddress,
                'To': { 'results': [toAddress] },
                'Body': body,
                'CC': { 'results': ccAddress },
                'Subject': subject
            }
        }),
        headers: {
            "Accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
            "X-RequestDigest": jQuery("#__REQUESTDIGEST").val()
        },
        success: function (data) {
            return true;
        },
        error: function (err) {
            return false;
        }
    });

}
/***** End: Populate Having Trouble Modal *****/

function SendEmail(fromAddress, toAddress, ccAddress, subject, body) {
    //Get the relative url of the site
    var siteurl = _spPageContextInfo.webServerRelativeUrl;
    var urlTemplate = siteurl + "/_api/SP.Utilities.Utility.SendEmail";
    $.ajax({
        contentType: 'application/json',
        url: urlTemplate,
        type: "POST",
        data: JSON.stringify({
            'properties': {
                '__metadata': {
                    'type': 'SP.Utilities.EmailProperties'
                },
                'From': fromAddress,
                'To': {
                    'results': [toAddress]
                },
                'Body': body,
                'CC': {'results': ccAddress},
                'Subject': subject
            }
        }),
        headers: {
            "Accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
            "X-RequestDigest": jQuery("#__REQUESTDIGEST").val()
        },
        success: function (data) {
            return true;
        },
        error: function (err) {
            return false;
        }
    });
}
/***** End Send Email *****/

/***** Start Utility Functions *****/
//Get the URL Parameter based on the parameter name
function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;
    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            if (sParameterName[1] === undefined) {
                return true;
            }
            else {
                var returnValue = sParameterName[1].replace('+', ' ');
                return returnValue;
            }
        }
    }
};

//Formats ANY date to convert to mm/dd/yyyy format
function FormatDate(unformattedDate) {
    var frmtModifiedDate = new Date(unformattedDate);
    var validModifiedDate = (frmtModifiedDate.getMonth() + 1) + "/" + frmtModifiedDate.getDate() + "/" + frmtModifiedDate.getFullYear();
    return validModifiedDate;
}

//Formats TODAYS date to mm/dd/yyyy format
function GetTodayDateinMMDDYYYY() {
    var todaysDate = new Date();
    var curr_date = todaysDate.getDate();
    var curr_month = todaysDate.getMonth() + 1; //Months are zero based
    var curr_year = todaysDate.getFullYear();
    var strDate = curr_month + '/' + curr_date + '/' + curr_year;
    return strDate;
}

/***** End Utility Functions *****/

