﻿var siteUrl = '/sites/wpcb/mswpo/';
var trainingProgressInfo;
var taskStandardsListInfo;
var MSWPOSafetyTrainingCompleteListInfo;

PrimaryCDSSListID = "3b8c1d2c-1839-4491-87b0-30c4926361d5"    // Title=CDSS Primary Station Training Level 3
SecondaryCDSSListID = "a606bc0f-0f4c-4654-bd1c-e4fca32154ab"  // Title=CDSS- Secondary Station - Training Level 3
AWTCDSSListID = "a1d23b11-4eb9-40d8-9e3e-565e1b7ee422"         // Title=CDSS- AWT Station - Training Level 3
DWBCDSSListID = "64d28fce-ff0e-46b4-8c64-76fa27162a04"// Title=CDSS- DWB Station - Training Level 3

PrimaryCDSSListEncodedLibraryName = "CDSS%20Primary%20Station%20Training%20Level%203";

PrimarytrainingDocsListID = "8a44d44b-8da7-40e7-a057-d94e2954c712";  //Title=Primary Station - Level 3 Feeder Training Docs
SecondarytrainingDocsListID = "9a113dca-97ec-4c37-86ca-01f95a0d1498";  //Title=Secondary Station - Level 3 Feeder Training Docs
AWTtrainingDocsListID = "d9fc725b-9394-46ef-b94e-90bedd717865";  //Title=AWT Station - Level 3 Feeder Training Docs
DWBtrainingDocsListID = "5cc83d4e-892d-4f2b-8a7f-4986d74fd68b";  //Title=DWB Station - Level 3 Feeder Training Docs

PrimaryTaskStandardsID = "DBEC4BE4-3A1E-403F-B5C5-79340F48445C";  //Title=Primary Station Level 3 Task Standards - RRCLs
SecondaryTaskStandardsID = "f0b13014-aba0-4f79-b21d-b9d48d8d5a24";  //Title=Secondary Station Level 3 Task Standards - RRCLs
AWTTaskStandardsID = "d6e8defa-b6d6-4654-a7af-1f244599c1bd";  //Title=AWT Station Level 3 Task Standards - RRCLs
DWBTaskStandardsID = "ea0b10c3-cb86-4e19-ab76-f16b55bac9e0";  //Title=DWB Station Level 3 Task Standards - RRCLs

MSWPOSafetyTrainingCompletionListID = "9E08D4B1-10E4-4E14-8E02-31C3379732C0"; //MSWPO Safety Training Completion List: Operator_x0020_Look_x0020_up
operatorCetrificationEmployeeDataListID = '68C451AE-426B-4CFA-B2DC-B101D8D115DF'; //Operator Certification and Employee Data: System_x0020_Defined_x0020_Opera

PrimaryTaskStandardsEncodedLibraryName = "Primary Station Level 3 Task Standards  RRCLs";
SecondaryTaskStandardsEncodedLibraryName = "Secondary Station Level 3 Task Standards  RRCLs";
AWTTaskStandardsEncodedLibraryName = "AWT Station Level 3 Task Standards  RRCLs";
DWBTaskStandardsEncodedLibraryName = "DWB Station Level 3 Task Standards  RRCLs";

PrimarytrainingDocsLibraryName = "Primary Station  Level 3 Feeder Training Docs";
SecondarytrainingDocsLibraryName = "Secondary Station  Level 3 Feeder Training Docs";
DWBtrainingDocsLibraryName = "DWB Station  Level 3 Feeder Training Docs";
AWTtrainingDocsListLibraryName = "AWT Station  Level 3 Feeder Training Docs";

var docLibTrainingDocumentSetID = "C8746D73-8405-44C5-BCE2-0DD0E8CDC332";
var docitemsReturned;
var operatorLevelInfo;
var operatorInfo;

SP.SOD.executeFunc('sp.js', 'SP.ClientContext', PopulateOperatorList);
SP.SOD.executeFunc('sp.js', 'SP.ClientContext', GetDefaultInfo);

$("#ddlShift").change(function () {
    GetDefaultInfo();
});
$("#ddlStation").change(function () {
    GetDefaultInfo();
});
$("#ddlSelectOperator").change(function () {
    var selectedOperator = $("#ddlSelectOperator").val();
   // window.location.href = '/sites/wpcb/mswpo/SitePages/SupervisorMultipleOperators.aspx?opname=' + selectedOperator;
   GetOperatorInfo(selectedOperator);
});
/***** 1. Start Retrieve Operator Info *****/
function GetDefaultInfo() {
    var selectShift = $("#ddlShift").val();
    var selectStation = $("#ddlStation").val();
    var fetchValue = RetrieveOperatorInfoByShiftandStation(selectShift, selectStation)
    fetchValue.done(function (result) {
        var returnedValue = result;
        var dataSet = [];
        //var returnedArray = returnedValue.toString().split(",");
        //There is no CDSS Form
        if (returnedValue.length > 0) {
            for (var i = 0; i < returnedValue.length; i++) {
                var returnedArray = returnedValue[i];
                var operatorName = returnedArray[0];
                var station = returnedArray[1];
                var Shift = returnedArray[2];
                var StationsCurrentLevel = returnedArray[3];
                var TrainingForLevel = 'N/A';
                dataSet.push([operatorName, station, Shift, StationsCurrentLevel, TrainingForLevel]);
            }

           var table =  $('#tblOperatorResults').DataTable();
           table.destroy();
           table = $('#tblOperatorResults').DataTable({
               data: dataSet,
               paging: false,
               searching:false
           });
        }
    });
    fetchValue.fail(function (result) {
        var error = result;
        console.log(error);
    });

}
function RetrieveOperatorInfoByShiftandStation(shift,station) {
    //1. Create client context based on the URL
    //Using JQUERY Deferred
    var d = $.Deferred();

    var clientContext = new SP.ClientContext.get_current();

    var oList = clientContext.get_web().get_lists().getById(operatorCetrificationEmployeeDataListID);

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(
        '<View><Query><Where><Eq><FieldRef Name=\'Shift\' \/><Value Type=\'Text\'>' + shift + '<\/Value> <\/Eq> <\/Where> <\/Query></View>'
    );
    operatorLevelInfo = oList.getItems(camlQuery);
    clientContext.load(operatorLevelInfo);

    var o = { d: d, operatorLevelInfo: operatorLevelInfo,station:station };
    clientContext.executeQueryAsync(Function.createDelegate(o, onretrieveOperatorInfoQuerySucceeded), Function.createDelegate(o, onretrieveOperatorInfoQueryFailed));

    return d.promise();

    function onretrieveOperatorInfoQuerySucceeded() {
        var totalOperatorCount = operatorLevelInfo.get_count();
        if (totalOperatorCount == 0) {
            console.log("Something went wrong, could not fetch operator info.");
        } else {
            console.log("Fetched operator info.");
            var listLevel1ItemEnumerator = operatorLevelInfo.getEnumerator();
            var resultArray = [];
            while (listLevel1ItemEnumerator.moveNext()) {
                var oListItem = listLevel1ItemEnumerator.get_current();
                //1. Operator Name
                var operatorName = oListItem.get_item('System_x0020_Defined_x0020_Opera').get_lookupValue();

                var operatorHyperLink = "<a href='/sites/wpcb/mswpo/SitePages/SupervisorSingleOperator.aspx?opname=" + operatorName + "'>" + operatorName + "</a>";
                //4. OPSLicense Level
                var OPSLicenseLevel = oListItem.get_item('OPS_x0020_License_x0020_Level');
                //5. Shift
                var Shift = oListItem.get_item('Shift');
                //6. Shif Supervisor

                //7. Current Levels at all Stations

                var PrimaryCurrentLevel = oListItem.get_item('Primary_x0020_Current_x0020_Leve');
                var SecondaryCurrentLevel = oListItem.get_item('Secondary_x0020_Current_x0020_Le');
                var AWTCurrentLevel = oListItem.get_item('AWT_x0020_Current_x0020_Level');
                var DWBCurrentLevel = oListItem.get_item('DWB_x0020_Current_x0020_Level');

                var LevelToDisplay;

                switch (station) {
                    case 'Primary':
                        LevelToDisplay = PrimaryCurrentLevel;
                        break;
                    case 'Secondary':
                        LevelToDisplay = SecondaryCurrentLevel;
                        break;
                    case 'AWT':
                        LevelToDisplay = AWTCurrentLevel;
                        break;
                    case 'DWB':
                        LevelToDisplay = DWBCurrentLevel;
                        break;
                    default:
                        LevelToDisplay = PrimaryCurrentLevel;
                }

                resultArray.push([operatorHyperLink, station, Shift, LevelToDisplay]);
            }

            //Prepare array to return on success.
            this.d.resolve(resultArray);
        }
    }
    function onretrieveOperatorInfoQueryFailed() {
        console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}

function PopulateOperatorList() {
    var fetchValue = GetOperators()
    fetchValue.done(function (result) {
        var returnedValue = result;
        if (returnedValue.length > 0) {
            var option = ''
            for (var i = 0; i < returnedValue.length; i++) {
                option += '<option value="' + returnedValue[i] + '">' + returnedValue[i] + '</option>';
            }
            //Use JQuery Autocomplete feature and provide with Available Operators.
            $('#ddlSelectOperator').append(option);
            GetOperatorInfo('');
        }
    });
    fetchValue.fail(function (result) {
        var error = result;
        console.log(error);
    });
}

/* Populates the list of operators */
function GetOperators() {
    //Get the sharepoint context based on the SiteUrl
    var clientContext = new SP.ClientContext.get_current();

    var d = $.Deferred();

    //Find the list to fetch the operators based on the GUID
    var oList = clientContext.get_web()
        .get_lists()
        .getById(operatorCetrificationEmployeeDataListID);

    //Create a CAML Query
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<Query> <OrderBy> <FieldRef Name=\'System_x0020_Defined_x0020_Opera\' Ascending=\'True\' /></OrderBy></Query>'
    );

    //Fetch the operator information using the CAML Query.
    operatorInfo = oList.getItems(camlQuery);
    clientContext.load(operatorInfo);

    var o = { d: d, operatorInfo: operatorInfo };
    clientContext.executeQueryAsync(Function.createDelegate(o, OnOperatorListQuerySucceeded), Function.createDelegate(o, onretrieveOperatorListQueryFailed));

    return d.promise();
    //Make the asychronous call.
    clientContext.executeQueryAsync(Function.createDelegate(this, this.OnOperatorListInfoQuerySucceeded),
        Function.createDelegate(this, this.OnOperatorListOperatorInfoQueryFailed)
    );
}


/***** 1. Start Retrieve Operator Info *****/
function GetOperatorInfo(operatorName) {
    var optrName;
    if (operatorName) {
        optrName = operatorName
    }
    else {
        optrName = getUrlParameter('opname');
    }
    if (optrName) {
        var fetchValue = RetrieveOperatorInfo(optrName)
        fetchValue.done(function (result) {
            var returnedValue = result;
            var returnedArray = returnedValue.toString().split(",");
            //There is no CDSS Form
            if (returnedArray.length > 0) {
                //Get the values from the returned Array
                var welcomeMessage = returnedArray[0];
                var operatorName = returnedArray[1];
                var validHireDate = returnedArray[2];
                var diffYears = returnedArray[3];
                var OPSLicenseLevel = returnedArray[4];
                var Shift = returnedArray[5];
                var ShiftSupervisor = returnedArray[6];
                var StationsCurrentLevel = returnedArray[7];
                var StationsLevelDates = returnedArray[8];

                $('#h2OPName').html(welcomeMessage);
                $('#basicInfoName').html(operatorName);
                $('#basicInfoHireDate').html(validHireDate);
                if (diffYears > 0) {
                    $('#basicInfoTimeInYears').html(diffYears + ' Years');
                }
                else {
                    $('#basicInfoTimeInYears').html('< 1 Year');
                }
                $('#basicInfoOPSLicenseLevel').html(OPSLicenseLevel);
                $('#basicInfoShift').html(Shift);
                $('#basicInfoShiftSupervisor').html(ShiftSupervisor);

                var keyValuePair = StationsCurrentLevel.split(';');
                console.log(StationsCurrentLevel);
                console.log("Length of of key value Pair" + keyValuePair.length);

                for (var i = 0; i < keyValuePair.length; i++) {
                    var splitKeyValuePair = keyValuePair[i].split('=');
                    var key = splitKeyValuePair[0];
                    var value = splitKeyValuePair[1];
                    var controlToPopulate = '#lblCurrentLevelInfo' + key;
                    $(controlToPopulate).attr('Style', 'margin-left:20px;');
                    if (value == 'T') {
                        value = 'Trainee';
                        $(controlToPopulate).html(' <i class="fa fa-graduation-cap"></i>Current level at this station is ' + value);
                    }
                    else {
                        $(controlToPopulate).html(' <i class="fa fa-graduation-cap"></i>Current level at this station is Level ' + value);
                    }
                }

            }
            OverrideDefaultValues(optrName,StationsCurrentLevel, StationsLevelDates);
            PopulateLevel3ColumnValues(optrName,StationsCurrentLevel, StationsLevelDates);
        });
        fetchValue.fail(function (result) {
            var error = result;
            console.log(error);
        });
    }
}
function RetrieveOperatorInfo(optrName) {
    //1. Create client context based on the URL
    //Using JQUERY Deferred
    var d = $.Deferred();

    var clientContext = new SP.ClientContext.get_current();

    var oList = clientContext.get_web().get_lists().getById(operatorCetrificationEmployeeDataListID);

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(
        '<View><Query> <Where> <Eq> <FieldRef Name=\'System_x0020_Defined_x0020_Opera\' \/> <Value Type=\'Lookup\'>' + optrName + '<\/Value> <\/Eq> <\/Where> <\/Query></View>'
    );
    operatorLevelInfo = oList.getItems(camlQuery);
    clientContext.load(operatorLevelInfo);

    var o = { d: d, operatorLevelInfo: operatorLevelInfo, optrName: optrName };
    clientContext.executeQueryAsync(Function.createDelegate(o, onretrieveOperatorInfoQuerySucceeded), Function.createDelegate(o, onretrieveOperatorInfoQueryFailed));

    return d.promise();

    function onretrieveOperatorInfoQuerySucceeded() {
        var totalOperatorCount = operatorLevelInfo.get_count();
        if (totalOperatorCount == 0) {
            console.log("Something went wrong, could not fetch operator info.");
            //fnOpenNormalMessage('Something went wrong, could not fetch operator info.', 'Error', 150, 40)
        } else {
            console.log("Fetched operator info.");

            //Populate Operator Name
            var welcomeMessage = 'Operator MSWPO Profile Page - Welcome ' + this.optrName;

            var listLevel1ItemEnumerator = operatorLevelInfo.getEnumerator();

            while (listLevel1ItemEnumerator.moveNext()) {

                var oListItem = listLevel1ItemEnumerator.get_current();
                //1. Operator Name
                var operatorName = oListItem.get_item('System_x0020_Defined_x0020_Opera').get_lookupValue();
                //2. Hire Date
                var HireDate = oListItem.get_item('Hire_x0020_Date');
                var frmtHireDate = new Date(HireDate);
                var validHireDate = (frmtHireDate.getMonth() + 1) + "/" + frmtHireDate.getDate() + "/" + frmtHireDate.getFullYear();
                //3. Time in Years
                var hireDate = new Date(validHireDate);
                var todaysDate = new Date(GetTodayDateinMMDDYYYY());
                var timeDiff = Math.abs(todaysDate.getTime() - hireDate.getTime());
                var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
                var diffYears = Math.round(diffDays / 365);
                //4. OPSLicense Level
                var OPSLicenseLevel = oListItem.get_item('OPS_x0020_License_x0020_Level');
                //5. Shift
                var Shift = oListItem.get_item('Shift');
                //6. Shif Supervisor
                var ShiftSupervisor = oListItem.get_item('Shift_x0020_Supervisor');

                //7. Current Levels at all Stations
                var PrimaryCurrentLevel = oListItem.get_item('Primary_x0020_Current_x0020_Leve');
                var SecondaryCurrentLevel = oListItem.get_item('Secondary_x0020_Current_x0020_Le');
                var AWTCurrentLevel = oListItem.get_item('AWT_x0020_Current_x0020_Level');
                var DWBCurrentLevel = oListItem.get_item('DWB_x0020_Current_x0020_Level');

                var PrimaryLevel3CertDate = oListItem.get_item('Primary_x0020_L3_x0020_Certifica');
                var PrimaryLevel2CertDate = oListItem.get_item('Primary_x0020_L2_x0020_Certifica');

                var SecondaryLevel3CertDate = oListItem.get_item('Secondary_x0020_L3_x0020_Certifi');
                var SecondaryLevel2CertDate = oListItem.get_item('Secondary_x0020_L2_x0020_Certifi');

                var AWTLevel3CertDate = oListItem.get_item('AWT_x0020_L3_x0020_Certification');
                var AWTLevel2CertDate = oListItem.get_item('AWT_x0020_L2_x0020_Certification');

                var DWBLevel3CertDate = oListItem.get_item('DWB_x0020_L3_x0020_Certification');
                var DWBLevel2CertDate = oListItem.get_item('DWB_x0020_L2_x0020_Certification');

                var keyValueString = "PS=" + PrimaryCurrentLevel + ";" + "SS=" + SecondaryCurrentLevel + ";" + "AWT=" + AWTCurrentLevel + ";" + "DWB=" + DWBCurrentLevel;
                console.log("keyValueString" + keyValueString);

                var certkeyValueString = "PSLevel3CertDate=" + PrimaryLevel3CertDate + ";" + "PSLevel2CertDate=" + PrimaryLevel2CertDate + "|" + "SSLevel3CertDate=" + SecondaryLevel3CertDate + ";" + "SSLevel2CertDate=" + SecondaryLevel2CertDate + "|" + "AWTLevel3CertDate=" + AWTLevel3CertDate + ";" + "AWTLevel2CertDate=" + AWTLevel2CertDate + "|" + "DWBLevel3CertDate=" + DWBLevel3CertDate + ";" + "DWBLevel2CertDate=" + DWBLevel2CertDate;

                console.log("keyValueString:  " + keyValueString);
                console.log("certkeyValueString:  " + certkeyValueString);

            }

            //Prepare array to return on success.
            var resultArray = [welcomeMessage, operatorName, validHireDate, diffYears, OPSLicenseLevel, Shift, ShiftSupervisor, keyValueString, certkeyValueString]
            this.d.resolve(resultArray);
        }
    }
    function onretrieveOperatorInfoQueryFailed() {
        console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}
/*****1. End Retrieve Operator Info *****/


//Query Succeeded.
function OnOperatorListQuerySucceeded() {
    var listItemEnumerator = operatorInfo.getEnumerator();
    var totalOperatorCount = operatorInfo.get_count();
    var availableOperators = [];

    if (totalOperatorCount == 0) {
        alert('Could not fetch operator info');
    }
    else {
        console.log('Entered TotalOperatorcount > 0')
        while (listItemEnumerator.moveNext()) {
            var oListItem = listItemEnumerator.get_current();

            //Fetch the operator title.
            var operatorName = oListItem.get_item('System_x0020_Defined_x0020_Opera').get_lookupValue();
            //Check if the operator is already in the array and avoid if ture.
            if (jQuery.inArray(operatorName, availableOperators) == -1) {
                availableOperators.push(operatorName);
            }
        }
    }
    //Prepare array to return on success.
    this.d.resolve(availableOperators);
}

//Query Failed.
function onretrieveOperatorListQueryFailed() {
    console.log('Request failed in GetOperators');
}

/*****2. Start= Level 3 rows for each Panel *****/
function OverrideDefaultValues(optrName,StationsCurrentLevel, StationsLevelDates) {
    //Get the prefix to test
    //StationsCurrentLevel = PS=T; SS=2; AWT=T; DWB=T
    //Get CurrentLevel
    var keyValuePair = StationsCurrentLevel.split(';');
    var Level2CDSSControls = ["#PSLevel2CDSS", "#SSLevel2CDSS", "#AWTLevel2CDSS", "#DWBLevel2CDSS"];
    var CtrlTaskStandardsLevel2IDs = ["#PSLevel2TaskStandards", "#SSLevel2TaskStandards", "#AWTLevel2TaskStandards", "#DWBLevel2TaskStandards"];
    var CtrlTrainingLevel2IDs = ["#PSLevel2TrainingDocs", "#SSLevel2TrainingDocs", "#AWTLevel2TrainingDocs", "#DWBLevel2TrainingDocs"];
    var Level3CDSSControls = ["#PSLevel3CDSS", "#SSLevel3CDSS", "#AWTLevel3CDSS", "#DWBLevel3CDSS"];
    var CtrlTaskStandardsLevel3IDs = ["#PSLevel3TaskStandards", "#SSLevel3TaskStandards", "#AWTLevel3TaskStandards", "#DWBLevel3TaskStandards"];
    var CtrlTrainingLevelLevel3IDs = ["#PSLevel3TrainingDocs", "#SSLevel3TrainingDocs", "#AWTLevel3TrainingDocs", "#DWBLevel3TrainingDocs"];

    for (var j = 0; j < keyValuePair.length; j++) {
        //Clear Controls
        $(Level2CDSSControls[j]).empty();
        $(CtrlTaskStandardsLevel2IDs[j]).empty();
        $( CtrlTrainingLevel2IDs[j]).empty();
        $(Level3CDSSControls[j]).empty();
        $(CtrlTaskStandardsLevel3IDs[j]).empty();
        $(CtrlTrainingLevelLevel3IDs[j]).empty();

        var splitKeyValuePair = keyValuePair[j].split('=');
        var key = splitKeyValuePair[0];
        var value = splitKeyValuePair[1];

        //StationsLevelDates = PSLevel3CertDate:null;PSLevel2CertDate:null|SSLevel3CertDate:Tue Jan 27 2015 01:00:00 GMT-0500 (Eastern Standard Time);SSLevel2CertDate:Sat Jun 27 2015 02:00:00 GMT-0400 (Eastern Daylight Time)|AWTLevel3CertDate:null;AWTLevel2CertDate:null|DWBLevel3CertDate:null;DWBLevel2CertDate:null

        var datekeyValuePair = StationsLevelDates.split('|');  //==PSLevel3CertDate:null;PSLevel2CertDate:null

        //Get Level 3 Dates
        var datekeyLevel3 = datekeyValuePair[j].split(';')[0].split('=')[0]; //PSLevel3CertDate:null and [PSLevel3CertDate]
        var datevalueLevel3 = datekeyValuePair[j].split(';')[0].split('=')[1];//[null]

        //Get Level 2 Dates
        var datekeyLevel2 = datekeyValuePair[j].split(';')[1].split('=')[0];
        var datevalueLevel2 = datekeyValuePair[j].split(';')[1].split('=')[1];

        if (value == 2) {
            //Overwrite Level 2 Controls
            if (datevalueLevel2 == null || datekeyLevel2 == 'null') {
                $(Level2CDSSControls[j]).html('<i class="fa fa-calendar-o">Certified(Date Information Unvailable)');
            }
            else {
                var certificationDate = FormatDate(datevalueLevel2);
                $(Level2CDSSControls[j]).html('<i class="fa fa-calendar"></i> Certified On: ' + certificationDate + '<br/> (Prior to MSWPO)');
            }
            $(CtrlTaskStandardsLevel2IDs[j]).html('<i class="fa fa-file-text"></i> Documentation Prior To MSWPO');
            $(CtrlTrainingLevel2IDs[j]).html('<i class="fa fa-file-text"></i> Documentation Prior To MSWPO');
        }
        //If current level at Station is 3
        if (value == 3 || value == 2) {
            //Overwrite Level 2 Controls
            if (datevalueLevel3 == null || datevalueLevel3 == 'null') {
                $(Level3CDSSControls[j]).html('<i class="fa fa-calendar-o"></i> Certified (Date Information Unvailable)');
            }
            else {
                var certificationDate = FormatDate(datevalueLevel3);
                $(Level3CDSSControls[j]).html('<i class="fa fa-calendar"></i> Certified On: ' + certificationDate + '<br/> (Prior to MSWPO)');
            }
         
            $(CtrlTaskStandardsLevel3IDs[j]).html('<i class="fa fa-file-text"></i> Documentation Prior To MSWPO');
            $(CtrlTrainingLevelLevel3IDs[j]).html('<i class="fa fa-file-text"></i> Documentation Prior To MSWPO');
        }
        if (value == 'T') {
            value = 'Trainee';
        }
    }
}

function PopulateLevel3ColumnValues(optrName,StationsCurrentLevel, StationsLevelDates) {

    if (optrName) {
        //List IDs to loop and query Sharepoint
        var CDSSLists = [PrimaryCDSSListID, SecondaryCDSSListID, AWTCDSSListID, DWBCDSSListID];
        //List Names to user in the URL construction
        var CDSSListNames = ["CDSS Primary Station Training Level 3", "CDSS Secondary Station  Training Level 3", "CDSS AWT Station  Training Level 3", "CDSS DWB Station  Training Level 3", ]
        //IDs of the table cells to populate
        var CDSSControlListIDs = ["PSLevel3CDSS", "SSLevel3CDSS", "AWTLevel3CDSS", "DWBLevel3CDSS"]

        PopulateColumnValues(optrName, CDSSLists, CDSSListNames, CDSSControlListIDs, StationsCurrentLevel, StationsLevelDates);

        //List IDs to loop and query Sharepoint
        var TaskStandardsLists = [PrimaryTaskStandardsID, SecondaryTaskStandardsID, AWTTaskStandardsID, DWBTaskStandardsID];
        //List Names to user in the URL construction
        var TaskStandardsNames = ["Primary Station Level 3 Task Standards  RRCLs", "Secondary Station Level 3 Task Standards  RRCLs", "AWT Station Level 3 Task Standards  RRCLs", "DWB Station Level 3 Task Standards  RRCLs", ]
        //IDs of the table cells to populate
        var TaskStandardsControlListIDs = ["PSLevel3TaskStandards", "SSLevel3TaskStandards", "AWTLevel3TaskStandards", "DWBLevel3TaskStandards"]
        PopulateColumnValues(optrName, TaskStandardsLists, TaskStandardsNames, TaskStandardsControlListIDs, StationsCurrentLevel, StationsLevelDates);


        //List IDs to loop and query Sharepoint
        var TrainingDocsLists = [PrimarytrainingDocsListID, SecondarytrainingDocsListID, AWTtrainingDocsListID, DWBtrainingDocsListID];
        //List Names to user in the URL construction
        var TrainingDocsNames = ["Primary Station  Level 3 Feeder Training Docs", "Secondary Station  Level 3 Feeder Training Docs", "AWT Station  Level 3 Feeder Training Docs", "DWB Station  Level 3 Feeder Training Docs", ]
        //IDs of the table cells to populate
        var TrainingDocsControlListIDs = ["PSLevel3TrainingDocs", "SSLevel3TrainingDocs", "AWTLevel3TrainingDocs", "DWBLevel3TrainingDocs"]
        PopulateColumnValues(optrName, TrainingDocsLists, TrainingDocsNames, TrainingDocsControlListIDs, StationsCurrentLevel, StationsLevelDates);

        //OverrideDefaultValues(StationsCurrentLevel, StationsLevelDates);

    }
}
function PopulateColumnValues(operatorName, Lists, ListName, ControlListID, StationsCurrentLevel, StationsLevelDates) {
    //Loop throught Lists by ID and check if the Form exists.
    //If Form exists populate the table cell with the Active Link
    //If NO Form give an option to the operator to send an email to Supervisor.
    for (var i = 0; i < Lists.length; i++) {
        console.log('1. Entering Populate Level3ColumnValues for' + Lists[i]);

        //Check if the operator exists
        var fetchValue = CheckIfOperatorAlreadyExists(operatorName, Lists[i], ListName[i], ControlListID[i]);

        //Make changes based on the result.
        fetchValue.done(function (result) {
            var returnedValue = result;
            var returnedArray = returnedValue.toString().split(",");
            //There is no Form
            if (returnedArray.length < 3) {
                console.log('No Form exists');
                $("#" + CTRLToPopulate).empty();
                //Get the control to Popuplate
                var CTRLToPopulate = returnedArray[0];
                var LstName = returnedArray[1];

                //Check if the list name has 'Training'
                substring = "Docs";
                var isTrainingList = LstName.indexOf(substring) > -1;
                if (isTrainingList == true) {
                    var newFormURL = 'https:\/\/arlingtonva.sharepoint.com\/sites\/wpcb\/mswpo\/Lists\/' + LstName + '\/NewForm.aspx';
                    //if ($("#" + CTRLToPopulate).html() == '') {
                        $("#" + CTRLToPopulate).html("<div style=\"margin-top: 6px;font-size: .9em;\"><a class=\"" + CTRLToPopulate.substring(0, 7) + "\" target=\"_blank\" href=\"" + newFormURL + "\" > <i class=\"fa fa-plus\"></i> Create New</a></div><div style=\"margin-top: 10px;font-size: .9em;\">Click to create new <br/> Training Documents Feeder Form</div>");
                   // }
                }
                else { // Common to CDSS and Task Standards
                    //Populate the table cell with and option to pop up modal to send email to Supervisor
                    var ModalToPopup = CTRLToPopulate + "Modal";
                   // if ($("#" + CTRLToPopulate).html() == '') {
                        $("#" + CTRLToPopulate).html("<div style=\"margin-top: 6px;font-size: .9em;\"><a class=\"" + CTRLToPopulate.substring(0, 7) + "\" onclick=\"PopulateModal('" + LstName + "')\"><i class=\"fa fa-envelope\"></i> Send Email</a></div> <div style=\"margin-top: 10px;font-size: .9em;\">Notify Supervisor to create <br/> a new CDSS Form </div>");
                   // }
                }
            }
            else //There is a  Form for operator
            {
                console.log('Form exists for this operator.');
                //Get the values from the returned Array
                var ItemEditID = returnedArray[0];
                var ModifiedDate = returnedArray[1];
                var ModifiedBy = returnedArray[2];
                var CTRLToPopulate = returnedArray[3];
                var LstName = returnedArray[4];
                //Create a link to edit link to the item
                //Add &source at the end which defines where ther operator lands after clicking save or cancel on  Form
                var URLToForm = 'https:\/\/arlingtonva.sharepoint.com\/sites\/wpcb\/mswpo\/Lists\/' + encodeURIComponent(LstName) + '\/EditForm.aspx?ID=' + ItemEditID + "&source=" + window.location.href;
                //Format modified as the default System Date has lot of unncessary strings
                var frmtModifiedDate = new Date(ModifiedDate);
                var validModifiedDate = (frmtModifiedDate.getMonth() + 1) + "/" + frmtModifiedDate.getDate() + "/" + frmtModifiedDate.getFullYear();
                //Populate the table cell with required HTML
               // if ($("#" + CTRLToPopulate).html() == '') {
                    $("#" + CTRLToPopulate).html("<div style=\"margin-top: 6px;font-size: .9em;\"><a href='" + URLToForm + "' class=\"" + CTRLToPopulate.substring(0, 7) + "\"><i class=\"fa fa-external-link\"></i> Open Form</a></div><div style=\"margin-top: 10px;font-size: .9em;\">Last Modified: " + validModifiedDate + "<br/>Last Modified By: " + ModifiedBy + "</div>");
               // }
                //Log values
                console.log('Returned list Arrray is' + ItemEditID + '-' + ModifiedDate + '-' + ModifiedBy + '-' + CTRLToPopulate + '-' + LstName);
            }

        });
        fetchValue.fail(function (result) {
            var error = result;
            console.log(error);
        });
    }
}
function RetrieveMSWPOSafetyTrainingInfo(operatorName) {
    //Using JQUERY Deferred
    var d = $.Deferred();
    //If in edit form
    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web()
        .get_lists()
        .getById(MSWPOSafetyTrainingCompletionListID);

    var camlQuery = new SP.CamlQuery();
    var CAMLQuery = '<View><Query> <Where> <Eq> <FieldRef Name=\'Operator_x0020_Look_x0020_up\' \/> <Value Type=\'Text\'>' + operatorName + '<\/Value> <\/Eq> <\/Where> <\/Query></View>';
    camlQuery.set_viewXml(CAMLQuery);

    MSWPOSafetyTrainingCompleteListInfo = oList.getItems(camlQuery);
    clientContext.load(MSWPOSafetyTrainingCompleteListInfo);

    var o = { d: d, MSWPOSafetyTrainingCompleteListInfo: MSWPOSafetyTrainingCompleteListInfo };
    clientContext.executeQueryAsync(Function.createDelegate(o, onretrieveMSWPOSafetTrainingInfoSuccess), Function.createDelegate(o, onretrieveMSWPOSafetTrainingInfoFailed));
    return d.promise();

    function onretrieveMSWPOSafetTrainingInfoSuccess() {

        var MSWPOSafetyTrainingCompleteListInfoEnumerator = this.MSWPOSafetyTrainingCompleteListInfo.getEnumerator();
        var resultCount = this.MSWPOSafetyTrainingCompleteListInfo.get_count();
        var TotalCompleted;
        var pastCurrentYearArray = [];
        if (resultCount > 0) {
            while (MSWPOSafetyTrainingCompleteListInfoEnumerator.moveNext()) {
                var currentYear = new Date().getFullYear();
                var pastYear = currentYear - 1;

                var oListItem = MSWPOSafetyTrainingCompleteListInfoEnumerator.get_current();
                var yearFromList = oListItem.get_item('Year');

                //Total Training Complete
                TotalCompleted = oListItem.get_item('_x0025__x0020_Total_x0020_Safety');

                if (currentYear == yearFromList) {
                    pastCurrentYearArray.push(parseInt(TotalCompleted));
                }
                if (pastYear == yearFromList) {
                    pastCurrentYearArray.push(parseInt(TotalCompleted));
                }

            }
            return this.d.resolve(pastCurrentYearArray);
        }
    }
    function onretrieveMSWPOSafetTrainingInfoFailed() {
        console.log('Request failed!');
    }
}

function FormatDate(unformattedDate) {
    var frmtModifiedDate = new Date(unformattedDate);
    var validModifiedDate = (frmtModifiedDate.getMonth() + 1) + "/" + frmtModifiedDate.getDate() + "/" + frmtModifiedDate.getFullYear();
    return validModifiedDate;
}
//Check if the Operator Already Exists
function CheckIfOperatorAlreadyExists(operatorName, ListID, ListName, CTRLToPopulate) {
    console.log('2. Entering CheckIfOperatorAlreadyExistsForCDSS for' + ListName);

    //Holds the items returned based on the CAML Query
    var itemsReturned;

    //Using JQUERY Deferred
    var d = $.Deferred();

    //Get the current SharePoint Client Content
    var clientContext = SP.ClientContext.get_current();

    //Get the list based on the parameter: CDSSListID
    var oList = clientContext.get_web()
         .get_lists()
        .getById(ListID);

    //Prepare the CAML Query
    substring = "Docs";
    var isTrainingList = ListName.indexOf(substring) > -1;
    var strCAML;
    if (isTrainingList == true) {
        strCAML = '<View><Query><Where><Eq><FieldRef Name=\'Title\' \/><Value Type=\'Text\'>' + operatorName + '<\/Value><\/Eq><\/Where><\/Query></View>';
    } else {
        strCAML = '<View><Query><Where><Eq><FieldRef Name=\'Employee_x0020_Name\' \/><Value Type=\'Text\'>' + operatorName + '<\/Value><\/Eq><\/Where><\/Query></View>';
    }

    //Set the CAML Query
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(strCAML);

    //Load the returned items based on the Query. Typically it should be only one value
    itemsReturned = oList.getItems(camlQuery);
    clientContext.load(itemsReturned);

    var o = { d: d, listOfItems: itemsReturned, clientContext: clientContext, CTRLToPopulate: CTRLToPopulate, ListName: ListName };
    clientContext.executeQueryAsync(Function.createDelegate(o, successCallback), Function.createDelegate(o, failCallback));

    return d.promise();

    //On success
    function successCallback() {
        //Get the count of items
        var itemCount = this.listOfItems.get_count();
        console.log('3. Entering successCallback and the item count is' + itemCount);
        if (itemCount == 0) {
            var resultArray = [this.CTRLToPopulate, this.ListName]
            this.d.resolve(resultArray);
        } else {

            var Level3ItemEnumerator = itemsReturned.getEnumerator();

            while (Level3ItemEnumerator.moveNext()) {
                //Get current Item
                var oListItem = Level3ItemEnumerator.get_current();

                //Get Current item ID
                var oListItemID = oListItem.get_item('ID');
                //Get Last Modified
                var oListItemLastModified = oListItem.get_item('Modified');
                //Get Last Modified By
                var oListItemLastModifiedBy = oListItem.get_item('Editor');

                //Log all values
                console.log('ID=' + oListItemID);
                console.log('Last Modified=' + oListItemLastModified);
                console.log('Last Modified By=' + oListItemLastModifiedBy.get_lookupValue());
            }

            //Prepare array to return on success.
            var resultArray = [oListItemID, oListItemLastModified, oListItemLastModifiedBy.get_lookupValue(), this.CTRLToPopulate, this.ListName]
            this.d.resolve(resultArray);
        }
    }

    //On Failure
    function failCallback() {
        this.d.reject('something bad happened');
        console.log('4. Entering failCallback and something went wrong');
    }
}
/*****2. End: Level 3 rows for each Panel*****/

/*****3. Start Populate DocumentSet URL *****/
function PopulateDocumentSetURL() {
    var operatorName = getUrlParameter('opname');
    if (operatorName) {
        var fetchValue = GetDocumentSetURL(operatorName);
        //Make changes based on the result.
        fetchValue.done(function (result) {
            var returnedValue = result;
            if (returnedValue == 'failed') {
                console.log('Could not retrieve document set URL');
            }
            else {
                $('#optrTrainingDocSet').attr('href', returnedValue);
            }
        });
    }
}
function GetDocumentSetURL(operatorName) {
    //Using JQUERY Deferred
    var d = $.Deferred();

    //1. Create client context based on the URL
    var clientContext = new SP.ClientContext.get_current();

    //2. Fetch the list that contains operators names.
    var oList = clientContext.get_web().get_lists().getById(docLibTrainingDocumentSetID);

    //3. Create a basic CAML query to query the list.
    var strcamlquery = "<View><Query> <Where> <Eq> <FieldRef Name=\'Title\' \/> <Value Type=\'Text\'>" + operatorName + "<\/Value> <\/Eq> <\/Where> <\/Query></View>";
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(strcamlquery);

    docitemsReturned = oList.getItems(camlQuery);
    clientContext.load(docitemsReturned);

    var o = { d: d, listOfItems: docitemsReturned, operatorName: operatorName };
    clientContext.executeQueryAsync(Function.createDelegate(o, successCallback), Function.createDelegate(o, failCallback));
    return d.promise();

    //Handle Succcess of retrieving operator list
    function successCallback() {
        //Get the count of items
        var itemCount = this.listOfItems.get_count();
        console.log('3. Entering successCallback and the item count is' + itemCount);
        if (itemCount == 0) {
            this.d.resolve('failed');
        } else {
            //Get the list enumerator.
            var listItemEnumerator = docitemsReturned.getEnumerator();
            while (listItemEnumerator.moveNext()) {
                var currentItem = listItemEnumerator.get_current();
                var oListItemID = currentItem.get_item('ID');
                var returnURL = "https:\/\/arlingtonva.sharepoint.com\/sites\/wpcb\/mswpo\/All%20MSWPO%20Training%20Documents\/Forms\/MSWPO%20Training%20Documents\/docsethomepage.aspx?ID=" + oListItemID + "&RootFolder=\/sites\/wpcb\/mswpo\/All%20MSWPO%20Training%20Documents\/" + encodeURIComponent(this.operatorName);
                console.log('ID=' + oListItemID);
                this.d.resolve(returnURL);
                console.log('URL=' + returnURL);
            }
        }
    }
    //Handle Failure of retrieving operator list
    function failCallback() {
        console.log('3. Entering failCallback - Something bad happened!');
    }
}
/*****3. End Populate DocumentSet URL *****/
/***** Start Send Email *****/
function SendSupervisorEmail(ModalToPopup) {
    var fromAddress = "sdakoju@arlingtonva.us";
    var toAddress = $("#" + ModalToPopup + "EmailTo").val();
    var ccAddress = $("#" + ModalToPopup + "EmailCC").val();
    var subject = $("#" + ModalToPopup + "EmailSubject").val();
    var body = $("#" + ModalToPopup + "EmailBody").html();
    var isSuccess = SendEmail(fromAddress, toAddress, ccAddress, subject, body);
    if (isSuccess == false) {
        alert('Email Sending Failed!');
        //TODO: Close Pop up window
    }
    else { alert('Email Sending Successfully!'); }
}
function SendEmail(fromAddress, toAddress, ccAddress, subject, body) {
    //Get the relative url of the site
    var siteurl = _spPageContextInfo.webServerRelativeUrl;
    var urlTemplate = siteurl + "/_api/SP.Utilities.Utility.SendEmail";
    $.ajax({
        contentType: 'application/json',
        url: urlTemplate,
        type: "POST",
        data: JSON.stringify({
            'properties': {
                '__metadata': {
                    'type': 'SP.Utilities.EmailProperties'
                },
                'From': fromAddress,
                'To': {
                    'results': [toAddress]
                },
                'Body': body,
                'CC': {
                    'results': [ccAddress]
                },
                'Subject': subject
            }
        }),
        headers: {
            "Accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
            "X-RequestDigest": jQuery("#__REQUESTDIGEST").val()
        },
        success: function (data) {
            return true;
            //fnOpenNormalMessage(sucessMessage, 'Email Successfully Sent!', 400, 225);
        },
        error: function (err) {
            return false;
            // console.log('Error in sending Email: ' + JSON.stringify(err));

        }
    });

}
/***** End Send Email *****/

/***** Start Utility Functions *****/
function PopulateModal(ListName) {
    var ModalToPopup = "GenericModal";//CTRLToPopulate + "Modal";
    var operatorName = getUrlParameter('opname');
    //Prepare for email
    var fromAddress = "sdakoju@arlingtonva.us";
    var toAddress = "sdakoju@arlingtonva.us";
    var ccAddress = "kgunnam@arlingtonva.us";
    var subject = "MSWPO:" + ListName + " for " + operatorName;
    var newFormURL = 'https:\/\/arlingtonva.sharepoint.com\/sites\/wpcb\/mswpo\/Lists\/' + ListName + '\/NewForm.aspx';
    var body = "Hi, <br/> <label style=\"font-family:'Segoe UI';font-size:1.0em !important\">Can you please create an new form for  " + operatorName + " for " + decodeURIComponent(ListName) + "?<br/><a href='" + newFormURL + "'>Click Here</a> <br/> Thank you,<br/>" + operatorName + "<label>";
    body = "<HTML><HEAD> <META name=GENERATOR content=\"MSHTML 10.00.9200.16843\"><\/HEAD><BODY>" + body + "<\/BODY><\/HTML>"

    $("#GenericModalEmailTo").attr('value', toAddress);
    $("#GenericModalEmailCC").attr('value', ccAddress);
    $("#GenericModalEmailSubject").attr('value', subject);
    $("#GenericModalEmailBody").html(body);

    //  $('#GenericModal .modal-body').html(html);
    $('#GenericModal').modal('show', { backdrop: 'static' });
}
function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            if (sParameterName[1] === undefined) {
                return true;
            }
            else {
                var returnValue = sParameterName[1].replace('+', ' ');
                return returnValue;
            }
            // return sParameterName[1] === undefined ? true : sParameterName[1].replace('+', ' ');
        }
    }
};
function GetTodayDateinMMDDYYYY() {
    var todaysDate = new Date();
    var curr_date = todaysDate.getDate();
    var curr_month = todaysDate.getMonth() + 1; //Months are zero based
    var curr_year = todaysDate.getFullYear();
    var strDate = curr_month + '/' + curr_date + '/' + curr_year;
    return strDate;
}


