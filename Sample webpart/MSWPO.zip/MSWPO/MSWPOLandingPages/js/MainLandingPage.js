﻿/*
Author: Susheel Dakoju
Date: 07/14/2016
Description: This script will get the name of the logged-in user and gets his role and influences 'Show my Options' on MSWPO Landing Page.
URL: https://arlingtonva.sharepoint.com/sites/wpcb/mswpo/SitePages/MSWPOLandingPage.aspx

Step 1. The script checks if the user is part of the MSWPO Access Management Configuration List and assigns the roles. There are two exceptions to this
    A. If a Supervisor falls under two roles, he will still be a Supervisor
    B. A trainer can also be an Operator so a unique role 'Trainer-Operator' is created with in the code and multiple options are displayed.
Step 2. If the user is not part of the list, it will check if the logged in person is part of the operator look up list, if he is 'Operator' roles is assigned, if NOT he is denied access.
*/

/********* Start List of IDs used  *********/
//MSWPO Access Management Configuration: 
var MSWPOAccessManagementList = "B441CA50-2EFB-425F-BF1B-E66EE18806B0"; //MSWPO Access Management Configuration : Contains various roles assigned: Supervisors, Management,Trainer, MSWPOAdmin
var operatorLookUpList = "F032B017-5260-492F-B72A-1A7E7FC31A23"; //Operator LookUp List : This list is used to check if the logged in person is part of the operator look up list
/********* End List of IDs used  *********/

/*-----------------------------------Start: List of operations on Page Load-----------------------------------------------------*/
SP.SOD.executeFunc('sp.js', 'SP.ClientContext', GetCurrentUserRole);
/*-----------------------------------End: List of operations on Page Load-----------------------------------------------------*/

//Get the current role of the logged in User
function GetCurrentUserRole() {

    var currentUserTitle = '';
    var currentUserRole = '';

    //Get the current user and get his title: i.e. First Name Last Name
    var fetchCurrentUser = GetCurrentUserInfo();

    fetchCurrentUser.done(function (result) {
        var returnedValue = result;
        //Get Current User Title
        currentUserTitle = returnedValue[1];
        //Call the actual method that retrieve the User Role
        var fetchCurrentRole = RetrieveCurrentUserRoleInfo(currentUserTitle);
        fetchCurrentRole.done(function (result) {
            //Role of the current User
            var returnedRole = result;
            //Construct the ID of the rows to display
            var trRole = "tr" + returnedRole;
            var trRoleNote = "tr" + returnedRole + "Note";
            var urlRole = trRole + "URL";
            //URL varies based on the logged in User
            var URL = '';
            var OperatorURL = '';
            var adminPageURL = '';
            var showOptions = true; // true by default; will be false if its visitor
            switch (returnedRole) {
                case 'Operator':
                    URL = "https://arlingtonva.sharepoint.com/sites/wpcb/mswpo/SitePages/OperatorLandingPage.aspx?opname=" + currentUserTitle;
                    break;
                case 'Supervisors':
                    URL = "https://arlingtonva.sharepoint.com/sites/wpcb/mswpo/SitePages/SupervisorLandingPage.aspx";
                    break;
                case 'MSWPOAdmin':
                    URL = "https://arlingtonva.sharepoint.com/sites/wpcb/mswpo/SitePages/MSWPOAdmin.aspx";
                    adminPageURL = "https://arlingtonva.sharepoint.com/sites/wpcb/mswpo/SitePages/ManagementLandingPage.aspx";
                    break;
                case 'Trainer':
                    URL = "https://arlingtonva.sharepoint.com/sites/wpcb/mswpo/SitePages/Trainerlandingpage.aspx";
                case 'Management':
                    URL = "https://arlingtonva.sharepoint.com/sites/wpcb/mswpo/SitePages/ManagementLandingPage.aspx";
                    break;
                case 'Trainer-Operator':
                    //This is for the trainer to go to his landing page
                    URL = "https://arlingtonva.sharepoint.com/sites/wpcb/mswpo/SitePages/Trainerlandingpage.aspx";
                    //Manually populate operator Info
                    OperatorURL = "https://arlingtonva.sharepoint.com/sites/wpcb/mswpo/SitePages/OperatorLandingPage.aspx?opname=" + currentUserTitle;
                    break;
                case 'Visitor':
                    showOptions = false;
                    break;
                default:
                    showOptions = false;
                    break;
            }

            if (showOptions == true) {// System identified in one of the roles
                if (returnedRole == 'Trainer-Operator') {
                    //Manually Populate for Trainer if he is an operator as well
                    $("#trTrainerURL").attr("href", URL);
                    $("#trTrainer").attr("style", "display: block;");
                    $("#trTrainerNote").attr("style", "display: block;background-color:#c65400;color:white;");

                    //Manually Populate for Trainer if he is an operator as well
                    $("#trOperatorURL").attr("href", OperatorURL);
                    $("#trOperator").attr("style", "display: block;");
                    $("#trOperatorNote").attr("style", "display: block;background-color:#ad9f00;color:white;");
                }
                else if (returnedRole == 'MSWPOAdmin' && currentUserTitle == 'Frank Corsoro') {
                    //Manually Populate for Trainer if he is an operator as well
                    $("#trManagementURL").attr("href", adminPageURL);
                    $("#trManagement").attr("style", "display: block;");
                    $("#trManagementNote").attr("style", "display: block;background-color:#c65400;color:white;");

                    //Manually Populate for Trainer if he is an operator as well
                    $("#trMSWPOAdminURL").attr("href", URL);
                    $("#trMSWPOAdmin").attr("style", "display: block;");
                    $("#trMSWPOAdminNote").attr("style", "display: block;background-color:#ad9f00;color:white;");
                }
                else {
                    //For all other roles except Trainer-Operator role.
                    $("#" + urlRole).attr("href", URL);
                    $("#" + trRole).attr("style", "display: block;");
                    $("#" + trRoleNote).attr("style", "display: block;background-color:#c65400;color:white;");
                }
            }
            else { // Visitor
                $("#trAccessDenied").attr("style", "display: block;");
            }

        });
        fetchCurrentRole.fail(function (result) {
            var error = result;
            console.log(error);
        });

    });
    fetchCurrentUser.fail(function (result) {
        var error = result;
        console.log(error);
    });
}
//This methods fetches current user email and title
function GetCurrentUserInfo() {

    var d = $.Deferred();
    var context = new SP.ClientContext.get_current();
    var web = context.get_web();
    var currentUser = web.get_currentUser();
    currentUser.retrieve();
    context.load(web);

    var o = { d: d, web: web };
    context.executeQueryAsync(Function.createDelegate(o, onQuerySucceeded), Function.createDelegate(o, onQueryFailed));

    return d.promise();

    function onQuerySucceeded(sender, args) {
        var returnArray = [];

        var currentUser = this.web.get_currentUser();
        var email = currentUser.get_email();
        var Title = currentUser.get_title();
        returnArray[0] = email;
        returnArray[1] = Title;

        //var id = currentUser.get_id();
        //var loginName = currentUser.get_loginName();

        //Construch the array to be returned.
        this.d.resolve(returnArray);

        console.log('Email is ' + email);
        console.log('Title is ' + Title);
    }
    function onQueryFailed(sender, args) {
        alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}
//Method that returns actual role of the logged in user.
function RetrieveCurrentUserRoleInfo(currentUserTitle) {
    var d1 = $.Deferred();
    //Following are basic sharepoint JSOM Operations and are self-explanatory
    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web().get_lists().getById(MSWPOAccessManagementList); // Call Operator Certification and Employee Data
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml();

    var currentUserRoleInfo = oList.getItems(camlQuery);
    clientContext.load(currentUserRoleInfo);

    var o = { d1: d1, currentUserRoleInfo: currentUserRoleInfo, currentUserTitle: currentUserTitle };
    clientContext.executeQueryAsync(Function.createDelegate(o, onretrieveOperatorInfoQuerySucceeded), Function.createDelegate(o, onretrieveOperatorInfoQueryFailed));

    return d1.promise();

    function onretrieveOperatorInfoQuerySucceeded() {

        var totalGroupRoleInfoCount = this.currentUserRoleInfo.get_count();

        var resolvedGroupName = '';

        if (totalGroupRoleInfoCount == 0) {
            console.log("Something went wrong, could not fetch group and role info.");
        } else {
            console.log("Fetched Group and Role info.");
            
            var totalGroupRoleInfoItemEnumerator = currentUserRoleInfo.getEnumerator();

            //Loop through the list and get the role assigned.
            while (totalGroupRoleInfoItemEnumerator.moveNext()) {
                //Get the current list item
                var oListItem = totalGroupRoleInfoItemEnumerator.get_current();
                //Get all the member of the Group Name
                var members = oListItem.get_item('Group_x0020_Members');

                //Get the name of the group from the 'Title' Column
                var groupName = oListItem.get_item('Title');
                //Members >0
                if (!!members) {
                    if (members.length > 0) {
                        for (var i = 0; i < members.length; i++) {
                            var title = members[i].get_lookupValue();
                            if (title == this.currentUserTitle) {
                                if (resolvedGroupName == "Supervisors")
                                {
                                    break;
                                }
                                resolvedGroupName = groupName;
                            }
                        }
                    }
                }
            }
            //Prepare to return on success.
            if (resolvedGroupName) { // user found in one of the roles
                if (resolvedGroupName == 'Trainer') {
                    //Check if the Trainer is also an operator
                    var checkOperatorFetchValue = CheckIfOperator(currentUserTitle);
                    checkOperatorFetchValue.done(function (result) {
                        var returnedValue = result;
                        if (returnedValue == 'true') { //recognized as operator
                            d1.resolve('Trainer-Operator');
                        }
                        else {
                            d1.resolve('Trainer');
                        }
                    });
                    checkOperatorFetchValue.fail(function (result) {
                        var error = result;
                        console.log(error);
                    });
                }
                else {
                    //All groups except for Trainer
                    d1.resolve(resolvedGroupName);
                }
            }
            else { //Check if the logged in user is operator
                var checkOperatorFetchValue = CheckIfOperator(currentUserTitle);

                checkOperatorFetchValue.done(function (result) {
                    var returnedValue = result;

                    if (returnedValue == 'true') { //recognized as operator
                        d1.resolve('Operator');
                    }
                    else {
                        d1.resolve('Visitor');
                    }

                });
                checkOperatorFetchValue.fail(function (result) {
                    var error = result;
                    console.log(error);
                });
            }
        }
    }
    function onretrieveOperatorInfoQueryFailed() {
        console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}
//Checks if the logged in user is in Operator Look Up list.
function CheckIfOperator(currentUserTitle) {
    var d = $.Deferred();
    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web().get_lists().getById(operatorLookUpList);

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(
        '<View><Query> <Where> <Eq> <FieldRef Name=\'Operator_x0020_Name\' \/> <Value Type=\'Text\'>' + currentUserTitle + '<\/Value> <\/Eq> <\/Where> <\/Query></View>'
    );
    var currentUserInfo = oList.getItems(camlQuery);
    clientContext.load(currentUserInfo);

    var o = { d: d, currentUserInfo: currentUserInfo, currentUserTitle: currentUserTitle };
    clientContext.executeQueryAsync(Function.createDelegate(o, onretrieveOperatorInfoQuerySucceeded), Function.createDelegate(o, onretrieveOperatorInfoQueryFailed));

    return d.promise();

    function onretrieveOperatorInfoQuerySucceeded() {
        var totalResultCount = currentUserInfo.get_count();
        if (totalResultCount == 0) {
            console.log("User found in Operator Certification and Employee Data");
            d.resolve('false');
        } else {
            console.log("User found in Operator Certification and Employee Data");
            d.resolve('true');
        }
    }
    function onretrieveOperatorInfoQueryFailed() {
        console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}
