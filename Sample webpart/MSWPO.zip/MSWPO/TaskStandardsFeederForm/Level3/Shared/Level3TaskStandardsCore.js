var currentFormUniqueId;
var currentFormWebPartId;
var currentLocation = window.location.href;
//~site/SiteAssets/MSWPO/TaskStandardsFeederForm/PSLevel3TaskStandardsCore.js
 (function () {
     // jQuery library is required in this sample 
     // Fallback to loading jQuery from a CDN path if the local is unavailable 
     document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/JQuery/jquery-1.11.0.min.js"><\/script>');
     document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/JQuery/jquery-ui.js"> </script>');

     document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/JQuery/jquery.loading-indicator.min.js"> </script>');
     document.write('<link href="/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/JQuery/jquery.loading-indicator.css" type="text/css" rel="stylesheet" />');

     document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/TaskStandardsFeederForm/Level3/Shared/TaskStandardsPreRender.js"> </script>');


     function _registerAccordionViewTemplate() {

         // Create object that have the context information about the field that we want to change it's output render  
         var trainingDocsFeederFormContext = {};
         trainingDocsFeederFormContext.Templates = {};

         // Add OnPostRender event handler to add accordion click events and style 
         trainingDocsFeederFormContext.OnPreRender = trainingDocsFeederFormOnPreRender;
         trainingDocsFeederFormContext.OnPostRender = trainingDocsFeederFormPostRender;

         SPClientTemplates.TemplateManager.RegisterTemplateOverrides(trainingDocsFeederFormContext);
     }

     function trainingDocsFeederFormOnPreRender(ctx) {
         if (!currentFormUniqueId) {
             //Get the current form Unique ID
             currentFormUniqueId = ctx.FormUniqueId;

             //Get the Current from WebPart Id
             currentFormWebPartId = "WebPart" + ctx.FormUniqueId;

             jQuery(document).ready(function () {
                 var formURL = GetFormURL();
                 //Add the new HTML created for accordion at the top of the web part
                 $.get(formURL, function (data, status) {
                     jQuery("#" + currentFormWebPartId).prepend(data);
                 });
             });
         }
     }
     function trainingDocsFeederFormPostRender(ctx) {
     }
     ExecuteOrDelayUntilScriptLoaded(_registerAccordionViewTemplate, 'clienttemplates.js');
 })();


 function GetFormURL() {
     if (document.location.href.indexOf('Primary') != -1) {
         return '/sites/wpcb/mswpo/SiteAssets/MSWPO/TaskStandardsFeederForm/Level3/PSLevel3TaskStandards.html';
     }
     if (document.location.href.indexOf('Secondary') != -1) {
         return '/sites/wpcb/mswpo/SiteAssets/MSWPO/TaskStandardsFeederForm/Level3/SSLevel3TaskStandards.html';
     }
     if (document.location.href.indexOf('DWB') != -1) {
         return '/sites/wpcb/mswpo/SiteAssets/MSWPO/TaskStandardsFeederForm/Level3/DWBLevel3TaskStandards.html';
     }
     if (document.location.href.indexOf('AWT') != -1) {
         return '/sites/wpcb/mswpo/SiteAssets/MSWPO/TaskStandardsFeederForm/Level3/AWTLevel3TaskStandards.html';
     }
 }