﻿var siteUrl = '/sites/wpcb/mswpo/';
var operatorLevelInfo;
var availableOperators = [];
var operatorsListID = '68C451AE-426B-4CFA-B2DC-B101D8D115DF';//Operator Certification and Employee Data


ExecuteOrDelayUntilBodyLoaded(LoadIndicator);

function LoadIndicator() {

    //The following line makes sure there is no conflict between version used in the SharePoint master page and version used for this page.
    $.noConflict();

    $('.ms-formtable').css("display", "none");;
    $(".ms-descriptiontext").css("display", "none");
    try {
        $(function () {
            var homeLoader = $('body').loadingIndicator({
                useImage: false,
            }).data("loadingIndicator");

            setTimeout(function () {
                homeLoader.hide();
            }, 3000);

        });
        $(document).ready(function () {
            SP.SOD.executeOrDelayUntilScriptLoaded(PopulateOperatorList, 'sp.js');
        })

    } catch (err) {
        console.log('Error at LoadIndicator' + err.message);
    }
}

/* Populates the list of operators */
function PopulateOperatorList() {
    $('.ms-formtable').css("display", "none");;
    $(".ms-descriptiontext").css("display", "none");
    //Get the sharepoint context based on the SiteUrl
    var clientContext = new SP.ClientContext(siteUrl);

    //Find the list to fetch the operators based on the GUID
    var oList = clientContext.get_web()
        .get_lists()
        .getById(operatorsListID);

    //Create a CAML Query
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View><Query> <Where><Neq><FieldRef Name=\'Status\'></FieldRef><Value Type=\'Choice\'>Inactive</Value></Neq></Where><OrderBy> <FieldRef Name=\'System_x0020_Defined_x0020_Opera\' Ascending=\'True\' /></OrderBy></Query></View>'
    );

    //Fetch the operator information using the CAML Query.
    operatorLevelInfo = oList.getItems(camlQuery);
    clientContext.load(operatorLevelInfo);

    //Make the asychronous call.
    clientContext.executeQueryAsync(Function.createDelegate(this, this.OnOperatorListInfoQuerySucceeded),
        Function.createDelegate(this, this.OnOperatorListOperatorInfoQueryFailed)
    );
}

//Query Succeeded.
function OnOperatorListInfoQuerySucceeded(sender, args) {
    var listItemEnumerator = operatorLevelInfo.getEnumerator();
    var totalOperatorCount = operatorLevelInfo.get_count();
    var availableOperators = [];

    if (totalOperatorCount == 0) {
        alert('Could not fetch operator info');
    }
    else {
        console.log('Entered TotalOperatorcount > 0')
        while (listItemEnumerator.moveNext()) {
            var oListItem = listItemEnumerator.get_current();

            //Fetch the operator title.
            var operatorName = oListItem.get_item('System_x0020_Defined_x0020_Opera').get_lookupValue();
            //Check if the operator is already in the array and avoid if ture.
            if (jQuery.inArray(operatorName, availableOperators) == -1) {
                availableOperators.push(operatorName);
            }
        }
    }
    //Use JQuery Autocomplete feature and provide with Available Operators.
    $("#operatorList").autocomplete({
        source: availableOperators
    });
}

//Query Failed.
function OnOperatorListOperatorInfoQueryFailed(sender, args) {
    console.log('Request failed in Level3CDSSPreRender ' + args.get_message() + '\n' + args.get_stackTrace());
}


