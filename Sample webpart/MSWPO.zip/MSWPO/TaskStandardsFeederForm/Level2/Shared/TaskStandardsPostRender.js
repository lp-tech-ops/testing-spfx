﻿var PrimaryTaskStandardsID = "C5588CD5-0CC4-4B2D-AAC7-2281AA41C353";  //Title=Primary Station Level 2 Task Standards - (Mini-Mods)
var SecondaryTaskStandardsID = "8918815A-B12C-4741-B024-957895254CCE";  //Title=Secondary Station Level 2 Task Standards - (Mini-Mods)
var AWTTaskStandardsID = "2D185A32-A228-4FB7-8E31-E43B20666AC4";  //Title=AWT Station Level 2 Task Standards - (Mini-Mods)
var DWBTaskStandardsID = "13E69C0A-F5C5-4E61-8F59-CE5C1221725D";  //Title=DWB Station Level 2 Task Standards - (Mini-Mods)

//PrimaryStation
var PrimaryFTControls = "DAFTFTPassFail,FEQFTPassFail,FMRLSFTPassFail,NFFFTPassFail,PCLFTPassFail,PGTBFTPassFail,PTBFTPassFail,PTBBACKUPFTPassFail,PYPSFTPassFail,RIPSFTPassFail,SSTFTPassFail,StationOverviewFTPassFail";
var PrimaryWTControls = "DAFTWTPassFail,FEQWTPassFail,FMRLSWTPassFail,NFFWTPassFail,PCLWTPassFail,PGTBWTPassFail,PTBWTPassFail,PTBBACKUPWTPassFail,PYPSWTPassFail,RIPSWTPassFail,SSTWTPassFail,StationOverviewWTPassFail";
//Secondary
var SecondaryFTControls = "ASE1FTPassFail,ASE2FTPassFail,DCBFTPassFail,EFDSFTPassFail,FCPSFTPassFail,SATFTPassFail,SBBFTPassFail,SCLFTPassFail,SFFFTPassFail,SGFFTPassFail,SPSBFTPassFail,SWPSFTPassFail,WFDSFTPassFail,WFFFTPassFail,WSPSBFTPassFail,StationOverviewFTPassFail";
var SecondaryWTControls = "ASE1WTPassFail,ASE2WTPassFail,DCBWTPassFail,EFDSWTPassFail,FCPSWTPassFail,SATWTPassFail,SBBWTPassFail,SCLWTPassFail,SFFWTPassFail,SGFWTPassFail,SPSBWTPassFail,SWPSWTPassFail,WFDSWTPassFail,WFFWTPassFail,WSPSBWTPassFail,StationOverviewWTPassFail";
//AWT
var AWTFTControls = "ABWBFTPassFail,CCTFTPassFail,FADFFTPassFail,MFFFTPassFail,PAFFTPassFail,PEWFFTPassFail,SHFFTPassFail,WWFFFTPassFail,Station OverviewFTPassFail";
var AWTWTControls = "ABWBWTPassFail,CCTWTPassFail,FADFWTPassFail,MFFWTPassFail,PAFWTPassFail,PEWFWTPassFail,SHFWTPassFail,WWFFWTPassFail,Station OverviewWTPassFail";
//DWB

var DWBFTControls = "DWBFTPassFail,BIOHHMFTPassFail,Station OverviewFTPassFail,General PlantFTPassFail,UtilitiesFTPassFail";
var DWBWTControls = "DWBWTPassFail,BIOHHMWTPassFail,Station OverviewWTPassFail,General PlantWTPassFail,UtilitiesWTPassFail";

$(document).ready(function () {
    hideDisableEnableElements();
    $("input[title='FTSummaryPercent']").prop("disabled", "disabled");
    $("input[title='WTSummaryPercent']").prop("disabled", "disabled");
    $("input[title='TotalAreas']").prop("disabled", "disabled");
    var totalAreas = $("input[title='TotalAreas']").val();
    var watermark = 'Please type operator name';
    $('#operatorList').blur(function () {
        if ($(this).val().length == 0)
            $(this).val(watermark).addClass('watermark');
    }).focus(function () {
        if ($(this).val() == watermark)
            $(this).val('').removeClass('watermark');
    }).val(watermark).addClass('watermark');


    $('#btnGetOperatorInfo').click(function () {
        var operatorName = $('#operatorList').val();
        if (operatorName.trim() && operatorName.trim() != 'Please type operator name') {
            var fetchValue = CheckIfOperatorAlreadyExists(operatorName);
            fetchValue.done(function (result) {
                var returnedValue = result;
                if (returnedValue == 'true') {
                    fnOpenNormalMessage('Feeder form already exists for this operator.', 'Error:', 800, 400);
                } else {
                    AutoFillOperatorInfo(operatorName);
                }
            });
            fetchValue.fail(function (result) {
                var error = result;
                console.log(error);
            });
        }
        else {
            fnOpenNormalMessage('Please enter an Operator Name', 'Error:', 800, 400);
        }
    });
    debugger;
    var FTControlsArray = GetArrayListID('FT');
    for (var i = 0; i < FTControlsArray.length; i++) {
        var controlReadName = 'select[title=\'' + FTControlsArray[i] + '\']';
        $(controlReadName).bind("change", function () {
            PopulateFTSummary();
        });
    }
    var WTControlsArray = GetArrayListID('WT');
    for (var i = 0; i < WTControlsArray.length; i++) {
        var controlReadName = 'select[title=\'' + WTControlsArray[i] + '\']';
        $(controlReadName).bind("change", function () {
            PopulateWTSummary();
        });
    }

    function PopulateFTSummary() {
        var passCount = 0;
        debugger;
        for (var i = 0; i < FTControlsArray.length; i++) {
            var controlReadName = 'select[title=\'' + FTControlsArray[i] + '\']';
            if ($(controlReadName).find(":selected").text() == "Pass") {
                passCount = passCount + 1;
            }
        }
        var totalPassCount = passCount + '/' + totalAreas;
        $("input[title='FTSummaryPercent']").val(totalPassCount);

    }

    function PopulateWTSummary() {
        var passCount = 0;
        for (var i = 0; i < WTControlsArray.length; i++) {
            var controlReadName = 'select[title=\'' + WTControlsArray[i] + '\']';
            if ($(controlReadName).find(":selected").text() == "Pass") {
                passCount = passCount + 1;
            }
        }
        var totalPassCount = passCount + '/' + totalAreas;
        $("input[title='WTSummaryPercent']").val(totalPassCount);
    }
});


function hideDisableEnableElements() {

    if (currentLocation.indexOf("DispForm.aspx") != -1 || currentLocation.indexOf("EditForm.aspx") != -1) {
        $('#trOperatorInfo').hide();
        $("input[title='Date']").parent().next().closest('td').find("img:first").css('display', 'none');
    }
    if (currentLocation.indexOf("EditForm.aspx") != -1 || currentLocation.indexOf("NewForm.aspx") != -1) {
        //disable
        $("input[title='Employee Name Required Field']").prop('disabled', true);
        $("input[title='Current Level']").prop('disabled', true);
        $("input[title='Training Level']").prop('disabled', true);
    }
    if (currentLocation.indexOf("DispForm.aspx") != -1 || currentLocation.indexOf("NewForm.aspx") != -1) {
        $('#print').hide();
        $('#email').hide();
    }

    if (currentLocation.indexOf("NewForm.aspx") != -1) {
        var operatorName = getUrlParameter('opname')
        console.log(operatorName);
        if (operatorName) { //operator name passed via URL
            //Hide option to select the operator again
            $('#trOperatorInfo').hide();
            AutoFillOperatorInfo(operatorName);
        }
        else {
            $('#trOperatorInfo').show();
        }
    }

    if (currentLocation.indexOf("EditForm.aspx") != -1) {

        $("input[title='Employee Name Required Field']").prop('disabled', true);
        $("input[title='Date']").prop('disabled', true);
        var supervisorSignOffDate = $('input[Title="Supervisor Signoff Date"]').val();

        if (supervisorSignOffDate) {
            $("#accordion input").attr("disabled", "disabled");
            $("#accordion textarea").attr("disabled", "disabled");
            $("#accordion select").attr("disabled", "disabled");
            $("#accordion [role='textbox']").attr("disabled", "disabled");
            var edit = document.getElementById("Ribbon.ListForm.Edit.Commit.Publish-Large");
            edit.style.display = "none";
            $("input[value$='Save']").attr('disabled', true);
        }
    }
}

function getUrlParameter(sParam) {
    name = sParam;
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]"); var regexS = "[\\?&]" + name + "=([^&#]*)"; var regex

    = new RegExp(regexS); var results = regex.exec(window.location.href); if (results == null) return ""; else return decodeURIComponent(results

    [1].replace(/\+/g, " "));
};

function AutoFillOperatorInfo(operatorName) {
    $("input[title='Employee Name Required Field']").val(operatorName);
    $("input[title='Employee Name Required Field']").prop('disabled', true);

    $("input[title='Current Level']").val('Level 3');
    $("input[title='Current Level']").prop('disabled', true);

    $("input[title='Training Level']").val('Level 2');
    $("input[title='Training Level']").prop('disabled', true);
}

function CheckIfOperatorAlreadyExists(operatorName) {

    var d = $.Deferred();

    var clientContext = SP.ClientContext.get_current();
    var currentListID = GetCurrentListID();
    var oList = clientContext.get_web()
         .get_lists()
        .getById(currentListID);
    var strCAML = '<View><Query><Where><Eq><FieldRef Name=\'Employee_x0020_Name\' \/><Value Type=\'Text\'>' + operatorName + '<\/Value><\/Eq><\/Where><\/Query></View>';
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(strCAML);

    var itemsReturned = oList.getItems(camlQuery);
    clientContext.load(itemsReturned);

    var o = { d: d, listOfItems: itemsReturned, clientContext: clientContext };
    clientContext.executeQueryAsync(Function.createDelegate(o, successCallback), Function.createDelegate(o, failCallback));

    return d.promise();

    function successCallback() {
        var itemCount = this.listOfItems.get_count();
        console.log(itemCount);
        if (itemCount == 0) {
            this.d.resolve('false');
        } else {
            this.d.resolve('true');
        }
    }
    function failCallback() {
        this.d.reject('something bad happened');
    }
}

/* The following part of the code is not used. But may require in future to pull other information about operator */
function retrieveOperatorInfo(optrName) {
    var clientContext = new SP.ClientContext(siteUrl);
    var oList = clientContext.get_web()
         .get_lists()
        .getById(operatorsListID);

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(
        '<View><Query><Where><Eq><FieldRef Name=\'Title\'/><Value Type=\'Text\'>' + optrName + '</Value></Eq></Where><OrderBy> <FieldRef Name=\'Primary_x0020_Station\' Ascending=\'True\' \/> <\/OrderBy></Query></View>'
    );
    operatorLevelInfo = oList.getItems(camlQuery);
    clientContext.load(operatorLevelInfo);
    clientContext.executeQueryAsync(Function.createDelegate(this, this.onretrieveOperatorInfoQuerySucceeded),
        Function.createDelegate(this, this.onretrieveOperatorInfoQueryFailed)
    );
}
function onretrieveOperatorInfoQuerySucceeded(sender, args) {
    var listLevel1ItemEnumerator = operatorLevelInfo.getEnumerator();
    var totalOperatorCount = operatorLevelInfo.get_count();

    if (totalOperatorCount == 0) {
        alert('Could not fetch operator info');
    } else {
        while (listLevel1ItemEnumerator.moveNext()) {
            var oListItem = listLevel1ItemEnumerator.get_current();
            var operatorName = oListItem.get_item('Title');

            $("input[title='Employee Name Required Field']").val(operatorName);
            $("input[title='Employee Name Required Field']").prop('disabled', true);

            $("input[title='Current Level']").val('Level 3');
            $("input[title='Current Level']").prop('disabled', true);

            $("input[title='Training Level']").val('Level 2');
            $("input[title='Training Level']").prop('disabled', true);
        }
    }
}
function onretrieveOperatorInfoQueryFailed(sender, args) {
    alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
}


function GetCurrentListID() {
    if (document.location.href.indexOf('Primary') != -1) {
        return PrimaryTaskStandardsID;
    }
    if (document.location.href.indexOf('Secondary') != -1) {
        return SecondaryTaskStandardsID;
    }
    if (document.location.href.indexOf('DWB') != -1) {
        return DWBTaskStandardsID;
    }
    if (document.location.href.indexOf('AWT') != -1) {
        return AWTTaskStandardsID;
    }
}
function GetArrayListID(testType) {
    debugger;
    if (document.location.href.indexOf('Primary') != -1) {
        if(testType == 'FT')
        {
            return PrimaryFTControls.split(',');
        }
        else
        {
            return PrimaryWTControls.split(',');
        }
    }
    if (document.location.href.indexOf('Secondary') != -1) {
        if(testType == 'FT')
        {
            return SecondaryFTControls.split(',');
        }
        else
        {
            return SecondaryWTControls.split(',');
        }
    }
    if (document.location.href.indexOf('DWB') != -1) {
        if (testType == 'FT') {
            return DWBFTControls.split(',');
        }
        else {
            return DWBWTControls.split(',');
        }
    }
    if (document.location.href.indexOf('AWT') != -1) {
        if (testType == 'FT') {
            return AWTFTControls.split(',');
        }
        else {
            return AWTWTControls.split(',');
        }
    }
}

$("#print").click(function () {
    $(".ui-accordion-content").show();
    // Print the page
    window.print();
});

$("#collapseAll").click(function () {
    $(".ui-accordion-content").hide()
});

$("#expandAll").click(function () {
    $(".ui-accordion-content").show()
});


$("#email").click(function () {
    processSendEmails();
});

function processSendEmails() {
    var p = getUserEmail();
    p.done(function (result) {
        var employeeName = $('input[Title="Employee Name Required Field"]').val();
        if (result) {
            var from = result,
                to = result,
                body = 'MSWPO: Primary Station- Level 2- Task Standards (Mini-Mods) for :' + '<a href="' + window.location.href + '">' + employeeName + '</a>';
            subject = 'MSWPO: Primary Station- Level 2- Task Standards (Mini-Mods) for' + employeeName;
            sucessMessage = 'Please check your inbox. An email has been sent successfully to you!';
            // Call sendEmail function
            sendEmail(from, to, body, subject, sucessMessage);
        }
    });

}

function getUserEmail() {
    var d = $.Deferred();
    var email;
    var context = new SP.ClientContext.get_current();
    var web = context.get_web();
    var currentUser = web.get_currentUser();
    currentUser.retrieve();
    context.load(web);

    var o = { d: d, web: web, email: email };
    context.executeQueryAsync(Function.createDelegate(o, successCallback), Function.createDelegate(o, failCallback));

    function successCallback() {
        var userObject = this.web.get_currentUser();
        this.email = userObject.get_email();
        this.d.resolve(this.email);
    }
    function failCallback() {
        this.d.reject("something bad happened");
    }
    return d.promise();
}

function sendEmail(from, to, body, subject, sucessMessage) {
    //Get the relative url of the site
    var siteurl = _spPageContextInfo.webServerRelativeUrl;
    var urlTemplate = siteurl + "/_api/SP.Utilities.Utility.SendEmail";
    $.ajax({
        contentType: 'application/json',
        url: urlTemplate,
        type: "POST",
        data: JSON.stringify({
            'properties': {
                '__metadata': {
                    'type': 'SP.Utilities.EmailProperties'
                },
                'From': from,
                'To': {
                    'results': [to]
                },
                'Body': body,
                'Subject': subject
            }
        }),
        headers: {
            "Accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
            "X-RequestDigest": jQuery("#__REQUESTDIGEST").val()
        },
        success: function (data) {
            fnOpenNormalMessage(sucessMessage, 'Email Successfully Sent!', 400, 225);
        },
        error: function (err) {
            fnOpenNormalMessage('Error in sending Email: ' + JSON.stringify(err), 'Error in sending Email:', 800, 400);
            if (to != "kgunnam@arlingtonva.us")
                sendEmail("kgunnam@arlingtonva.us", "kgunnam@arlingtonva.us", "", subject, body);
        }
    });
}

function fnOpenNormalMessage(messageBoxHTML, messagetitle, width, height) {
    $("#dialog-message").html(messageBoxHTML);
    $("#dialog-message").dialog({
        modal: true,
        title: messagetitle,
        width: '600px',
        dialogClass: 'main-dialog-class',
        buttons: {
            Ok: function () {
                $(this).dialog("close");
            }
        }
    });
}


function PreSaveItem() {
    var employeeName = $('input[Title="Employee Name Required Field"]').val();
    if (employeeName) { //If the employee name is empty do not save.
        return true; // allow save form
    }
    else {
        fnOpenNormalMessage('Please select an operator.', 'Error:', 800, 400);
        return false; // not allow save form
    }
}

