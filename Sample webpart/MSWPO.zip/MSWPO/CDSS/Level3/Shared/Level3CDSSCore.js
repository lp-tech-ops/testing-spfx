﻿var currentFormUniqueId;
var currentFormWebPartId;
var currentLocation = window.location.href;
(function () {
    // jQuery library is required in this sample 
    document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/JQuery/jquery-1.11.0.min.js"><\/script>');
    document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/JQuery/jquery-ui.js"> </script>');
                                
    document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/JQuery/jquery.loading-indicator.min.js"> </script>');
    document.write('<link href="/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/JQuery/jquery.loading-indicator.css" type="text/css" rel="stylesheet" />');
    //Populate the tab-3 of the Competencies section of the CDSS Form
     document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/CDSS/Level3/Shared/Level3CDSSPreRender.js"> </script>');

    
    function _registerAccordionViewTemplate() {
        // Create object that have the context information about the field that we want to change it's output render  
        var cdssFormContext = {};
        cdssFormContext.Templates = {};

        // Add OnPostRender event handler to add accordion click events and style 

        cdssFormContext.OnPreRender = CDSSFormOnPreRender;
        cdssFormContext.OnPostRender = CDSSFormOnPostRender;

        SPClientTemplates.TemplateManager.RegisterTemplateOverrides(cdssFormContext);
    }
    function CDSSFormOnPreRender(ctx) {
        if (!currentFormUniqueId) {
            //Get the current form Unique ID
            currentFormUniqueId = ctx.FormUniqueId;

            //Get the Current from WebPart Id
            currentFormWebPartId = "WebPart" + ctx.FormUniqueId;

            jQuery(document).ready(function () {
                var formURL = GetFormURL();
                console.log('Writing to logn'+ formURL);
                //Add the new HTML created for accordion at the top of the web part
                $.get(formURL, function (data, status) {
                    jQuery("#" + currentFormWebPartId).prepend(data);
                });
            });
        }
    }
    function CDSSFormOnPostRender(ctx) {

    }
    ExecuteOrDelayUntilScriptLoaded(_registerAccordionViewTemplate, 'clienttemplates.js');
})();

function GetFormURL()
{
    if (document.location.href.indexOf('Primary') !=-1) {
        return '/sites/wpcb/mswpo/SiteAssets/MSWPO/CDSS/Level3/PSLevel3CDSSForm.html';
    }
    if (document.location.href.indexOf('Secondary') !=-1) {
        return '/sites/wpcb/mswpo/SiteAssets/MSWPO/CDSS/Level3/SSLevel3CDSSForm.html';
    }
    if (document.location.href.indexOf('DWB') !=-1) {
        return '/sites/wpcb/mswpo/SiteAssets/MSWPO/CDSS/Level3/DWBLevel3CDSSForm.html';
    }
    if (document.location.href.indexOf('AWT') !=-1) {
        return '/sites/wpcb/mswpo/SiteAssets/MSWPO/CDSS/Level3/AWTLevel3CDSSForm.html';
    }
}

