﻿/*
Author: Susheel Dakoju
Date: 07/14/2016
Description:
- This is the common file shared accross all CDSS Forms for Level 3
- This script interacts with supporting feeder froms: Training Documents and Task Standards
- It also interacts with other supporting list to get Operator basic Information, Prerequisites (Duration and Training at Station), 
*/

//Information on this List Forms is pulled from multiple sites. 'Supervisor Station Assignment' list in 'Forms' site is used to pull the operator's time and training at each station.
var siteUrl = '/sites/wpcb/mswpo/';
var WPCBFormsUrl = '/sites/wpcb/forms/';

//Global variables
var trainingProgressInfo;
var taskStandardsListInfo;
var MSWPOSafetyTrainingCompleteListInfo;
var operatorStationAssignmentListInfo;
var operatorLevelInfo;
var DOCSummaryListInfo;
var operatorEmail = '';
var shiftSupervisorEmail = '';
//Array with default values
var libNames = ["Forms and Checklists",
      "System Operating Manuals",
      "Field SOPs",
      "Lab SOPs",
      "Mini Modules",
      "PCS Strategies"
]
var libInternalNames = ["OP_x0020_Forms_x0020_and_x0020_C1", //Forms and Checklists % Complete
      "m8q8", //System Operating Manuals % Complete
      "bpkx", //Field SOP % Complete
      "gijq", //Lab SOP % Complete
      "uc2x", //Mini Modules % Complete
      "xpyc", //PCS Strategies % Complete
      "s6oq"  //% Total Complete
]
var libTotalCountInternalNames = ["OP_x0020_Forms_x0020_and_x0020_C", //Forms and Checklists % Complete
      "iv1y", //System Operating Manuals % Complete
      "ljss", //Field SOP % Complete
      "tujv", //Lab SOP % Complete
      "ivxx", //Mini Modules % Complete
      "r07a", //PCS Strategies % Complete
      "s6oq"  //% Total Complete
]
var taskStandardNames = ["Chemicals", "Safety", "Specific Knowledge", "General"];

/*!*!*!*!*!*!*!*!*!*!*!*!*!*!*!*! Important MSWPO Admin Area ONLY: Start  *!*!*!*!*!*!*!*!*!*!*!*!*!*!*!*!*/
var OperationsManagerEmail = "Fcorsoro@arlingtonva.us";
var StandardFromAddress = "no-reply@sharepointonline.com";
//Use this to cc address to copied on all MSWPO communications.
var StandardCCAddress = "";
//Use this to cc all supervisors and operator: Copy supervisor email addresses only, operator value is dynamically fetched.
var CCAddressForCertification = "";
/*!*!*!*!*!*!*!*!*!*!*!*!*!*!*!*! Important MSWPO Admin Area ONLY: End  *!*!*!*!*!*!*!*!*!*!*!*!*!*!*!*!*/

/*=*=*=*=**=*=*=*=**=*=*=*=*  Start List of IDs used  *=*=*=*=**=*=*=*=**=*=*=*=*/
var operatorLookUpList = "F032B017-5260-492F-B72A-1A7E7FC31A23"; //Operator LookUp List
var MSWPOSafetyTrainingCompletionListID = "9E08D4B1-10E4-4E14-8E02-31C3379732C0"; //MSWPO Safety Training Completion List: Operator_x0020_Look_x0020_up
var operatorCetrificationEmployeeDataListID = '68C451AE-426B-4CFA-B2DC-B101D8D115DF'; //Operator Certification and Employee Data: System_x0020_Defined_x0020_Opera
//AWT and DWB Stations Only
var DOCDateSummaryListID = "D088C1C4-D8DD-4281-9E5C-62D2645CB84A";

PrimaryCDSSListID = "99fe0336-193e-42b6-83aa-ff7cc8f44183"    // Title=CDSS Primary Station Training Level 2
SecondaryCDSSListID = "D8F44610-ED6A-4063-BFCD-2C47339A179A"  // Title=CDSS- Secondary Station - Training Level 3
AWTCDSSListID = "AF8406F9-2ADB-4617-8FBB-EFA63275F563"         // Title=CDSS- AWT Station - Training Level 3
DWBCDSSListID = "8F4B7AA0-9E38-4207-AA8B-B6B379289B1D"// Title=CDSS- DWB Station - Training Level 3

PrimarytrainingDocsListID = "149e1017-cf92-45f2-b195-fe12a570f8f4" //Title=Primary Station - Level 2 Feeder Training Docs
SecondarytrainingDocsListID = "e12a45d2-8faa-43cd-847b-f04b8657a7a9" //Title=Secondary Station - Level 2 Feeder Training Docs
AWTtrainingDocsListID = "b65f8db5-051d-4cfc-b4fb-f33bae7084a0" // Title=AWT Station - Level 2 Feeder Training Docs
DWBtrainingDocsListID = "3674435a-0c3a-4a45-8c8d-81eb98335d13" //Title=DWB Station - Level 2 Feeder Training Docs

PrimaryTaskStandardsID = "c5588cd5-0cc4-4b2d-aac7-2281aa41c353";  //Title=Primary Station Level 2 Task Standards - MiniMods
SecondaryTaskStandardsID = "8918815a-b12c-4741-b024-957895254cce";  //Title=Secondary Station Level 2 Task Standards - MiniMods
AWTTaskStandardsID = "2d185a32-a228-4fb7-8e31-e43b20666ac4";  //Title=AWT Station Level 2 Task Standards - MiniMods
DWBTaskStandardsID = "13e69c0a-f5c5-4e61-8f59-ce5c1221725d";  //Title=DWB Station Level 2 Task Standards - MiniMods

PrimaryTaskStandardsEncodedLibraryName = "Primary%20Station%20Level%202%20Task%20Standards%20%20MiniMods";
SecondaryTaskStandardsEncodedLibraryName = "Secondary%20Station%20Level%202%20Task%20Standards%20%20MiniMods";
AWTTaskStandardsEncodedLibraryName = "AWT%20Station%20Level%202%20Task%20Standards%20%20MiniMods";
DWBTaskStandardsEncodedLibraryName = "DWB%20Station%20Level%202%20Task%20Standards%20%20MiniMods";

PrimarytrainingDocsLibraryName = "Primary Station  Level 2 Feeder Training Docs";
SecondarytrainingDocsLibraryName = "Secondary Station  Level 2 Feeder Training Docs";
DWBtrainingDocsLibraryName = "DWB Station  Level 2 Feeder Training Docs";
AWTtrainingDocsListLibraryName = "AWT Station  Level 2 Feeder Training Docs";
/*=*=*=*=**=*=*=*=**=*=*=*=* End List of IDs used  *=*=*=*=**=*=*=*=**=*=*=*=*/

/*-----------------------------------Start: List of operations on Page Load-----------------------------------------------------*/

SP.SOD.executeFunc('sp.js', 'SP.ClientContext', retrieveTrainingInfo);
SP.SOD.executeFunc('sp.js', 'SP.ClientContext', retrieveTaskStandardsInfo);
SP.SOD.executeFunc('sp.js', 'SP.ClientContext', retrieveMSWPOSafetTrainingInfo);
SP.SOD.executeFunc('sp.js', 'SP.ClientContext', PopulateForm);

/*-----------------------------------End: List of operations on Page Load-----------------------------------------------------*/

function PopulateForm() {
    debugger;
    //Check if the operator is certified
    var isOperatorCertified = $("input[title='CertifyOperator']").val();
    if (isOperatorCertified) {
        var edit = document.getElementById("Ribbon.ListForm.Edit.Commit.Publish-Large");
        edit.style.display = "none";
        $("input[value$='Save']").attr('disabled', true);

    }

   
}

$(document).ready(function () {
    //Water mark on select operator on CDSS Form
    var watermark = 'Please type operator name';
    $('#operatorList').blur(function () {
        if ($(this).val().length == 0)
            $(this).val(watermark).addClass('watermark');
    }).focus(function () {
        if ($(this).val() == watermark)
            $(this).val('').removeClass('watermark');
    }).val(watermark).addClass('watermark');
    var currentLocation = window.location.href;
    if (currentLocation.indexOf("NewForm.aspx") != -1) {
        var operatorName = getUrlParameter('opname')
        console.log(operatorName);
        if (operatorName) { //operator name passed via URL
            //Hide option to select the operator again
            $('#trSelectOperator').hide();
            AutoFillOperatorInfo(operatorName);
        }
        else {
            $('#trSelectOperator').show();
        }
    }
    hideDisableEnableElements();
});

/***** 1. Start Operator Basic Info and Auto fill *****/
function AutoFillOperatorInfo(operatorName) {
    if (operatorName.trim() && operatorName.trim() != 'Please type operator name') {
        var fetchValue = CheckIfOperatorAlreadyExists(operatorName);
        fetchValue.done(function (result) {
            var returnedValue = result;
            if (returnedValue == 'true') {
                fnOpenNormalMessage('CDSS form already exists for this operator.', 'Error:', 800, 400);
            } else {
                retrieveOperatorInfo(operatorName);
                retrieveTrainingInfo();
                retrieveTaskStandardsInfo();
                retrieveMSWPOSafetTrainingInfo();
            }
        });
        fetchValue.fail(function (result) {
            var error = result;
            console.log(error);
        });
    }
    else {
        fnOpenNormalMessage('Please enter an Operator Name', 'Error:', 800, 400);
    }
}
function CheckIfOperatorAlreadyExists(operatorName) {

    var d = $.Deferred();

    var clientContext = SP.ClientContext.get_current();
    var currentListID = GetCDSSListID();
    var oList = clientContext.get_web()
         .get_lists()
        .getById(currentListID);
    var strCAML = '<View><Query><Where><Eq><FieldRef Name=\'Employee_x0020_Name\' \/><Value Type=\'Text\'>' + operatorName + '<\/Value><\/Eq><\/Where><\/Query></View>';
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(strCAML);

    var itemsReturned = oList.getItems(camlQuery);
    clientContext.load(itemsReturned);

    var o = { d: d, listOfItems: itemsReturned, clientContext: clientContext };
    clientContext.executeQueryAsync(Function.createDelegate(o, successCallback), Function.createDelegate(o, failCallback));

    return d.promise();

    function successCallback() {
        var itemCount = this.listOfItems.get_count();
        if (itemCount == 0) {
            this.d.resolve('false');
        } else {
            this.d.resolve('true');
        }
    }
    function failCallback() {
        this.d.reject('something bad happened');
    }
}
function retrieveOperatorInfo(optrName) {
    var operatorExists = CheckIfOperatorAlreadyExists(optrName);
    if (operatorExists == "true") {
        fnOpenNormalMessage('Operator Already Exists', 'Note:', 500, 225);
    }
    if (operatorExists) {
        var clientContext = new SP.ClientContext(siteUrl);
        var oList = clientContext.get_web()
             .get_lists()
            .getById(operatorCetrificationEmployeeDataListID);

        var camlQuery = new SP.CamlQuery();
        camlQuery.set_viewXml(
            '<View><Query> <Where> <Eq> <FieldRef Name=\'System_x0020_Defined_x0020_Opera\' \/> <Value Type=\'Text\'>' + optrName + '<\/Value> <\/Eq> <\/Where> <\/Query></View>'
        );
        operatorLevelInfo = oList.getItems(camlQuery);
        clientContext.load(operatorLevelInfo);
        clientContext.executeQueryAsync(Function.createDelegate(this, this.onretrieveOperatorInfoQuerySucceeded), Function.createDelegate(this, this.onretrieveOperatorInfoQueryFailed));
    }
}
function onretrieveOperatorInfoQuerySucceeded(sender, args) {
    var totalOperatorCount = operatorLevelInfo.get_count();
    if (totalOperatorCount == 0) {
        fnOpenNormalMessage('Something went wrong, could not fetch operator info.', 'Error', 150, 40)
    } else {
        var listLevel1ItemEnumerator = operatorLevelInfo.getEnumerator();
        while (listLevel1ItemEnumerator.moveNext()) {
            var oListItem = listLevel1ItemEnumerator.get_current();
            var operatorName = oListItem.get_item('System_x0020_Defined_x0020_Opera').get_lookupValue();
            var HireDate = oListItem.get_item('Hire_x0020_Date');

            var Shift = oListItem.get_item('Shift');
            var ShiftSupervisor = oListItem.get_item('Shift_x0020_Supervisor');

            $("input[title='Current Level']").val('Level 3');
            $("input[title='Current Level']").prop('disabled', true);

            $("input[title='Shift Supervisor']").val(ShiftSupervisor);
            $("input[title='Shift Supervisor']").prop('disabled', true);

            $("input[title='Employee Name Required Field']").val(operatorName);
            $("input[title='Employee Name Required Field']").prop('disabled', true);

            var frmtHireDate = new Date(HireDate);
            var validHireDate = (frmtHireDate.getMonth() + 1) + "/" + frmtHireDate.getDate() + "/" + frmtHireDate.getFullYear();

            $("input[title='Hire Date']").val(validHireDate);
            $("input[title='Hire Date']").prop('disabled', true);

            $("input[title='Shift Name']").val(Shift);
            $("input[title='Shift Name']").prop('disabled', true);

            $("input[title='TrainingForLevel']").val('Level 2');
            $("input[title='TrainingForLevel']").prop('disabled', true);

            var stationName = GetStationName();
            $("input[title='Station Name']").val(stationName);
            $("input[title='Station Name']").prop('disabled', true);
            GetOperatorHours(operatorName);
        }
    }
}
function onretrieveOperatorInfoQueryFailed(sender, args) {
    alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
}
/***** 1. End Operator Basic Info and Auto fill *****/

/***** 2. Start Operator Hours at Station and Training Summary *****/
function retriveTrainingSummary(listID, siteURLofList) {
    debugger;
    var operatorName;
    //If in edit form
    if (currentLocation.indexOf("EditForm.aspx") != -1 || currentLocation.indexOf("NewForm.aspx") != -1) {
        operatorName = $("input[title='Employee Name Required Field']").val();
        var TrainingCAMLQuery = '';
        if (siteURLofList == WPCBFormsUrl) {
            if (operatorName == "Alex E. Wilson Jr.") { operatorName = "Alex E. Wilson" }
            else if (operatorName == "Billy R. Jackson") { operatorName = "Billy Jackson" }
            else if (operatorName == "Francis Spokus") { operatorName = "Frank Spokus" }
            else if (operatorName == "George DeAtley") { operatorName = "George De Atley" }
            else if (operatorName == "Jeffrey A. Sikes") { operatorName = "Jeffrey Sikes" }
            else if (operatorName == "John DeLaVergne") { operatorName = "John Delavergne" }
            else if (operatorName == "Tesfaalem Tesfamariam") { operatorName = "Tes Tesfamariam" }
            TrainingCAMLQuery = "<View><Query> <Where> <And> <Eq> <FieldRef Name=\'operator0\' \/> <Value Type=\'Text\'>" + operatorName + "<\/Value> <\/Eq> <Eq> <FieldRef Name=\'Station\' \/> <Value Type=\'Choice\'>" + GetStationNameForSSA() + "<\/Value> <\/Eq> <\/And> <\/Where> <\/Query><\/View>";
        }
        else {

            TrainingCAMLQuery = "<View><Query> <Where> <And> <Eq> <FieldRef Name=\'operator\' \/> <Value Type=\'Text\'>" + operatorName + "<\/Value> <\/Eq> <Eq> <FieldRef Name=\'Station\' \/> <Value Type=\'Choice\'>" + GetStationNameForSSA() + "<\/Value> <\/Eq> <\/And> <\/Where> <\/Query><\/View>";
        }
        if (operatorName) {
            var clientContext = new SP.ClientContext(siteURLofList);
            //Add comma seperated list: Yearly
            var oList = clientContext.get_web()
                .get_lists()
                .getById(listID);

            var camlQuery = new SP.CamlQuery();
            camlQuery.set_viewXml(TrainingCAMLQuery);

            operatorStationAssignmentListInfo = oList.getItems(camlQuery);
            clientContext.load(operatorStationAssignmentListInfo);
            clientContext.executeQueryAsync(Function.createDelegate(this, this.onOperatorStationAssignmentListInfoSuccess), Function.createDelegate(this, this.onOperatorStationAssignmentListInfoFailed));
        }
        else {
            var message = 'Operator name cannot be empty!';
            $(".fade_div2").html(message);
            $('.fade_div2').finish().show().delay(9000).fadeOut("slow");
        }
    }
    else {
        //for both new and display forms
        // var emptyDisplayMessage = "<br/><br/><img src='/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/Images/note-icon.png'/><p class='emptyDisplayMessage'>There is no data to show! Please save this form and reload the page";
        // $('#TaskStandardContainer').html(emptyDisplayMessage);
    }
}
function onOperatorStationAssignmentListInfoSuccess(sender, args) {
    debugger;
    var operatorStationAssignmentInfoEnumerator = operatorStationAssignmentListInfo.getEnumerator();
    var resultCount = operatorStationAssignmentListInfo.get_count();
    if (resultCount > 0) {
        var hoursatStation = parseInt(resultCount * 12);
        var trainingHours = 0;
        while (operatorStationAssignmentInfoEnumerator.moveNext()) {
            var oListItem = operatorStationAssignmentInfoEnumerator.get_current();
            var isTraining = oListItem.get_item('training');
            if (isTraining) {
                var fetchedHours = oListItem.get_item('hours');
                if (fetchedHours) {
                    trainingHours += fetchedHours;
                }
            }
        }
        //Reuired Hours at Station
        var requiredHoursAtStation = parseInt($("input[title='Required Hours at Station']").val());
        //Required Training Hours at Station
        var requiredTrainingHoursAtStation = parseInt($("input[title='Required Training Hours at Station']").val());

        if (requiredHoursAtStation) { //There is already an existing value, fetch and add to it
            hoursatStation = parseInt(hoursatStation);
            $("input[title='Required Hours at Station']").val(hoursatStation + requiredHoursAtStation);
        }
        else {
            hoursatStation = parseInt(hoursatStation);//If there is no existing value, do have to add
            $("input[title='Required Hours at Station']").val(hoursatStation);
        }
        if (requiredTrainingHoursAtStation) {//There is already an existing value, fetch and add to it
            trainingHours = parseInt(trainingHours);
            $("input[title='Required Training Hours at Station']").val(trainingHours + requiredTrainingHoursAtStation);
        }
        else {
            trainingHours = parseInt(trainingHours); //If there is no existing value, do have to add
            $("input[title='Required Training Hours at Station']").val(trainingHours);
        }
    }
    else {
        //var message = 'Operator is NOT found in one of the lists due to name mismatch Or the operator did not work at this station.';
      //  $(".fade_div2").html(message);
       // $('.fade_div2').finish().show().delay(9000).fadeOut("slow");
    }
}
function onOperatorStationAssignmentListInfoFailed(sender, args) {
    alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
}
/***** 2. End Operator Hours at Station and Training Summary *****/

/***** 3. Start Operator Task Standards Summary *****/

function retrieveTaskStandardsInfo(operatorName) {
    var operatorName;
    //If in edit form
    if (currentLocation.indexOf("EditForm.aspx") != -1 || currentLocation.indexOf("NewForm.aspx") != -1) {
        operatorName = $("input[title='Employee Name Required Field']").val();
        if (operatorName) {
            var clientContext = new SP.ClientContext(siteUrl);
            var taskStandardsListID = GetTaskStandardlistID();
            var oList = clientContext.get_web()
                .get_lists()
                .getById(taskStandardsListID);

            var camlQuery = new SP.CamlQuery();
            var CAMLQuery = '<View><Query> <Where> <Eq> <FieldRef Name=\'Employee_x0020_Name\' \/> <Value Type=\'Text\'>' + operatorName + '<\/Value> <\/Eq> <\/Where> <\/Query></View>';
            camlQuery.set_viewXml(CAMLQuery);

            taskStandardsListInfo = oList.getItems(camlQuery);
            clientContext.load(taskStandardsListInfo);
            clientContext.executeQueryAsync(Function.createDelegate(this, this.onRetrieveTaskStandardsInfoSuccess), Function.createDelegate(this, this.onRetrieveTaskStandardsInfoFailed));
        }
        else {
            var message = 'Operator name cannot be empty!';
            $(".fade_div").html(message);
            $('.fade_div').finish().show().delay(9000).fadeOut("slow");
        }
    }
    else { //for both new and display forms
        var emptyDisplayMessage = "<br/><br/><img src='/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/Images/note-icon.png'/><p class='emptyDisplayMessage'>There is no data to show! Please save this form and reload the page";
        $('#TaskStandardContainer').html(emptyDisplayMessage);
    }
}
function onRetrieveTaskStandardsInfoSuccess(sender, args) {
    debugger;
    var taskStandardInfoEnumerator = taskStandardsListInfo.getEnumerator();
    var resultCount = taskStandardsListInfo.get_count();
    if (resultCount > 0) {
        debugger;
        var TaskStandardsFeederFormID;
        var supervisorSignOff;
        var supervisorSignOffDate;
        var FTSummaryPercent;
        var TotalAreas;
        var WTSummaryPercent;
        while (taskStandardInfoEnumerator.moveNext()) {
            var oListItem = taskStandardInfoEnumerator.get_current();
            TaskStandardsFeederFormID = oListItem.get_item('ID');
            //Get Supervisor Sign off
            FTSummaryPercent = oListItem.get_item('FTSummaryPercent');
            TotalAreas = oListItem.get_item('TotalAreas');
            WTSummaryPercent = oListItem.get_item('WTSummaryPercent');
            supervisorSignOff = oListItem.get_item('Supervisor_x0020_Signoff');
            //Get Supervisor Sign off Date
            //TODO: Date seems to be incorrect
            supervisorSignOffDate = oListItem.get_item('Supervisor_x0020_Signoff_x0020_D');
        }

        $("input[title='FTSummaryPercent']").val(FTSummaryPercent);
        $("input[title='TotalAreas']").val(TotalAreas);
        $("input[title='WTSummaryPercent']").val(WTSummaryPercent);

        $("input[title='RRCL Sign Off Supervisor or Trainer']").val(supervisorSignOff);

        //Get the value from the feeder from
        if (supervisorSignOffDate != null && supervisorSignOffDate != 'null' && supervisorSignOffDate) {
            var frmtSignOffDate = new Date(supervisorSignOffDate);
            var validSignOffDate = (frmtSignOffDate.getMonth() + 1) + "/" + frmtSignOffDate.getDate() + "/" + frmtSignOffDate.getFullYear();
            $("input[title='RRCL Sign Off Supervisor or Trainer Date']").val(validSignOffDate);


        }
        var operatorName = $("input[title='Employee Name Required Field']").val();
        //Get the current URL
        var currentURL;
        if (currentLocation.indexOf("EditForm.aspx") != -1) {
            currentURL = window.location.href.split('&')[0];
        }
        else {
            currentURL = 'https://arlingtonva.sharepoint.com/sites/wpcb/mswpo';
        }
        var FeederFormListName = (GetTaskStandardsListName());

        //Normal message for the operator
        $('#lblOperatorName').html('The Supervisor Sign off and date are pulled from \'Task Standards Feeder Form\' of <b>' + operatorName + '</b>. ');

        var URLToTheFeederForm = 'https:\/\/arlingtonva.sharepoint.com\/sites\/wpcb\/mswpo\/Lists\/' + FeederFormListName + '\/EditForm.aspx?ID=' + TaskStandardsFeederFormID + "&source=" + currentURL;

        $('#anchorTaskStandardURL').attr("href", URLToTheFeederForm);
        $('#anchorTaskStandardURL').attr("class", 'feederFormAnchor');
        $('#anchorTaskStandardURL').attr("target", "_self");
        $('#anchorTaskStandardURL').html('Open the form!');
    }
    else {//There is no feeder form

        //No feeder form for Training Documents for this operator. Show Message
        var operatorName = $("input[title='Employee Name Required Field']").val();

        //Get the Task Standards list name
        var FeederFormListName = GetTaskStandardsListName();

        //Get the first part of the URL with out the 'Source' portion of the default SharePoint
        var currentURL;
        if (currentLocation.indexOf("EditForm.aspx") != -1) {
            currentURL = window.location.href.split('&')[0];
        }
        else {
            currentURL = 'https://arlingtonva.sharepoint.com/sites/wpcb/mswpo';
        }

        //Create the New URL to the feeder form
        var New_URL_TaskStandardsFeederForm = 'https:\/\/arlingtonva.sharepoint.com\/sites\/wpcb\/mswpo\/Lists\/' + FeederFormListName + '\/NewForm.aspx?source=' + currentURL + '&opname=' + operatorName;

        //Dissolving Pop Up message:
        //Set the behaviour of anchor based on form
        var targetType
        if (currentLocation.indexOf("NewForm.aspx") != -1) {
            targetType = "_blank";
        }
        else {
            targetType = "_self";
        }

        var New_URL_Anchor_TaskStandardsFeederForm = '<a href=\"' + New_URL_TaskStandardsFeederForm + '" target=\"' + targetType + '">Click Here<\/a> to create one.';

        var message = 'Oops! There is no data to show you!.<br\/> It looks like there is no feeder form for <b>' + operatorName + '</b>. ';
        $(".fade_div").html(message);
        $('.fade_div').finish().show().delay(9000).fadeOut("slow");


        $('#lblOperatorName').html('The \'Supervisor Signoff\' and \'Date\' are pulled from \'Task Standards Feeder Form\' of <b>' + operatorName + '</b>.<br/> But it appears that there is no form created yet');
        //$('#anchorTaskStandardURL').attr("href", New_URL_TaskStandardsFeederForm);
        //$('#anchorTaskStandardURL').attr("class", 'feederFormAnchor');
        //$('#anchorTaskStandardURL').html('Create a new form!');
        $('#anchorTaskStandardURL').css('display', 'none');

    }

    //Set the behaviour of anchor based on form
    if (currentLocation.indexOf("NewForm.aspx") != -1) {
        $('#anchorTaskStandardURL').attr("target", "_blank");
    }
    else {
        $('#anchorTaskStandardURL').attr("target", "_self");
    }
}
function onRetrieveTaskStandardsInfoFailed(sender, args) {
    alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
}
/***** 3. End Operator Task Standards Summary *****/

/***** 4. Start Operator Safety Training Summary *****/
function retrieveMSWPOSafetTrainingInfo(operatorName) {
    var operatorName;
    //If in edit form
    if (currentLocation.indexOf("EditForm.aspx") != -1 || currentLocation.indexOf("NewForm.aspx") != -1) {
        operatorName = $("input[title='Employee Name Required Field']").val();
        if (operatorName) {
            var clientContext = new SP.ClientContext(siteUrl);
            var oList = clientContext.get_web()
                .get_lists()
                .getById(MSWPOSafetyTrainingCompletionListID);

            var camlQuery = new SP.CamlQuery();
            var CAMLQuery = '<View><Query> <Where> <Eq> <FieldRef Name=\'Operator_x0020_Look_x0020_up\' \/> <Value Type=\'Text\'>' + operatorName + '<\/Value> <\/Eq> <\/Where> <\/Query></View>';
            camlQuery.set_viewXml(CAMLQuery);

            MSWPOSafetyTrainingCompleteListInfo = oList.getItems(camlQuery);
            clientContext.load(MSWPOSafetyTrainingCompleteListInfo);
            clientContext.executeQueryAsync(Function.createDelegate(this, this.onretrieveMSWPOSafetTrainingInfoSuccess), Function.createDelegate(this, this.onretrieveMSWPOSafetTrainingInfoFailed));
        }
        else {
            var message = 'Operator name cannot be empty!';
            $(".fade_div").html(message);
            $('.fade_div').finish().show().delay(9000).fadeOut("slow");
        }
    }
}
function onretrieveMSWPOSafetTrainingInfoSuccess(sender, args) {
    var MSWPOSafetyTrainingCompleteListInfoEnumerator = MSWPOSafetyTrainingCompleteListInfo.getEnumerator();
    var resultCount = MSWPOSafetyTrainingCompleteListInfo.get_count();
    if (resultCount > 0) {
        while (MSWPOSafetyTrainingCompleteListInfoEnumerator.moveNext()) {
            var currentYear = new Date().getFullYear();
            var pastYear = currentYear - 1;

            var oListItem = MSWPOSafetyTrainingCompleteListInfoEnumerator.get_current();
            var yearFromList = oListItem.get_item('Year');
            //Get Online Completed
            onlineCompleted = oListItem.get_item('_x0025_Online_x0020_Completed');
            //Get Face to Face completed
            facetofaceCompleted = oListItem.get_item('_x0025_Face_x0020_to_x0020_Face_');
            //Total Training Complete
            TotalCompleted = oListItem.get_item('_x0025__x0020_Total_x0020_Safety');

            if (currentYear == yearFromList) {
                $("input[title='Competency A Current face to face']").val(facetofaceCompleted);
                $("input[title='Competency A Current Online']").val(onlineCompleted);
                $("input[title='Current Year % of Available Training Complete']").val(TotalCompleted);
            }

            if (pastYear == yearFromList) {
                $("input[title='Competency A Past face to face']").val(facetofaceCompleted);
                $("input[title='Competency A Past Online']").val(onlineCompleted);
                $("input[title='Past Year % Training Complete']").val(TotalCompleted);
            }
        }
    }

}
function onretrieveMSWPOSafetTrainingInfoFailed(sender, args) {
    console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
}
/***** 4. End Operator Safety Training Summary *****/

/***** 5. Start Operator Training Documents Summary *****/
function retrieveTrainingInfo() {
    var operatorName;
    //Edit form only
    if (currentLocation.indexOf("EditForm.aspx") != -1 || currentLocation.indexOf("NewForm.aspx") != -1) {
        //Get the operator Name
        operatorName = $("input[title='Employee Name Required Field']").val();
        //Query the Training docs list using the operator Name
        if (operatorName) {
            var clientContext = new SP.ClientContext(siteUrl);
            var TraingDocslistID = GetTraingDocslistID();
            var oList = clientContext.get_web()
                .get_lists()
                 .getById(TraingDocslistID);
            var camlQuery = new SP.CamlQuery();
            var CAMLQuery = '<View><Query> <Where> <Eq> <FieldRef Name=\'Title\' \/> <Value Type=\'Text\'>' + operatorName + '<\/Value> <\/Eq> <\/Where> <\/Query></View>';
            camlQuery.set_viewXml(CAMLQuery);
            trainingProgressInfo = oList.getItems(camlQuery);
            clientContext.load(trainingProgressInfo);
            clientContext.executeQueryAsync(Function.createDelegate(this, this.onRetrieveTrainingProgressSuccess),
                Function.createDelegate(this, this.onRetrieveTrainingProgressFailed)
            );
        }
        else {
            var message = 'Operator name cannot be empty!';
            $(".fade_div1").html(message);
            $('.fade_div1').finish().show().delay(9000).fadeOut("slow");
        }
    } else { //for both new and display forms
        var emptyDisplayMessage = "<br/><br/><img src='/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/Images/note-icon.png'/><p class='emptyDisplayMessageTab'>There is no data to show, please save and revisit this form";
        $('#TrianingProgressContainer').html(emptyDisplayMessage);
    }
}
function onRetrieveTrainingProgressSuccess(sender, args) {
    //Get the Enumerator
    var trainingProgressInfoItemEnumerator = trainingProgressInfo.getEnumerator();
    //Get the result count
    var resultCount = trainingProgressInfo.get_count();
    var TrainingDocsFeederFormID;
    //Process only if the result count is greater than zero
    if (resultCount > 0) {
        var chartdataPoints = [];
        while (trainingProgressInfoItemEnumerator.moveNext()) {
            var oListItem = trainingProgressInfoItemEnumerator.get_current();
            //Get ID
            TrainingDocsFeederFormID = oListItem.get_item('ID');
            var totalPercent = 0;
            for (var i = 0; i < libNames.length; i++) {
                var yValue = oListItem.get_item(libInternalNames[i]);

                var numberDocumentsToRead = oListItem.get_item(libTotalCountInternalNames[i]);

                var labelValue = libNames[i];
                var indexLabelValue;

                if (libInternalNames[i] != "s6oq" && numberDocumentsToRead == 0) {
                    indexLabelValue = 'No documents required!'
                }
                else {
                    indexLabelValue = yValue + '%';
                }
                chartdataPoints.push({ y: yValue, label: labelValue, indexLabel: indexLabelValue });
                totalPercent += yValue;
            }
            if (totalPercent > 0) {
                var averageTotal = Math.round(totalPercent / (libNames.length));
                var indexTotalLabelValue = averageTotal + '%';
                chartdataPoints.push({ y: averageTotal, label: "Total %", indexLabel: indexTotalLabelValue });
            }
        }
        chartdataPoints.reverse();
        var chart = new CanvasJS.Chart("TrianingProgressContainer", {
            title: {
                text: "",
                fontFamily: "Segoe UI Light,Segoe UI,Segoe,Tahoma,Helvetica,Arial,sans-serif",
                fontSize: 15
            },
            animationEnabled: true,
            axisX: {
                interval: 1,
                gridThickness: 0,
                labelFontSize: 15,
                labelFontStyle: "normal",
                labelFontWeight: "bolder",
                labelFontFamily: "Segoe UI Light,Segoe UI,Segoe,Tahoma,Helvetica,Arial,sans-serif"

            },
            axisY: {
                tickThickness: 0,
                lineThickness: 0,
                valueFormatString: " ",
                gridThickness: 0
            },
            height: 190,
            width: 690,
            theme: "theme2",
            data: [
            {
                type: "bar",
                name: "TrainingLevels",
                axisYType: "primary",
                indexLabelFontSize: 18,
                toolTipContent: "<span style='\"'color: {color};'\"'>{indexLabel}: </span><span style='\"'font-size: 20px; color:peru '\"'>{label}</span>",
                indexLabelPlacement: "inside",
                indexLabelFontColor: "white",
                indexLabelFontWeight: 500,
                indexLabelFontFamily: "Segoe UI Light,Segoe UI,Segoe,Tahoma,Helvetica,Arial,sans-serif",
                dataPoints: chartdataPoints
            }

            ]
        });
        chart.render();

        //Get the operator Name:
        var operatorName = $("input[title='Employee Name Required Field']").val();

        //Get the current URL
        var currentURL;
        if (currentLocation.indexOf("EditForm.aspx") != -1) {
            currentURL = window.location.href.split('&')[0];
        }
        else {
            currentURL = 'https://arlingtonva.sharepoint.com/sites/wpcb/mswpo';
        }

        //Feeder form is found, provide the link to the edit form.
        var FeederFormListName = encodeURIComponent(GetTrainingDocsListName());

        //Normal message for the operator
        $('#lblOperatorNameCompetencyC').html("The status of the documents read is pulled from \'" + decodeURIComponent(FeederFormListName) + "' of <b>'" + operatorName + "'</b>.");

        //Actual link to the feeder form
        var URLToTheFeederForm = 'https:\/\/arlingtonva.sharepoint.com\/sites\/wpcb\/mswpo\/Lists\/' + FeederFormListName + '\/EditForm.aspx?ID=' + TrainingDocsFeederFormID + "&source=" + currentURL;
        $('#anchorTrainingURL').attr("href", URLToTheFeederForm);
        $('#anchorTrainingURL').attr("class", 'feederFormAnchor');
        $('#anchorTrainingURL').html('Open the form!');
    }
    else { //There is no feeder form
        //No feeder form for Training Documents for this operator. Show Message
        var operatorName = $("input[title='Employee Name Required Field']").val();

        //Get the training docs list name
        var FeederFormListName = GetTrainingDocsListName();

        //Get the first part of the URL with out the 'Source' portion of the default SharePoint
        var currentURL;
        if (currentLocation.indexOf("EditForm.aspx") != -1) {
            currentURL = window.location.href.split('&')[0];
        }
        else {
            currentURL = 'https://arlingtonva.sharepoint.com/sites/wpcb/mswpo';
        }

        //Create the New URL to the feeder form
        var New_URL_TrainingDocsFeederForm = 'https:\/\/arlingtonva.sharepoint.com\/sites\/wpcb\/mswpo\/Lists\/' + FeederFormListName + '\/NewForm.aspx?source=' + currentURL + '&opname=' + operatorName;

        //Dissolving Pop Up message:
        //Set the behaviour of anchor based on form
        var targetType
        if (currentLocation.indexOf("NewForm.aspx") != -1) {
            targetType = "_blank";
        }
        else {
            targetType = "_self";
        }
        var New_URL_Anchor_TrainingDocsFeederForm = '<a href=\"' + New_URL_TrainingDocsFeederForm + '" target=\"' + targetType + '">Click Here<\/a> to create one.';
        var message = 'Oops! There is no data to show you!.<br\/> It looks like there is no feeder form for <b>' + operatorName + '</b>. ';
        $(".fade_div1").html(message);
        $('.fade_div1').finish().show().delay(9000).fadeOut("slow");

        //No feeder form for Training Documents for this operator. Provide a link

        $('#lblOperatorNameCompetencyC').html("The status of the documents read is pulled from '" + FeederFormListName + "' of <b>'" + operatorName + "'</b>.But it appears that there is no feeder form created yet");
        //$('#anchorTrainingURL').attr("href", New_URL_TrainingDocsFeederForm);
        //$('#anchorTrainingURL').attr("class", 'feederFormAnchor');
        //$('#anchorTrainingURL').html('Create a new form!');
        $('#anchorTrainingURL').css('display', 'none');
    }

    //Set the behaviour of anchor based on form
    if (currentLocation.indexOf("NewForm.aspx") != -1) {
        $('#anchorTrainingURL').attr("target", "_blank");
    }
    else {
        $('#anchorTrainingURL').attr("target", "_self");
    }
}
function onRetrieveTrainingProgressFailed(sender, args) {
    alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
}
/***** 5. End Operator Training Documents Summary *****/

/***** 6. Start Supporting Getters *****/
function GetStationNameForSSA() {
    if (document.location.href.indexOf('Primary') != -1) {
        return "Primary";
    }
    if (document.location.href.indexOf('Secondary') != -1) {
        return "Secondary";
    }
    if (document.location.href.indexOf('DWB') != -1) {
        return "Dewater Building";
    }
    if (document.location.href.indexOf('AWT') != -1) {
        return "AWT";
    }
}
function GetCDSSListID() {
    if (document.location.href.indexOf('Primary') != -1) {
        return PrimaryCDSSListID;
    }
    if (document.location.href.indexOf('Secondary') != -1) {
        return SecondaryCDSSListID;
    }
    if (document.location.href.indexOf('DWB') != -1) {
        return DWBCDSSListID;
    }
    if (document.location.href.indexOf('AWT') != -1) {
        return AWTCDSSListID;
    }

}
function GetTraingDocslistID() {
    if (document.location.href.indexOf('Primary') != -1) {
        return PrimarytrainingDocsListID;
    }
    if (document.location.href.indexOf('Secondary') != -1) {
        return SecondarytrainingDocsListID;
    }
    if (document.location.href.indexOf('DWB') != -1) {
        return DWBtrainingDocsListID;
    }
    if (document.location.href.indexOf('AWT') != -1) {
        return AWTtrainingDocsListID;
    }
}
function GetTaskStandardlistID() {
    if (document.location.href.indexOf('Primary') != -1) {
        return PrimaryTaskStandardsID;
    }
    if (document.location.href.indexOf('Secondary') != -1) {
        return SecondaryTaskStandardsID;
    }
    if (document.location.href.indexOf('DWB') != -1) {
        return DWBTaskStandardsID;
    }
    if (document.location.href.indexOf('AWT') != -1) {
        return AWTTaskStandardsID;
    }
}
function GetStationName() {
    if (document.location.href.indexOf('Primary') != -1) {
        return "Primary Station";
    }
    if (document.location.href.indexOf('Secondary') != -1) {
        return "Seconday Station";
    }
    if (document.location.href.indexOf('DWB') != -1) {
        return "DWB Station";
    }
    if (document.location.href.indexOf('AWT') != -1) {
        return "AWT Station";
    }
}
function GetTaskStandardsListName() {
    if (document.location.href.indexOf('Primary') != -1) {
        return PrimaryTaskStandardsEncodedLibraryName;
    }
    if (document.location.href.indexOf('Secondary') != -1) {
        return SecondaryTaskStandardsEncodedLibraryName;
    }
    if (document.location.href.indexOf('DWB') != -1) {
        return DWBTaskStandardsEncodedLibraryName;

    }
    if (document.location.href.indexOf('AWT') != -1) {
        return AWTTaskStandardsEncodedLibraryName;
    }
}
function GetTrainingDocsListName() {
    if (document.location.href.indexOf('Primary') != -1) {
        return PrimarytrainingDocsLibraryName;
    }
    if (document.location.href.indexOf('Secondary') != -1) {
        return SecondarytrainingDocsLibraryName;
    }
    if (document.location.href.indexOf('DWB') != -1) {
        return DWBtrainingDocsLibraryName;
    }
    if (document.location.href.indexOf('AWT') != -1) {
        return AWTtrainingDocsListLibraryName;
    }
}
function GetFieldForCertificateDate() {
    if (document.location.href.indexOf('Primary') != -1) {
        return " Primary_x0020_L3_x0020_Certifica";
    }
    if (document.location.href.indexOf('Secondary') != -1) {
        return "Secondary_x0020_L3_x0020_Certifi";
    }
    if (document.location.href.indexOf('DWB') != -1) {
        return "DWB_x0020_L3_x0020_Certification";
    }
    if (document.location.href.indexOf('AWT') != -1) {
        return "AWT_x0020_L3_x0020_Certification";
    }
}
/***** 6. End Supporting Getters  *****/

/***** 7.  Start Button Click Functions *****/

//Handle button Clicks
//Basic Operator Info
$('#btnGetOperatorInfo').click(function () {
    var operatorName = $('#operatorList').val();
    AutoFillOperatorInfo(operatorName);

});
//Hours at station and Training Hours
$('#btnGetOperatorTrningHrsSummary').click(function () {
    var operatorName = $("input[title='Employee Name Required Field']").val();
    GetOperatorHours(operatorName);
    //$("input[title='Required Hours at Station']").val('');
    //$("input[title='Required Training Hours at Station']").val('');

    //var message = 'Ok hold on! Fetching operator hours and training hours at the station. Please wait...';
    //$(".fade_div2").html(message);
    //$('.fade_div2').finish().show().delay(14000).fadeOut("slow");

    //// Yearly Change:
    //// Please note that the following IDs will have to be updated based on the list IDs created on yearly basis.
    //// Get the training from List 1
    //retriveTrainingSummary('A0FC9AB0-23CD-4350-9D22-99571F4E2B96', WPCBFormsUrl);

    //var delay = 5000; //5 seconds
    //setTimeout(function () {
    //    //Get the training from List 2
    //    retriveTrainingSummary('C2932C64-DF7B-4221-85D3-5E3A11FDC2D5', siteUrl);
    //}, delay);

    //var Prequisitesdelay = 12000; //10 seconds
    //setTimeout(function () {
    //    //Required hours at station
    //    var requiredHoursAtStation = parseInt($("input[title='Required Hours at Station']").val());
    //    //Required Training Hours at Station
    //    var requiredTrainingHoursAtStation = parseInt($("input[title='Required Training Hours at Station']").val());

    //    if (requiredHoursAtStation) { //There is already an existing value, fetch and add to it
    //        var textToDisplay = GetMonthsValueToDisplay(parseInt(requiredHoursAtStation));
    //        $("input[title='Required Hours at Station']").val(textToDisplay);
    //    }
    //    else {
    //        $("input[title='Required Hours at Station']").val('0');
    //    }
    //    if (requiredTrainingHoursAtStation) {//There is already an existing value, fetch and add to it
    //        var textToDisplay = GetMonthsValueToDisplay(parseInt(requiredTrainingHoursAtStation));
    //        $("input[title='Required Training Hours at Station']").val(textToDisplay);
    //    }
    //    else {
    //        $("input[title='Required Training Hours at Station']").val('0');
    //    }
    //}, Prequisitesdelay);

    var stationName = GetStationName();
    if (stationName == "DWB Station" || stationName == "AWT Station") {
        retrieveDOCSummary();
    }
});
//Task standards info
$('#btnGetTaskStandardsInfo').click(function () {
    retrieveTaskStandardsInfo();
});
//Safety Training
$('#btnGetSafetyTraining').click(function () {
    retrieveMSWPOSafetTrainingInfo();
});
//Operator Training Documents Summary
$('#btnGetOperatorTrainingDoc').click(function () {
    retrieveTrainingInfo();
});
$("#validateCheck").click(function () {
    var result = ValidateCertification();
    if (result == 'true') {
        var hasOpsManagerNotifiedAlready = $("input[title='NotifyOpsManagerInfo']").val();
        var OperationManagerNotifiedDate = $("input[title='Sign Off by Supervisor Date']").val();
        if (hasOpsManagerNotifiedAlready) {
            fnOpenNormalMessage(' - Operator meets all the certification criteria! <br/>  - Operations Manager has been notified on ' + OperationManagerNotifiedDate + '.', 'Awesome!', 400, 155);
        }
        else {
            fnOpenNormalMessage(' - Operator meets all the certification criteria! <br/>  - Please notify Operators Manager.', 'Awesome!', 400, 155);
        }
    }
    else {
        fnOpenNormalMessage(result, 'Certification criteria failed!', 500, 225);
    }
});

$("#notifyOPSManager").click(function () {
    var result = ValidateCertification();

    var supervisorSignOffDate = $('input[Title="Sign Off by Supervisor Date"]').val();
    var supervisorSignOff = $('input[Title="Sign Off by Supervisor"]').val();

    if (supervisorSignOffDate && supervisorSignOff) {

        if (result == 'true') {
            if (currentLocation.indexOf("EditForm.aspx") != -1) {
                var hasSuperVisorSignedOff = $("input[title='Sign Off by Supervisor Date']").val();
                if (hasSuperVisorSignedOff) {
                    $('#trNotifyOpsManager').show();
                    var employeeName = $('input[Title="Employee Name Required Field"]').val();
                    $("input[title='NotifyOpsManagerInfo']").val('Supervisor certified ' + employeeName + ' on ' + hasSuperVisorSignedOff)
                    $('input[Title="Sign Off by Supervisor Date"]').prop("disabled", true);
                    $("input[title='Sign Off by Supervisor Date']").parent().next().closest('td').find("img:first").css('display', 'none')
                    $('input[Title="Sign Off by Supervisor"]').prop("disabled", true);
                }
            }
            var hasOpsManagerNotified = $("input[title='NotifyOpsManagerInfo']").val();
            if (!hasOpsManagerNotified) {
                NotifyOperationsManager();
            }
            else {
                fnOpenNormalDialog('Operations Manager will be notified. Do you want to notify?', 'supervisor', 'Info', 150, 40);
            }

        }
        else {
            fnOpenNormalMessage(result, 'Certification criteria Failed!', 500, 225);
        }
    }
    else {
        fnOpenNormalMessage('Please signoff and provide a date before you notify Operations Manager!', 'Error', 150, 40)
    }
});
function NotifyOperationsManager() {
    debugger;
    //Fetch employee and Level info to send the email.
    var employeeName = $('input[Title="Employee Name Required Field"]').val();
    var stnLvlInfo = GetStationName();
    stnLvlInfo += ' at Level 2';

    var p = getUserEmail();
    p.done(function (result) {
        if (result) {
            debugger;
            //Construct Email structure
            var from = StandardFromAddress;
            var to = OperationsManagerEmail;
            var cc = StandardCCAddress.split(',');
            var subject = 'MSWPO: Certify ' + employeeName + ' at ' + stnLvlInfo;
            var body = 'Dear Operations Manger, <br/><br/>' + employeeName + ' is ready to be certified for ' + stnLvlInfo + '. <br/><br/>Please go to his ' + '<a href=\'' + window.location.href + '\'>' + 'CDSS Form ' + '</a>' + 'to certify ' + employeeName;

            //This will not be sent as part of email. Just to display message after sucessful email sent
            var sucessMessage = 'An email has been sent to Operations Manager requesting to certify the operator.';

            // Call sendEmail function
            sendEmail(from, to, cc, body, subject, sucessMessage);
        }
    });

}
$("#certifyOperator").click(function () {
    debugger;
    var result = ValidateCertification();
    var operationManagerSignOff = $('input[Title="Sign Off by Operations Manager"]').val();
    var operationManagerSignOffDate = $('input[Title="Sign Off by Operations Manager Date"]').val();
    var employeeName = $('input[Title="Employee Name Required Field"]').val();
    if (operationManagerSignOff && operationManagerSignOffDate) {
        //All the criteria are met
        if (result == 'true') {
            var hasOperationsManagerNotified = $("input[title='NotifyOpsManagerInfo']").val();
            if (hasOperationsManagerNotified) {
                var stationName = GetStationName();
                fnOpenNormalDialog('You are about to certify ' + employeeName + 'at ' + stationName + 'for Level2, once certified no changes are allowed. Do you wish to proceed?', 'opsmanager', 'Info', 150, 40);
                if (currentLocation.indexOf("EditForm.aspx") != -1) {
                    //If the operations manager signed off show the date that he signed off.
                    if (operationManagerSignOffDate) {
                        $('#trCertifyOperator').show();
                        $("input[title='CertifyOperator']").val('OPS Manager certified ' + employeeName + ' on ' + operationManagerSignOffDate)
                        $('input[Title="Sign Off by Operations Manager Date"]').prop("disabled", true);
                        $('input[Title="Sign Off by Operations Manager"]').prop("disabled", true);
                        if (!hasOperationsManagerNotified) {
                            fnOpenNormalMessage(employeeName + " has been certified on " + operationManagerSignOffDate, 'Awesome!', 490, 125);
                        }
                    }
                }
            }
            else {
                $('input[Title="Sign Off by Operations Manager Date"]').val('');
                $('input[Title="Sign Off by Operations Manager"]').val('');
                $("input[title='CertifyOperator']").val('');
                fnOpenNormalMessage('Supervisor did not certify the operator yet!', 'Error:', 490, 125)
            }

        }
        else {
            fnOpenNormalMessage(result, 'Certification criteria Failed!', 500, 225);
        }
    }
    else {
        fnOpenNormalMessage('Please signoff and provide a date before you certify operator!', 'Error:', 490, 125)
    }
});
function NotifyOperatorCerfication() {
    debugger;
    var stnLvlInfo = GetStationName();
    stnLvlInfo += ' at Level 2';
    var p = getUserEmail();
    p.done(function (result) {
        if (result) {
            debugger;
            var employeeName = $('input[Title="Employee Name Required Field"]').val();
            var supervisorName = $('input[Title="Shift Supervisor"]').val();

            var toAddressTest = '';
            //Construct Email structure
            var from = StandardFromAddress;
            var to = OperationsManagerEmail;
            var cc = StandardCCAddress.split(',');
            var subject = 'MSWPO: Certified ' + employeeName + ' for ' + stnLvlInfo;
            // var supervisorFetchedEmail = GetOperatorEmail(supervisorName, 'supervisor');
            // var supervisorEmail = "";
            // supervisorFetchedEmail.done(function (result1) {
            //    supervisorEmail = result1;
            // });
            var ccAddressfetchValue = GetOperatorEmail(employeeName, supervisorName);
            //Make changes based on the result.

            ccAddressfetchValue.done(function (result) {
                var returnedValue = result;
                StandardCCAddress = [shiftSupervisorEmail, "Fcorsoro@arligntonva.us", "Scameron@arlingtonva.us", "Scprice@arlingtonva.us"];
                cc = StandardCCAddress;
                to = result;
                if (returnedValue) {
                    debugger;
                    toAddressTest = returnedValue;
                    var body = 'Hi,<br/><br/>' + employeeName + ' is certified for ' + stnLvlInfo + '. <br/><br/>Click here to see his ' + '<a href=\'' + window.location.href + '\'>' + 'CDSS Form ' + '</a>' + '.';
                    //This will not be sent as part of email. Just to display message after sucessful email sent
                    var sucessMessage = 'An email has been sent to Operations Manager,Supervisor and operator.';
                    // Call sendEmail function
                    //Todo: Replace cc with returned value + operators
                    sendEmail(from, to, cc, body, subject, sucessMessage);
                }
            });
        }
    });

}
function ValidateCertification() {
    var displayText = '';
    //Prerequisites
    var txtPrerequisitesDate = $('input[Title="Prequisites Supervisor Sign off Date"]').val();
    if (txtPrerequisitesDate) {
        $('input[Title="Certification Criteria 1"]').val('Yes (Supervisor signedoff on ' + txtPrerequisitesDate + ')');
    }
    else {
        displayText += '<br/>'
        displayText += '<b>Prerequisites: Criteria 1 failed</b> - Prerequisites are not signed off by Supervisor yet.';
        $('input[Title="Certification Criteria 1"]').val('');
    }

    //Task Standards Value
    var txtTaskStandardsDate = $('input[Title="RRCL Supervisor Sign off Date"]').val();

    var txtTaskStandardsPulledSigned = $('input[Title="RRCL Sign Off Supervisor or Trainer"]').val();
    var txtTaskStandardsPulledSignedDate = $('input[Title="RRCL Sign Off Supervisor or Trainer Date"]').val();
    var txtTaskStandardsSupervisorSigned = $('input[Title="Task Standards Supervisor Signoff"]').val();
    var txtTaskStandardsSupervisorDateSigned = $('input[Title="RRCL Supervisor Sign off Date"]').val();

    if (txtTaskStandardsPulledSignedDate && txtTaskStandardsSupervisorDateSigned && txtTaskStandardsSupervisorSigned && txtTaskStandardsPulledSigned) {
        $('input[Title="Certification Criteria 2"]').val('Yes (Supervisor signedoff on ' + txtTaskStandardsDate + ')');
    }
    else {
        displayText += '<br/>'
        displayText += '<br/><b>Task Standards Mini-Mods: Criteria 2 failed!</b> - Either the Task Standards are not signed off by Supervisor or data from supporting feeder from is not pulled yet.';
        $('input[Title="Certification Criteria 2"]').val('');
    }


    //Competency A
    var txtCompetencyASupervisorSignOffDate = $('input[Title="Competency A Supervisor Sign-off Date"]').val();
    var txtCompetencyASupervisorSignOff = $('input[Title="Competency A Supervisor Sign-off"]').val();

    //Competency B
    var txtCompetencyBSupervisorSignOffDate = $('input[Title="Competency B Sign Off Date"]').val();
    var txtCompetencyBSupervisorSignOff = $('input[Title="Competency B Sign Off"]').val();
    var ddlCompetencyBSummaryQuestion = $('select[Title="Competency B Summary Question"]').val().trim();

    //Competency C
    var txtCompetencyCSupervisorSignOffDate = $('input[Title="Competency C Sign Off Date"]').val();
    var txtCompetencyCSupervisorSignOff = $('input[Title="Competency C Sign Off"]').val();

    //Competency D
    var txtCompetencyDSupervisorSignOffDate = $('input[Title="Competency D Sign off Date"]').val();
    var txtCompetencyDSupervisorSignOff = $('input[Title="Competency D Sign off"]').val();
    var ddlCompetencyDSummaryQuestion = $('select[Title="Competency D Summary Question"]').val().trim();

    //Check if all the dates are signed off & sign offs are not empty.
    if (txtCompetencyASupervisorSignOffDate && txtCompetencyBSupervisorSignOffDate && txtCompetencyCSupervisorSignOffDate && txtCompetencyDSupervisorSignOffDate && txtCompetencyASupervisorSignOff && txtCompetencyBSupervisorSignOff && txtCompetencyCSupervisorSignOff && txtCompetencyDSupervisorSignOff) {
        //Check if all the .
        if (ddlCompetencyDSummaryQuestion && ddlCompetencyBSummaryQuestion) {
            var checkText = 'Yes(' + 'A-' + txtCompetencyASupervisorSignOffDate + '|B -' + txtCompetencyBSupervisorSignOffDate + '|C-' + txtCompetencyCSupervisorSignOffDate + '|D-' + txtCompetencyDSupervisorSignOffDate + ')';
            $('input[Title="Certification Criteria 3"]').val(checkText);
        } else {
            //Empty the text box
            $('input[Title="Certification Criteria 3"]').val('');

            //Competency B:
            if (!ddlCompetencyBSummaryQuestion) {
                displayText += '<br/><b> Required Competencies: Criteria 3 - Competency B failed! </b> - Supervisor did not select any valued for \'Operator understands plant locations for this station and training level\'';
            }
            if (!ddlCompetencyDSummaryQuestion) {
                displayText += '<br/><b> Required Competencies: Criteria 3 - Competency D failed! </b> - Supervisor did not select any valued for \'Operator understands Knowledge Databases for this station and training level\'<br/>';
            }
        }
    } else {
        //Empty the text box
        $('input[Title="Certification Criteria 3"]').val('');

        //Competency A:
        if (!txtCompetencyASupervisorSignOffDate || !txtCompetencyASupervisorSignOff) {
            displayText += '<br/> <br/> <b> Required Competencies: Criteria 3 -Competency A - Safety failed!</b> - Supervisor did not sign off completely . Both date and signoff are required! <br/>';
        }
        //Competency B:
        if (!txtCompetencyBSupervisorSignOffDate || !txtCompetencyBSupervisorSignOff || !ddlCompetencyBSummaryQuestion) {
            if (!txtCompetencyBSupervisorSignOffDate || !txtCompetencyBSupervisorSignOff) {
                displayText += ' <br/> <b>Required Competencies: Criteria 3 - Competency B - Plant Locations failed! </b> - Supervisor did not sign off completely . Both date and signoff are required! <br/>';
            } else {
                displayText += '<br/><b>Required Competencies: Criteria 3 - Competency B failed! </b> - Supervisor did not select any valued for \'Operator understands plant locations for this station and training level\'<br/>';
            }
        }
        //Competency C:
        if (!txtCompetencyCSupervisorSignOffDate || !txtCompetencyCSupervisorSignOff) {
            displayText += ' <br/> <b>Required Competencies: Criteria 3 - Competency C - Training Documents failed!</b> - Supervisor did not sign off completely . Both date and signoff are required! <br/>';
        }

        //Competency D:
        if (!txtCompetencyDSupervisorSignOffDate || !txtCompetencyDSupervisorSignOff || !ddlCompetencyDSummaryQuestion) {
            if (!txtCompetencyDSupervisorSignOffDate || !txtCompetencyDSupervisorSignOff) {
                displayText += ' <br/> <b> Criteria 3 - Competency D - Knowledge Databases failed! </b>- Supervisor did not sign off completely . Both date and signoff are required! <br/>';
            } else {
                displayText += '<br/><b>Required Competencies: Criteria 3 - Competency D failed! </b>- Supervisor did not select any valued for \'Operator understands Knowledge Databases for this station and training level\'<br/>';
            }
        }

        //
    }
    //MaintenanceSection
    var txtMaintenanceSectionDate = $('input[Title="Maintenance Supervisor Sign-off Date"]').val();
    var txtMaintenanceSection = $('input[Title="Maintenance Supervisor Sign-off"]').val();
    if (txtMaintenanceSectionDate && txtMaintenanceSection) {
        $('input[Title="Certification Criteria 4"]').val('Yes (Supervisor signedoff on ' + txtTaskStandardsDate + ')');
    }
    else {
        displayText += '<br/>'
        displayText += '<br/><b>Maintenance: Criteria 4 failed! </b>- Maintenance is not signed off by Supervisor.';
        $('input[Title="Certification Criteria 4"]').val('');
    }

    if (displayText) {
        return displayText;
    }
    else {
        //alert('Operator meets all the criteria! Please notify Operators Manager.');
        return 'true';
    }
}
$("#print").click(function () {
    $(".ui-accordion-content").show()
    $("#tabs").each(function () {
        // Before printing show all the tab panel contents
        $('.ui-tabs-panel').show();
        $('#tabs').tabs().css({
            'margin-top': '-190px',
            'padding-top': '170px'
        });
        $('.ui-tabs-nav').hide();
        $('#RCInfoSection').hide();
        $('#trRefreshIcon').hide();
        $('#tdRefreshIcon').hide();
        $('#divNotifyOpsManager').hide();
        $('#validateCheck').hide();

        $('#expandAll').hide();
        $('#collapseAll').hide();
        $('#print').hide();
        $('#email').hide();

        $('.tooltip').hide();


        // Print the page
        window.print();
        // After printing hide back all the tab panel contents which are supposed to be hidden
        $('.ui-tabs-panel[aria-hidden=true]').hide();
        $("#tabs").tabs().css({
            'min-height': '440px',
            'overflow': 'auto',
            'margin-top': '5px;',
            'padding-top': '5px'
        });
        $('.ui-tabs-nav').show();

        $('#trRefreshIcon').show();
        $('#tdRefreshIcon').show();
        $('#RCInfoSection').show();

        $('#divNotifyOpsManager').show();
        $('#validateCheck').show();

        $('#expandAll').show();
        $('#collapseAll').show();
        $('#print').show();
        $('#email').show();

        $('.tooltip').show();
    });
});
$("#email").click(function () {
    SendCurrentFormAsEmail();
});
function SendCurrentFormAsEmail() {
    var p = getUserEmail();
    p.done(function (result) {
        var employeeName = $('input[Title="Employee Name Required Field"]').val();
        if (result) {
            var from = result,
                to = result,
                body = 'MSWPO CDSS Form for :' + '<a href=\'' + window.location.href + '\'>' + employeeName + '</a>';
            subject = 'MSWPO CDSS for ' + employeeName + ':Primary Station Level 2';
            sucessMessage = 'Please check your inbox. An email has been sent successfully to you!';

            // Call sendEmail function
            sendEmail(from, to, [''], body, subject, sucessMessage);
        }
    });

}
/***** 7.  End Button Click Functions *****/



/***** 8.  Start Retrieve DOC Summary: For AWT and DWB Only *****/
function retrieveDOCSummary() {
    debugger;
    var operatorName;
    //If in edit form
    if (currentLocation.indexOf("EditForm.aspx") != -1 || currentLocation.indexOf("NewForm.aspx") != -1) {
        operatorName = $("input[title='Employee Name Required Field']").val();
        if (operatorName) {
            var clientContext = new SP.ClientContext(siteUrl);
            //Add comma seperated list: Yearly
            var oList = clientContext.get_web()
                .get_lists()
                .getById(DOCDateSummaryListID);
            DOCSummaryCAMLQuery = "<View><Query><Where><Eq><FieldRef Name=\'Title\' \/><Value Type=\'Text\'>" + operatorName + "<\/Value><\/Eq><\/Where><\/Query><\/View>";
            var camlQuery = new SP.CamlQuery();
            camlQuery.set_viewXml(DOCSummaryCAMLQuery);
            DOCSummaryListInfo = oList.getItems(camlQuery);
            clientContext.load(DOCSummaryListInfo);
            clientContext.executeQueryAsync(Function.createDelegate(this, this.onDOCSummaryListInfoListInfoSuccess), Function.createDelegate(this, this.onDOCSummaryListInfoListInfoFailed));
        }
    }
}
function onDOCSummaryListInfoListInfoSuccess(sender, args) {
    var DOCSummaryListInfoEnumerator = DOCSummaryListInfo.getEnumerator();
    var resultCount = DOCSummaryListInfo.get_count();
    var stationName = GetStationName();
    var controlToUpdate;
    var DOCDate;
    if (resultCount > 0) {
        while (DOCSummaryListInfoEnumerator.moveNext()) {
            var oListItem = DOCSummaryListInfoEnumerator.get_current();
            if (stationName == "DWB Station") {
                DOCDate = oListItem.get_item('DWBDOCDate');
                controlToUpdate = 'DWBDOCDate'
            }
            if (stationName == "AWT Station") {
                DOCDate = oListItem.get_item('AWTDOCDate');
                controlToUpdate = 'AWTDOCDate'
            }
        }
        if (DOCDate) {
            $("input[title='" + controlToUpdate + "']").val(FormatDate(DOCDate));
        }
        else {
            $("input[title='" + controlToUpdate + "']").val('Not Certified');
        }
    }
    else {
        var message = 'Operator is not found in the Doc Date list. There could be a name mismatch';
        $(".fade_div2").html(message);
        $('.fade_div2').finish().show().delay(9000).fadeOut("slow");
    }
}
function onDOCSummaryListInfoListInfoFailed(sender, args) {
    alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
}
/***** 8.  End Retrieve DOC Summary: For AWT and DWB Only *****/

/*****9. Start Send Email *****/
function getUserEmail() {
    var d = $.Deferred();
    var email;
    var context = new SP.ClientContext.get_current();
    var web = context.get_web();
    var currentUser = web.get_currentUser();
    currentUser.retrieve();
    context.load(web);

    var o = { d: d, web: web, email: email };
    context.executeQueryAsync(Function.createDelegate(o, successCallback), Function.createDelegate(o, failCallback));

    function successCallback() {
        var userObject = this.web.get_currentUser();
        this.email = userObject.get_email();
        this.d.resolve(this.email);
    }
    function failCallback() {
        this.d.reject("something bad happened");
    }
    return d.promise();
}
function GetOperatorHours(optrName) {
    //var d = $.Deferred();
    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web().get_lists().getById(operatorLookUpList);
    var camlQuery = new SP.CamlQuery();
    var strCAML = '<View><Query> <Where> <Eq> <FieldRef Name=\'Operator_x0020_Name\' \/> <Value Type=\'Text\'>' + optrName + '<\/Value> <\/Eq> <\/Where> <\/Query></View>'
    camlQuery.set_viewXml(strCAML);
    this.collListItem = oList.getItems(camlQuery);
    clientContext.load(collListItem);
    clientContext.executeQueryAsync(Function.createDelegate(this, this.onOperatorHoursQuerySucceeded), Function.createDelegate(this, this.onOperatorHoursQueryFailed));
}
function onOperatorHoursQuerySucceeded(sender, args) {
    var listItemEnumerator = this.collListItem.getEnumerator();
    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
        var stationName = $("input[title='Station Name']").val();
        console.log(stationName);
        console.log(stationName.indexOf("Secondary") != -1);
        if (stationName.indexOf("AWT") != -1) {
            $("input[title='Required Hours at Station']").val(oListItem.get_item('AWTStationHours'));
            $("input[title='Required Training Hours at Station']").val(oListItem.get_item('AWTStationTrainingHours'));
        }
        if (stationName.indexOf("DWB") != -1) {
            $("input[title='Required Hours at Station']").val(oListItem.get_item('DWBStationHours'));
            $("input[title='Required Training Hours at Station']").val(oListItem.get_item('DWBStationTrainingHours'));
        }
        if (stationName.indexOf("Primary") != -1) {
            $("input[title='Required Hours at Station']").val(oListItem.get_item('PrimaryStationHours'));
            $("input[title='Required Training Hours at Station']").val(oListItem.get_item('PrimaryStationTrainingHours'));
        }
        if (stationName.indexOf("Secondary") != -1 || stationName.indexOf("Seconday") != -1) {
            console.log("Hours at station " + oListItem.get_item('SecondaryStationHours'));
            $("input[title='Required Hours at Station']").val(oListItem.get_item('SecondaryStationHours'));
            $("input[title='Required Training Hours at Station']").val(oListItem.get_item('SecondaryStationTrainingHours'));
        }
        if (stationName.indexOf("Supervisor Duties") != -1) {
            $("input[title='Required Hours at Station']").val(oListItem.get_item('SupervisorDutiesStationHours'));
            $("input[title='Required Training Hours at Station']").val(oListItem.get_item('SupervisorDutiesStationTrainingHours'));
        }
        console.log("Hours at station " + $("input[title='Required Hours at Station']").val() + " list value" + oListItem.get_item('SecondaryStationHours'));
        var Prequisitesdelay = 3000; //3 seconds
        setTimeout(function () {
            //Required hours at station
            var requiredHoursAtStation = parseInt($("input[title='Required Hours at Station']").val());
            //Required Training Hours at Station
            var requiredTrainingHoursAtStation = parseInt($("input[title='Required Training Hours at Station']").val());

            if (requiredHoursAtStation) { //There is already an existing value, fetch and add to it
                var textToDisplay = GetMonthsValueToDisplay(parseInt(requiredHoursAtStation));
                $("input[title='Required Hours at Station']").val(textToDisplay);
            }
            else {
                $("input[title='Required Hours at Station']").val('0');
            }
            if (requiredTrainingHoursAtStation) {//There is already an existing value, fetch and add to it
                var textToDisplay = GetMonthsValueToDisplay(parseInt(requiredTrainingHoursAtStation));
                $("input[title='Required Training Hours at Station']").val(textToDisplay);
            }
            else {
                $("input[title='Required Training Hours at Station']").val('0');
            }
        }, Prequisitesdelay);

    }
}
function onOperatorHoursQueryFailed(sender, args) {
    alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
}
function GetOperatorEmail(optrName, suprName) {
    var d = $.Deferred();
    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web().get_lists().getById(operatorLookUpList);
    var camlQuery = new SP.CamlQuery();
    var strCAML = '<View><Query> <Where><Or> <Eq> <FieldRef Name=\'Operator_x0020_Name\' \/> <Value Type=\'Text\'>' + optrName + '<\/Value> <\/Eq> <Eq> <FieldRef Name=\'Operator_x0020_Name\' \/> <Value Type=\'Text\'>' + suprName + '<\/Value> <\/Eq> <\/Or><\/Where> <\/Query></View>'
    camlQuery.set_viewXml(strCAML);
    this.collListItem = oList.getItems(camlQuery);
    clientContext.load(collListItem);

    var o = { d: d, collListItem: collListItem };
    clientContext.executeQueryAsync(Function.createDelegate(o, onQuerySucceeded), Function.createDelegate(o, onQueryFailed));

    return d.promise();
    function onQuerySucceeded(sender, args) {
        var email = '';
        var listItemEnumerator = this.collListItem.getEnumerator();
        while (listItemEnumerator.moveNext()) {
            var oListItem = listItemEnumerator.get_current();
            email = oListItem.get_item('Operator_x0020_Email');
            name = oListItem.get_item('Operator_x0020_Name')
            if (suprName == name) {
                shiftSupervisorEmail = email;
            }
            if (optrName == name) {
                operatorEmail = email;
            }
        }
        this.d.resolve(email);

    }
    function onQueryFailed(sender, args) {
        alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}
function sendEmail(from, to, cc, body, subject, sucessMessage) {
    //Get the relative url of the site
    var siteurl = _spPageContextInfo.webServerRelativeUrl;
    var urlTemplate = siteurl + "/_api/SP.Utilities.Utility.SendEmail";
    $.ajax({
        contentType: 'application/json',
        url: urlTemplate,
        type: "POST",
        data: JSON.stringify({
            'properties': {
                '__metadata': {
                    'type': 'SP.Utilities.EmailProperties'
                },
                'From': from,
                'To': {
                    'results': [to]
                },
                'CC': { 'results': cc },
                'Body': body,
                'Subject': subject
            }
        }),
        headers: {
            "Accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
            "X-RequestDigest": jQuery("#__REQUESTDIGEST").val()
        },
        success: function (data) {
            fnOpenNormalMessage(sucessMessage, 'Email Successfully Sent!', 400, 225);
        },
        error: function (err) {
            fnOpenNormalMessage('Error in sending Email: ' + JSON.stringify(err), 'Error in sending Email:', 800, 400);
            if (to != "kgunnam@arlingtonva.us")
                sendEmail("kgunnam@arlingtonva.us", "kgunnam@arlingtonva.us", [""], subject, body);
        }
    });
}
/*****9. End Send Email *****/

/***** 10.  Start Utility Functions *****/
function GetMonthsValueToDisplay(hours) {
    //Convert hours to months
    var valueInMonths = (hours) / 730;
    if (valueInMonths < 1) {
        var rounded = Math.round(valueInMonths * 10) / 10;
        var days = rounded * 30;
        return "Less than a month (" + days + ")days";
    }
    else {
        //Get Months
        var monthsPart = Math.floor(valueInMonths);
        //Get Decimal and conver to days
        var decimal = valueInMonths - monthsPart;
        var days = (Math.round(decimal * 10) / 10) * 30;
        return monthsPart + " Month(s) & " + days + "days"
    }
}
function hideDisableEnableElements() {
    $('#trNotifyOpsManager').hide();
    $('#trCertifyOperator').hide();
    //Disable irrespective of form
    $("input[title='Competency A Current face to face']").prop('disabled', true);
    $("input[title='Competency A Current Online']").prop('disabled', true);
    $("input[title='Current Year % of Available Training Complete']").prop('disabled', true);

    $("input[title='Competency A Past face to face']").prop('disabled', true);
    $("input[title='Competency A Past Online']").prop('disabled', true);
    $("input[title='Past Year % Training Complete']").prop('disabled', true);
    var operatorName = $("input[title='Employee Name Required Field']").val();
    GetOperatorHours(operatorName);
    var stationName = GetStationName();
    if (stationName == "DWB Station" || stationName == "AWT Station") {
        retrieveDOCSummary();
    }
    if (currentLocation.indexOf("DispForm.aspx") != -1 || currentLocation.indexOf("EditForm.aspx") != -1) {
        $('#trSelectOperator').hide();
    }

    if (currentLocation.indexOf("EditForm.aspx") != -1 || currentLocation.indexOf("NewForm.aspx") != -1) {
        //disable
        $("input[title='Shift Supervisor']").prop('disabled', true);
        $("input[title='Employee Name Required Field']").prop('disabled', true);
        $("input[title='Hire Date']").prop('disabled', true);
        $("input[title='Shift Name']").prop('disabled', true);
        $("input[title='TrainingForLevel']").prop('disabled', true);
        $("input[title='Station Name']").prop('disabled', true);
        $("input[title='Current Level']").prop("disabled", true);
        $("input[title='Certification Criteria 1']").prop('disabled', true);
        $("input[title='Certification Criteria 2']").prop("disabled", true);
        $("input[title='Certification Criteria 3']").prop("disabled", true);
        $("input[title='Certification Criteria 4']").prop("disabled", true);

        $("input[title='NotifyOpsManagerInfo']").prop("disabled", true);
        $("input[title='CertifyOperator']").prop("disabled", true);

        //$("input[title='Required Hours at Station']").prop("disabled", true);
        // $("input[title='Required Training Hours at Station']").prop("disabled", true);
        $("input[title='TotalAreas']").prop("disabled", true);
        $("input[title='FTSummaryPercent']").prop("disabled", true);
        $("input[title='WTSummaryPercent']").prop("disabled", true);
        $("input[title='RRCL Sign Off Supervisor or Trainer']").prop("disabled", true);
        $("input[title='RRCL Sign Off Supervisor or Trainer Date']").prop("disabled", true);
        $("input[title='RRCL Sign Off Supervisor or Trainer Date']").parent().next().closest('td').find("img:first").css('display', 'none')

        var supervisorSignOffDate = $('input[Title="Sign Off by Supervisor Date"]').val();

        if (supervisorSignOffDate) {
            $('input[Title="Sign Off by Supervisor Date"]').prop("disabled", true);
            $("input[title='Sign Off by Supervisor Date']").parent().next().closest('td').find("img:first").css('display', 'none')

            $('input[Title="Sign Off by Supervisor"]').prop("disabled", true);

            $('#trNotifyOpsManager').show();
            var employeeName = $('input[Title="Employee Name Required Field"]').val();
            $("input[title='NotifyOpsManagerInfo']").val('Supervisor certified ' + employeeName + ' on ' + supervisorSignOffDate)
        }
        var OPSMgrSignedOffDate = $("input[title='Sign Off by Operations Manager Date']").val();

        if (OPSMgrSignedOffDate) {
            $(".wrapper input").attr("disabled", "disabled");
            $(".wrapper textarea").attr("disabled", "disabled");
            $(".wrapper select").attr("disabled", "disabled");
            $(".wrapper [role='textbox']").attr("disabled", "disabled");
            $("input[title='Sign Off by Operations Manager']").prop("disabled", true);
            $('input[Title="Sign Off by Operations Manager Date"]').prop("disabled", true);
            $("input[title='Sign Off by Operations Manager Date']").parent().next().closest('td').find("img:first").css('display', 'none')

            $('#trCertifyOperator').show();
            var employeeName = $('input[Title="Employee Name Required Field"]').val();
            $("input[title='CertifyOperator']").val('OPS Manager certified ' + employeeName + ' on ' + OPSMgrSignedOffDate)
        }
        //TODO: Temporarily Disabling it since there is no data to pull
        // $("input[title='Supervisor Sign off']").prop("disabled", true);
        //  $('input[Title="Prequisites Supervisor Sign off Date"]').prop("disabled", true);
        // $("input[title='Prequisites Supervisor Sign off Date']").parent().next().closest('td').find("img:first").css('display', 'none')
    }

    if (currentLocation.indexOf("DispForm.aspx") != -1 || currentLocation.indexOf("NewForm.aspx") != -1) {
        //Hide elements in new and display forms.
        $('#validateCheck').hide();
        $('#notifyOPSManager').hide();

        //$('#anchorTaskStandardURL').hide();
        //$('#anchorTrainingURL').hide();

        // $('#btnGetTaskStandardsInfo').hide();
        // $('#btnGetOperatorTrainingDoc').hide();

        $('#divCertifyOperator').hide();
        $('#print').hide();
        $('#email').hide();
    }

    if (currentLocation.indexOf("NewForm.aspx") != -1) {
        $("input[title='Sign Off by Supervisor']").prop('disabled', true);
        $("input[title='Sign Off by Supervisor Date']").prop('disabled', true);
        $("input[title='Sign Off by Supervisor Date']").parent().next().closest('td').find("img:first").css('display', 'none');

        $("input[title='Sign Off by Operations Manager']").prop('disabled', true);
        $("input[title='Sign Off by Operations Manager Date']").prop('disabled', true);
        $("input[title='Sign Off by Operations Manager Date']").parent().next().closest('td').find("img:first").css('display', 'none');

    }

    if (currentLocation.indexOf("EditForm.aspx") != -1) {
        var hasSuperVisorSignedOff = $("input[title='Sign Off by Supervisor Date']").val();
        var hasOPSMgrSignedOff = $("input[title='Sign Off by Operations Manager Date']").val();
        if (hasSuperVisorSignedOff) {
            $('#trNotifyOpsManager').show();
            $("input[title='NotifyOpsManagerInfo']").val('Supervisor Signedoff ' + employeeName + ' on ' + hasSuperVisorSignedOff)
            $("input[title='Sign Off by Supervisor Date']").prop("disable", true);
            $("input[title='Sign Off by Supervisor Date']").parent().next().closest('td').find("img:first").css('display', 'none');
            $("#divNotifyOpsManager").css("display", "none");

        }
        if (hasOPSMgrSignedOff) {
            $('#trCertifyOperator').show();
            $("input[title='CertifyOperator']").val('Operations manager has signedoff ' + employeeName + ' on ' + hasOPSMgrSignedOff);
            $("input[title='Sign Off by Operations Manager Date']").prop("disable", true);
            $("input[title='Sign Off by Operations Manager Date']").parent().next().closest('td').find("img:first").css('display', 'none');
            $("#divCertifyOperator").css("display", "none");
        }
    }
}
function getUrlParameter(sParam) {
    name = sParam;
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]"); var regexS = "[\\?&]" + name + "=([^&#]*)"; var regex

    = new RegExp(regexS); var results = regex.exec(window.location.href); if (results == null) return ""; else return decodeURIComponent(results

    [1].replace(/\+/g, " "));
};
function FormatDate(unformattedDate) {
    var frmtModifiedDate = new Date(unformattedDate);
    var validModifiedDate = (frmtModifiedDate.getMonth() + 1) + "/" + frmtModifiedDate.getDate() + "/" + frmtModifiedDate.getFullYear();
    return validModifiedDate;
}
/***** 10.  End Utility Functions *****/

/*****11. Start Dialogs *****/
function fnOpenNormalMessage(messageBoxHTML, messagetitle, width, height) {
    $("#dialog-message").html(messageBoxHTML);
    $("#dialog-message").dialog({
        modal: true,
        title: messagetitle,
        width: '600px',
        dialogClass: 'main-dialog-class',
        buttons: {
            Ok: function () {
                $(this).dialog("close");
            }
        }
    });
}
function fnOpenNormalDialog(confirmBoxHTML, role) {
    $("#dialog-confirm").html(confirmBoxHTML);

    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "Please confirm",
        width: '600px',
        dialogClass: 'main-dialog-class',
        buttons: {
            "Yes": function () {
                $(this).dialog('close');
                callback(true, role);
            },
            "No": function () {
                $(this).dialog('close');
                callback(false, role);
            }
        }
    });
}
function callback(value, role) {
    if (value) {
        if (role == 'supervisor') {
            NotifyOperationsManager();
        }

        if (role == 'opsmanager') {
            NotifyOperatorCerfication();
        }
    }
}
/*****11. End Dialogs *****/


/*****11. Start Overide Presave *****/
function PreSaveItem() {
    var employeeName = $('input[Title="Employee Name Required Field"]').val();
    if (employeeName) { //If the employee name is empty do not save.
        return true; // allow save form
    }
    else {
        fnOpenNormalMessage('Please select an operator.', 'Error:', 800, 400);
        return false; // not allow save form
    }
}
/*****11. End Overide Presave *****/





//function retrieveTaskStandardsInfo(operatorName) {
//    var operatorName;
//    //If in edit form
//    if (currentLocation.indexOf("EditForm.aspx") != -1 || currentLocation.indexOf("NewForm.aspx") != -1) {
//        operatorName = $("input[title='Employee Name']").val();
//        if (operatorName) {
//            var clientContext = new SP.ClientContext(siteUrl);
//            var taskStandardsListID = GetTaskStandardlistID();
//            var oList = clientContext.get_web()
//                .get_lists()
//                .getById(taskStandardsListID);

//            var camlQuery = new SP.CamlQuery();
//            var CAMLQuery = '<View><Query> <Where> <Eq> <FieldRef Name=\'Employee_x0020_Name\' \/> <Value Type=\'Text\'>' + operatorName + '<\/Value> <\/Eq> <\/Where> <\/Query></View>';
//            camlQuery.set_viewXml(CAMLQuery);

//            taskStandardsListInfo = oList.getItems(camlQuery);
//            clientContext.load(taskStandardsListInfo);
//            clientContext.executeQueryAsync(Function.createDelegate(this, this.onRetrieveTaskStandardsInfoSuccess), Function.createDelegate(this, this.onRetrieveTaskStandardsInfoFailed));
//        }
//        else {
//            var message = 'Operator name cannot be empty!';
//            $(".fade_div").html(message);
//            $('.fade_div').finish().show().delay(9000).fadeOut("slow");
//        }
//    }
//    else { //for both new and display forms
//        var emptyDisplayMessage = "<br/><br/><img src='/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/Images/note-icon.png'/><p class='emptyDisplayMessage'>There is no data to show! Please save this form and reload the page";
//        $('#TaskStandardContainer').html(emptyDisplayMessage);
//    }
//}
//function onRetrieveTaskStandardsInfoSuccess(sender, args) {
//    var taskStandardInfoEnumerator = taskStandardsListInfo.getEnumerator();
//    var resultCount = taskStandardsListInfo.get_count();
//    var totalItemCountInChemicalsGroup = 3;
//    var totalItemCountInSafetyGroup = 1;
//    var totalItemCountInSpecificKnowledgeGroup = 10;
//    var totalItemCountInGeneralGroup = 2;
//    var totalItemsFromAllGroups = totalItemCountInChemicalsGroup + totalItemCountInSafetyGroup + totalItemCountInSpecificKnowledgeGroup + totalItemCountInGeneralGroup;

//    if (resultCount > 0) {
//        var taskStandardschartdataPoints = [];
//        var TaskStandardsFeederFormID;
//        var supervisorSignOff;
//        var supervisorSignOffDate;
//        while (taskStandardInfoEnumerator.moveNext()) {
//            var oListItem = taskStandardInfoEnumerator.get_current();
//            TaskStandardsFeederFormID = oListItem.get_item('ID');
//            //Get Supervisor Sign off
//            supervisorSignOff = oListItem.get_item('Supervisor_x0020_Signoff');

//            //Get Supervisor Sign off Date
//            //TODO: Date seems to be incorrect
//            supervisorSignOffDate = oListItem.get_item('Supervisor_x0020_Signoff_x0020_D');

//            var totalPercent = 0;
//            for (var i = 0; i < taskStandardNames.length; i++) {
//                switch (taskStandardNames[i]) {
//                    case "Chemicals":
//                        var numberOfItemsChecked = 0;
//                        for (var i = 1; i < totalItemCountInChemicalsGroup + 1; i++) {
//                            var internalName = "Chemicals" + i;
//                            var yValue = oListItem.get_item(internalName);
//                            if (yValue == '1') {
//                                var yValue2 = oListItem.get_item(internalName);
//                                numberOfItemsChecked += 1;
//                                totalPercent += 1;
//                            }
//                        }

//                        var actualValuesToChart = Math.round((numberOfItemsChecked / totalItemCountInChemicalsGroup) * 100);
//                        var indexLabelValue = actualValuesToChart + "%";
//                        taskStandardschartdataPoints.push({ y: actualValuesToChart, label: "Chemicals", indexLabel: indexLabelValue });
//                    case "Safety":
//                        var numberOfItemsChecked = 0;
//                        for (var i = 1; i < totalItemCountInSafetyGroup + 1; i++) {
//                            var internalName = "Safety" + i;
//                            var yValue = oListItem.get_item(internalName);
//                            if (yValue == '1') {
//                                var yValue2 = oListItem.get_item(internalName);
//                                numberOfItemsChecked += 1;
//                                totalPercent += 1;
//                            }
//                        }
//                        var actualValuesToChart = Math.round((numberOfItemsChecked / totalItemCountInSafetyGroup) * 100);
//                        var indexLabelValue = actualValuesToChart + "%";
//                        taskStandardschartdataPoints.push({ y: actualValuesToChart, label: "Safety", indexLabel: indexLabelValue });
//                    case "Specific Knowledge":
//                        var numberOfItemsChecked = 0;
//                        for (var i = 1; i < totalItemCountInSpecificKnowledgeGroup + 1; i++) {
//                            var internalName = "SpecificKnowledge" + i;
//                            var yValue = oListItem.get_item(internalName);
//                            if (yValue == '1') {
//                                var yValue2 = oListItem.get_item(internalName);
//                                numberOfItemsChecked += 1;
//                                totalPercent += 1;
//                            }
//                        }
//                        var actualValuesToChart = Math.round((numberOfItemsChecked / totalItemCountInSpecificKnowledgeGroup) * 100);
//                        var indexLabelValue = actualValuesToChart + "%";
//                        taskStandardschartdataPoints.push({ y: actualValuesToChart, label: "Specific Knowledge", indexLabel: indexLabelValue });
//                    case "General":
//                        var numberOfItemsChecked = 0;
//                        for (var i = 1; i < totalItemCountInGeneralGroup + 1; i++) {
//                            var internalName = "General" + i;
//                            var yValue = oListItem.get_item(internalName);
//                            if (yValue == '1') {
//                                var yValue2 = oListItem.get_item(internalName);
//                                numberOfItemsChecked += 1;
//                                totalPercent += 1;
//                            }
//                        }

//                        var actualValuesToChart = Math.round((numberOfItemsChecked / totalItemCountInGeneralGroup) * 100);
//                        var indexLabelValue = actualValuesToChart + "%";
//                        taskStandardschartdataPoints.push({ y: actualValuesToChart, label: "General", indexLabel: indexLabelValue });
//                }
//            }
//            if (totalPercent > 0) {
//                var averageTotal = Math.round((totalPercent / totalItemsFromAllGroups) * 100);
//                var indexTotalLabelValue = averageTotal + '%';
//                taskStandardschartdataPoints.unshift({ y: averageTotal, label: "Total %", indexLabel: indexTotalLabelValue });
//            }
//        }
//        var chart = new CanvasJS.Chart("TaskStandardContainer", {
//            title: {
//                text: "",
//                fontFamily: "Segoe UI Light,Segoe UI,Segoe,Tahoma,Helvetica,Arial,sans-serif",
//                fontSize: 15
//            },
//            animationEnabled: true,
//            axisX: {
//                interval: 1,
//                gridThickness: 0,
//                labelFontSize: 15,
//                labelFontStyle: "normal",
//                labelFontWeight: "bolder",
//                labelFontFamily: "Segoe UI Light,Segoe UI,Segoe,Tahoma,Helvetica,Arial,sans-serif"

//            },
//            axisY: {
//                tickThickness: 0,
//                lineThickness: 0,
//                valueFormatString: " ",
//                gridThickness: 0
//            },
//            height: 150,
//            width: 690,
//            theme: "theme2",
//            data: [
//            {
//                type: "bar",
//                name: "TaskStandardNames",
//                axisYType: "primary",
//                indexLabelFontSize: 18,
//                toolTipContent: "<span style='\"'color: {color};'\"'>{label}: </span><span style='\"'font-size: 20px; color:peru '\"'>{indexLabel}</span>",
//                indexLabelPlacement: "inside",
//                indexLabelFontColor: "white",
//                indexLabelFontWeight: 500,
//                indexLabelFontFamily: "Segoe UI Light,Segoe UI,Segoe,Tahoma,Helvetica,Arial,sans-serif",
//                dataPoints: taskStandardschartdataPoints
//            }

//            ]
//        });
//        chart.render();

//        $("input[title='RRCL Sign Off Supervisor or Trainer']").val(supervisorSignOff);

//        //Get the value from the feeder from
//        if (supervisorSignOffDate != null && supervisorSignOffDate != 'null' && supervisorSignOffDate) {
//            var frmtSignOffDate = new Date(supervisorSignOffDate);
//            var validSignOffDate = (frmtSignOffDate.getMonth() + 1) + "/" + frmtSignOffDate.getDate() + "/" + frmtSignOffDate.getFullYear();
//            $("input[title='RRCL Sign Off Supervisor or Trainer Date']").val(validSignOffDate);


//        }
//        var operatorName = $("input[title='Employee Name']").val();
//        //Get the current URL
//        var currentURL;
//        if (currentLocation.indexOf("EditForm.aspx") != -1) {
//            currentURL = window.location.href.split('&')[0];
//        }
//        else {
//            currentURL = 'https://arlingtonva.sharepoint.com/sites/wpcb/mswpo';
//        }
//        var FeederFormListName = encodeURIComponent(GetTaskStandardsListName());

//        //Normal message for the operator
//        $('#lblOperatorName').html('The Supervisor Sign off and date are pulled from \'Task Standards Feeder Form\' of <b>' + operatorName + '</b>. ');

//        var URLToTheFeederForm = 'https:\/\/arlingtonva.sharepoint.com\/sites\/wpcb\/mswpo\/Lists\/' + FeederFormListName + '\/EditForm.aspx?ID=' + TaskStandardsFeederFormID + "&source=" + currentURL;

//        $('#anchorTaskStandardURL').attr("href", URLToTheFeederForm);
//        $('#anchorTaskStandardURL').attr("class", 'feederFormAnchor');
//        $('#anchorTaskStandardURL').attr("target", "_self");
//        $('#anchorTaskStandardURL').html('Open the form!');
//    }
//    else {//There is no feeder form

//        //No feeder form for Training Documents for this operator. Show Message
//        var operatorName = $("input[title='Employee Name Required Field']").val();

//        //Get the Task Standards list name
//        var FeederFormListName = GetTaskStandardsListName();

//        //Get the first part of the URL with out the 'Source' portion of the default SharePoint
//        var currentURL;
//        if (currentLocation.indexOf("EditForm.aspx") != -1) {
//            currentURL = window.location.href.split('&')[0];
//        }
//        else {
//            currentURL = 'https://arlingtonva.sharepoint.com/sites/wpcb/mswpo';
//        }

//        //Create the New URL to the feeder form
//        var New_URL_TaskStandardsFeederForm = 'https:\/\/arlingtonva.sharepoint.com\/sites\/wpcb\/mswpo\/Lists\/' + FeederFormListName + '\/NewForm.aspx?source=' + currentURL + '&opname=' + operatorName;

//        //Dissolving Pop Up message:
//        //Set the behaviour of anchor based on form
//        var targetType
//        if (currentLocation.indexOf("NewForm.aspx") != -1) {
//            targetType = "_blank";
//        }
//        else {
//            targetType = "_self";
//        }

//        var New_URL_Anchor_TaskStandardsFeederForm = '<a href=\"' + New_URL_TaskStandardsFeederForm + '" target=\"' + targetType + '">Click Here<\/a> to create one.';

//        var message = 'Oops! There is no data to show you!.<br\/> It looks like there is no feeder form for <b>' + operatorName + '</b>. ' + New_URL_Anchor_TaskStandardsFeederForm;
//        $(".fade_div").html(message);
//        $('.fade_div').finish().show().delay(9000).fadeOut("slow");


//        $('#lblOperatorName').html('The \'Supervisor Signoff\' and \'Date\' are pulled from \'Task Standards Feeder Form\' of <b>' + operatorName + '</b>.<br/> But it appears that there is no form created yet');
//        $('#anchorTaskStandardURL').attr("href", New_URL_TaskStandardsFeederForm);
//        $('#anchorTaskStandardURL').attr("class", 'feederFormAnchor');
//        $('#anchorTaskStandardURL').html('Create a new form!');

//    }

//    //Set the behaviour of anchor based on form
//    if (currentLocation.indexOf("NewForm.aspx") != -1) {
//        $('#anchorTaskStandardURL').attr("target", "_blank");
//    }
//    else {
//        $('#anchorTaskStandardURL').attr("target", "_self");
//    }
//}
//function onRetrieveTaskStandardsInfoFailed(sender, args) {
//    alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
//}














