﻿var returnedArrays;
var operatorCetrificationEmployeeDataListID = '68C451AE-426B-4CFA-B2DC-B101D8D115DF'; //Operator Certification and Employee Data: System_x0020_Defined_x0020_Opera
var OperatorStationAssignment = 'C2932C64-DF7B-4221-85D3-5E3A11FDC2D5';
var SupervisorStationAssignment = 'C18CC7CF-4BB6-4D55-BCCD-9D252976D75B';
var isFormValid = true;


SP.SOD.executeFunc('sp.js', 'SP.ClientContext', PopulateForm);

$(document).ready(function () {
    $('#selectOperator').trigger("change");
});
function PopulateForm() {
    //Edit and Display Form
    if (currentLocation.indexOf("DispForm.aspx") != -1 || currentLocation.indexOf("EditForm.aspx") != -1) {
        var delay = 3000; //10 second
        setTimeout(function () {
            $('select[title="Shift Name"]').prop('disabled', true);
            $("input[title='Shift Date']").prop('disabled', true);
            $("input[title='Shift Date']").parent().next().closest('td').find("img:first").css('display', 'none')
            $('#btnPreviousValues').prop('disabled', true);

            var title = $("input[title='Title Required Field']").val();
            if (currentLocation.indexOf("DispForm.aspx") != -1) {
                title = $('span[data-displayname="Title"]').text();
            }

            if (title) {
                title = title.replace(/\s/g, '');
                var CAMLQuery = '<View><Query><Where><Eq><FieldRef Name=\'Title\' \/> <Value Type=\'Text\'>' + title + '<\/Value><\/Eq><\/Where><\/Query></View>';
                executeonFormValid(CAMLQuery);
            }
        }, delay);
    }
}
//Add button functionality
$('#add_button').click(function () {

    var isFormaValidToAdd = true;
    //Do nothing if the its the last child
    var isLastChild = $(this).closest('.child_div').is(':last-child');
    var currentRowWithControls = $('.child_div:last');
    var errorMessage = '';
    if (isLastChild == false) {
        //1. Check the station Dropdown list
        var selectedStation = currentRowWithControls.find('#selectStation').val();
        if (selectedStation == 'null' || selectedStation == null) {
            errorMessage += '<i class="fa fa-hand-o-right" aria-hidden="true"></i> Please select a station. <br/>';
            isFormaValidToAdd = false;
        }
        //2. Check the operator Dropdown list
        var selectedOperator = currentRowWithControls.find('#selectOperator').val();
        if (selectedOperator == 'null' || selectedOperator == null) {
            errorMessage += '<i class="fa fa-hand-o-right" aria-hidden="true"></i> Please select an operator.<br/>';
            isFormaValidToAdd = false;
        }
        //3. Check Recertification
        if (currentRowWithControls.find('#chbxReCertification').is(':checked')) {
            //check if the level is selected
            var selectedLevel = currentRowWithControls.find('#selectLevel').val();
            if (selectedLevel == 'null' || selectedLevel == null) {
                errorMessage += '<i class="fa fa-hand-o-right" aria-hidden="true"></i> Re-Certification requires to select the training level<br/>';
                isFormaValidToAdd = false;
            }
        }
        //4. Check In-Training
        if (currentRowWithControls.find('#chbxInTraining').is(':checked')) {
            //check if training hour are valid
            var trainingHours = currentRowWithControls.find('#txtHours').val();
            if (!trainingHours) {
                errorMessage += '<i class="fa fa-hand-o-right" aria-hidden="true"></i> Please enter trianing hours.<br/>';
                isFormaValidToAdd = false;
            }
            else {
                if (trainingHours > 12 || trainingHours < 1) {
                    errorMessage += '<i class="fa fa-hand-o-right" aria-hidden="true"></i> Please enter hours between 1 and 12 only.<br/>';
                    isFormaValidToAdd = false;
                }
            }
            //check if the level is selected
            var selectedLevel = currentRowWithControls.find('#selectLevel').val();
            if (selectedLevel == 'null' || selectedLevel == null) {
                errorMessage += '<i class="fa fa-hand-o-right" aria-hidden="true"></i> Please select the level the operator is training at.<br/>';
                isFormaValidToAdd = false;
            }
            //check if the trainer is selected
            var selectedTrainer = currentRowWithControls.find('#selectTrainer').val();
            if (selectedTrainer == 'null' || selectedTrainer == null) {
                errorMessage += '<i class="fa fa-hand-o-right" aria-hidden="true"></i>Please select the trainer.<br/>';
                isFormaValidToAdd = false;
            }
        }
        if (errorMessage) { //show only if the message is not empty
            showMsg(errorMessage);
        }
    }
    //If the form or row is valid, add a row
    if (isFormaValidToAdd == true) {
        var html = $('.child_div:first').parent().html();
        var $htmlChange = $(html);
        $htmlChange.find('#chbxInTraining').prop('disabled', false);
        $htmlChange.find('#chbxReCertification').prop('disabled', false);

        if ($htmlChange != 'undefined') {
            $htmlChange.insertBefore(this);
        }
    }
});

//Remove button click
$(document).on("click", ".deleteButton", function () {
    //Check if its the last row.
    var isLastChild = $(this).closest('.child_div').is(':last-child');
    if (isLastChild == false) {
        //IF NOT last row delete
        $(this).closest('.child_div').remove();
    }
    else {
        //If it is the last row, prevent the user from deletion and show him the message.
        showMsg('You cannot delete this item!');
    }
});

//Re-certification Click
$(document).on("click", "#chbxReCertification", function () {
    if (this.checked) {
        //Add default 12 hours to hours
        $(this).closest('.child_div').find('#txtHours').val(12);
        //Enable level
        $(this).closest('.child_div').find('#selectLevel').prop('disabled', false);
        //Disable Training Check box
        $(this).closest('.child_div').find('#chbxInTraining').prop('disabled', true);
        //Disable Trainer
        $(this).closest('.child_div').find('#selectTrainer').prop('disabled', true);
        //Disable hours
        $(this).closest('.child_div').find('#txtHours').prop('disabled', true);
    }
    else {
        //Disable the level dropdown
        $(this).closest('.child_div').find('#selectLevel').prop('disabled', true);
        $(this).closest('.child_div').find('#selectLevel').find('option:first').attr('selected', 'selected');
        //Clear the hours textbox
        $(this).closest('.child_div').find('#txtHours').val('');
        //Enable Training Check box
        $(this).closest('.child_div').find('#chbxInTraining').prop('disabled', false);
    }
});

//In-Training Check box click
$(document).on("click", "#chbxInTraining", function () {
    if (this.checked) {
        //Enable hours
        $(this).closest('.child_div').find('#txtHours').prop('disabled', false);
        //Enable Level
        $(this).closest('.child_div').find('#selectLevel').prop('disabled', false);
        //Disable Recertification Check box
        $(this).closest('.child_div').find('#chbxReCertification').prop('disabled', true);
        //Enable Trainer
        $(this).closest('.child_div').find('#selectTrainer').prop('disabled', false);
    }
    else {
        //Disable the level dropdown
        $(this).closest('.child_div').find('#selectLevel').prop('disabled', true);
        //Clear the hours textbox and disable it
        $(this).closest('.child_div').find('#txtHours').prop('disabled', true);
        $(this).closest('.child_div').find('#txtHours').val('');
        //Enable Re-Certification Check box
        $(this).closest('.child_div').find('#chbxReCertification').prop('disabled', false);
        //Disable Trainer
        $(this).closest('.child_div').find('#selectTrainer').prop('disabled', true);
    }
});

$(document).on("change", "#selectOperator", function () {
    var selectedOperator = $(this).closest('.child_div').find('#selectOperator').val();
    RetrieveOperatorInfoForAllStations(selectedOperator, $(this));
});

//The following function returns the operator current certfication status
function RetrieveOperatorInfoForAllStations(optrName, ddl) {

    var d = $.Deferred();
    //Following are basic sharepoint JSOM Operations and are self-explanatory
    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web().get_lists().getById(operatorCetrificationEmployeeDataListID); // Call Operator Certification and Employee Data
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(
        '<View><Query> <Where> <Eq> <FieldRef Name=\'System_x0020_Defined_x0020_Opera\' \/> <Value Type=\'Lookup\'>' + optrName + '<\/Value> <\/Eq> <\/Where> <\/Query></View>'
    );

    operatorLevelInfo = oList.getItems(camlQuery);
    clientContext.load(operatorLevelInfo);

    var o = { d: d, operatorLevelInfo: operatorLevelInfo };
    clientContext.executeQueryAsync(Function.createDelegate(o, onretrieveOperatorInfoQuerySucceeded), Function.createDelegate(o, onretrieveOperatorInfoQueryFailed));

    return d.promise();

    function onretrieveOperatorInfoQuerySucceeded() {
        var totalOperatorCount = operatorLevelInfo.get_count();
        if (totalOperatorCount == 0) {
            console.log("Something went wrong, could not fetch operator info.");
        } else {
            console.log("Fetched operator info.");
            var listLevel1ItemEnumerator = operatorLevelInfo.getEnumerator();
            var resultArray = [];

            while (listLevel1ItemEnumerator.moveNext()) {
                var oListItem = listLevel1ItemEnumerator.get_current();
                //1. Operator Name
                var operatorName = oListItem.get_item('System_x0020_Defined_x0020_Opera').get_lookupValue();

                //2. Current Levels at all Stations
                var PrimaryCurrentLevel = oListItem.get_item('Primary_x0020_Current_x0020_Leve');
                var SecondaryCurrentLevel = oListItem.get_item('Secondary_x0020_Current_x0020_Le');
                var AWTCurrentLevel = oListItem.get_item('AWT_x0020_Current_x0020_Level');
                var DWBCurrentLevel = oListItem.get_item('DWB_x0020_Current_x0020_Level');

                resultArray.push([PrimaryCurrentLevel, SecondaryCurrentLevel, AWTCurrentLevel, DWBCurrentLevel]);
                var formattedTable = createTableToDisplay(resultArray, operatorName).replace(/"/g, "'");;
                var insertHTML = '<a href="" id="operatorInfo" data-toggle="popover" data-trigger="hover" data-content="' + formattedTable + '"><i class="fa fa-info-circle" aria-hidden="true" style="padding: 0px;margin-left: -16px;margin-right: -3px;"></i></a>';
                $(ddl).closest('.child_div').find('[id="operatorInfo"]').remove();
                $(ddl).closest('.child_div').find('#tdddlSelectOperator').prepend(insertHTML);

                $('[data-toggle="popover"]').popover({
                    html: true,
                });
                $('[data-toggle="popover"]').on('click', function (e) { e.preventDefault(); return true; });
            }
            //Prepare array to return on success.
            d.resolve(resultArray);
        }
    }
    function onretrieveOperatorInfoQueryFailed() {
        console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}
//Format it as table to display
function createTableToDisplay(resultsArray, selectedOperator) {
    var prefix = '<label style="font-weight:normal;font-size:0.99em !important;">Current levels for: <b>' + selectedOperator + '</b></label><br/>';
    var table = prefix + "<table class='table'>"; // Open Table
    table += '<tr style="font-size:1.0em !important;"><th style="font-weight:normal;">Primary</th><th style="font-weight:normal;">Secondary</th><th style="font-weight:normal;">AWT</th><th style="font-weight:normal;">DWB</th></tr>';
    for (i = 0; i < resultsArray.length; i++) {
        table += "<tr>"; // Open Row
        for (i2 = 0; i2 < resultsArray[i].length; i2++) {
            table += "<td>" + resultsArray[i][i2] + "</td>"; // Each Column
        }
        table += "</tr>"; // Close Row
        table += "</table>" //Close Table
    }
    return table;
}
//Previous Values button click
$('#btnPreviousValues').click(function () {
    var isCurrentFormValid = true;
    //Validate Date
    var selectedDate = $("input[title='Shift Date']").val(); //$('#txtCalender').val();
    if (selectedDate == '') {
        showMsg('Please select a date for the Shift');
        isCurrentFormValid = false;
    }

    //Validate Shift
    var selectedShiftValue = $('select[title="Shift Name"]').val();
    if (!selectedShiftValue) {
        showMsg('Please select a Shift');
        isCurrentFormValid = false;
    }
    else {
        //Disable to avoid multiple resubmits
        $('#btnPreviousValues').prop('disabled', true);
        if (isCurrentFormValid == true) {
            //debugger;
            var strCAMLQuery = '<View><Query> <Where> <Eq> <FieldRef Name=\'operatorshift\' \/> <Value Type=\'Choice\'>' + selectedShiftValue + '<\/Value> <\/Eq> <\/Where> <OrderBy> <FieldRef Name=\'Modified\' Ascending=\'False\' \/> <\/OrderBy><RowLimit>10<\/RowLimit> <\/Query></View>';
            executeonFormValid(strCAMLQuery);
        }
    }
});

$('#btnDeleteTest').click(function () {
    //Validate Date
    var selectedDate = $("input[title='Shift Date']").val();
    //Validate Shift
    var selectedShift = $('select[title="Shift Name"]').val();
    //Get the selected date and format as yyyy_mm_dd
    var strDate = new Date(selectedDate);
    //Conver date to YYYY_MM_DD
    Date.prototype.yyyymmdd = function () {
        var yyyy = this.getFullYear().toString();
        var mm = (this.getMonth() + 1).toString(); // getMonth() is zero-based
        var dd = this.getDate().toString();
        return yyyy + '_' + (mm[1] ? mm : "0" + mm[0]) + '_' + (dd[1] ? dd : "0" + dd[0]); // padding
    };
    //Format the title for the item to be saved.
    var formatTitle = 'SSA_' + strDate.yyyymmdd() + selectedShift.replace('Shift ', '_');
    //debugger;
    DeleteItemsWithKey(formatTitle);
});

//If the form is valid then pull the previous or old values
function executeonFormValid(strCAMLQuery) {
    //Get the previous Values
    //debugger;
    var supervisorPreviousValues = ExecuteGetSupervisorPreviousValues(strCAMLQuery);
    var titleCheck = '';
    //Populate section with values
    supervisorPreviousValues.done(function (result) {
        var returnedDoneArrays = result;
        if (!$.isEmptyObject(returnedDoneArrays) !== -1) {
            returnedArrays = returnedDoneArrays;

            for (var i = 0; i < returnedArrays.length; i++) {
                //debugger;
                //(title, Station, hours, level, datestamp, training, operatorshift, assignmentshift, operator, recertification, trainer);
                //Get the template to add
                var html = $('.child_div:first').parent().html();
                var $htmlChange = $(html);

                var returnedArray = returnedArrays[i];
                var title = returnedArray[0];
                if (i == 0) {
                    titleCheck = title;
                }
                var Station = returnedArray[1];
                var hours = returnedArray[2];
                var level = returnedArray[3];
                var datestamp = returnedArray[4];
                var training = returnedArray[5];
                var operatorshift = returnedArray[6];
                var assignmentshift = returnedArray[7];
                var operator = returnedArray[8];
                var recertification = returnedArray[9];
                var trainer = returnedArray[10];

                //Select Operator
                $htmlChange.find('#tdddlSelectOperator select option[value="' + operator + '"]').prop('selected', 'selected').change();
                //Select Station
                $htmlChange.find('#tdddlselectStation select option').each(function (index, element) {
                    if (element.value == Station) {
                        $(this).prop("selected", true);
                    }
                });
                //Recertification
                $htmlChange.find('#chbxReCertification').prop("checked", recertification);
                if (recertification)
                {
                    $htmlChange.find("#txtHours").val(12);
                }
                //Training
                $htmlChange.find('#chbxInTraining').prop("checked", training);
                //Hours
                if (training == true) {
                    $htmlChange.find("#txtHours").val(hours);
                    $htmlChange.find("#txtHours").prop('disabled', false);
                }
                //Select Level
                $htmlChange.find('#tdddlselectLevel select option').each(function (index, element) {
                    if (element.value == level) {
                        $htmlChange.find('#tdddlselectLevel select').prop('disabled', false);
                        $(this).prop("selected", true);
                    }
                });
                //Select Trainer
                if (trainer) {
                    $htmlChange.find('#tdddlselectTrainer select').prop('disabled', false);
                    $htmlChange.find('#tdddlselectTrainer select option[value="' + trainer + '"]').prop('selected', 'selected').change();
                }
                //Populate after all changes
                if ($htmlChange != 'undefined') {
                    if (titleCheck == title) {
                        $htmlChange.insertBefore($('#add_button'));
                    }
                }
                //debugger;
            }
        }
    });
}

/* Populates the list of operators */
function ExecuteGetSupervisorPreviousValues(strCAMLQuery) {

    var d = $.Deferred();
    //Get the sharepoint context based on the SiteUrl
    var clientContext = new SP.ClientContext(siteUrl);
    //Find the list to fetch the operators based on the GUID
    var oList = clientContext.get_web()
        .get_lists()
        .getById(OperatorStationAssignment);
    //Create a CAML Query
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(strCAMLQuery);

    //Fetch the operator information using the CAML Query.
    supervisorPreviousInfo = oList.getItems(camlQuery);
    clientContext.load(supervisorPreviousInfo);

    //Make the asychronous call.
    var o = { d: d, supervisorPreviousInfo: supervisorPreviousInfo };
    clientContext.executeQueryAsync(Function.createDelegate(o, OnOptrAssgnmtListQuerySucceeded), Function.createDelegate(o, OnOptrAssgnmtListQueryFailed));

    return d.promise();
    //Query Succeeded.
    function OnOptrAssgnmtListQuerySucceeded() {

        var listItemEnumerator = this.supervisorPreviousInfo.getEnumerator();
        var totalItemsCount = this.supervisorPreviousInfo.get_count();
        var itemsArray = [];
        if (totalItemsCount == 0) {
            showMsg('Could not fetch values. Please add operators manually');
            console.log('Could not fetch operator info');
        }
        else {
            console.log('Entered totalTrainerCount > 0');

            while (listItemEnumerator.moveNext()) {
                var oListItem = listItemEnumerator.get_current();
                var title = oListItem.get_item('Title');
                var Station = oListItem.get_item('Station');
                var hours = oListItem.get_item('hours');
                var level = oListItem.get_item('level');
                var datestamp = oListItem.get_item('datestamp');
                var training = oListItem.get_item('training');
                var operatorshift = oListItem.get_item('operatorshift');
                var assignmentshift = oListItem.get_item('assignmentshift');
                var operator = oListItem.get_item('operator');
                var recertification = oListItem.get_item('recertification');
                //debugger;
                var trainer = oListItem.get_item('trainerorsme');
                if (trainer != undefined && trainer != null) {
                    //debugger;
                    trainer = oListItem.get_item('trainerorsme').get_lookupValue();//Person or Group Column
                    console.log('Trainer - ' + trainer);
                }
                itemsArray.push([title, Station, hours, level, datestamp, training, operatorshift, assignmentshift, operator, recertification, trainer]);
            }
            //debugger;
            d.resolve(itemsArray);
        }
    }
    //Query Failed.
    function OnOptrAssgnmtListQueryFailed() {
        console.log('Request failed in GetSupervisorPreviousValues ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}

//Do the task before saving this form
function PreSaveAction() {
    //Validate Date
    var selectedDate = $("input[title='Shift Date']").val();
    if (selectedDate == '') {
        showMsg('Please select a date for the Shift');
        return false;
    }
    //Validate Shift
    var selectedShift = $('select[title="Shift Name"]').val();
    if (!selectedShift) {
        showMsg('Please select a Shift');
        return false;
    }

    //Get the selected date and format as yyyy_mm_dd
    var strDate = new Date(selectedDate);
    //Conver date to YYYY_MM_DD
    Date.prototype.yyyymmdd = function () {
        var yyyy = this.getFullYear().toString();
        var mm = (this.getMonth() + 1).toString(); // getMonth() is zero-based
        var dd = this.getDate().toString();
        return yyyy + '_' + (mm[1] ? mm : "0" + mm[0]) + '_' + (dd[1] ? dd : "0" + dd[0]); // padding
    };
    //Format the title for the item to be saved.
    var formatTitle = 'SSA_' + strDate.yyyymmdd() + selectedShift.replace('Shift ', '_');
    $("input[title='Title Required Field']").val(formatTitle);

    var checkControlValues = []; //Prepare controls to validate
    $('.child_div').each(function (i, obj) {
        //Loop through each row of div and create and array
        var selectedOperator = $(this).find('#selectOperator').val();
        if (selectedOperator != 'null' && selectedOperator != null && selectedOperator != '') {
            var selectedStation = $(this).find('#selectStation').val();
            var isOperatorRecertifying = $(this).find('#chbxReCertification').is(":checked");
            var isOperatorTraining = $(this).find('#chbxInTraining').is(":checked");
            var hours = $(this).find('#txtHours').val();
            var SelectedLevel = $(this).find('#selectLevel').val();
            var SelectedTrainer = $(this).find('#selectTrainer').val();

            checkControlValues.push([formatTitle, selectedOperator, selectedStation, isOperatorRecertifying, isOperatorTraining, hours, SelectedLevel, SelectedTrainer, strDate, selectedShift]);
            console.log('Operator = ' + selectedOperator + " | Selected Station = " + selectedStation, " | isOperatorRecertifying = " + isOperatorRecertifying + " | isOperatorTraining=" + isOperatorTraining + " |Hours=" + hours + " |SelectedLevel" + SelectedLevel + " |SelectedTrainer" + SelectedTrainer);
        }
    });

    //Check if the same operator is selected twice.
    var haveDuplicateOperators = ValidateForDuplicateOperators(checkControlValues);
    if (haveDuplicateOperators == true) {
        showMsg('You selected the same operator twice, please check!');
        return false;
    }
    else {
        //Only on NewForm.aspx
        AddorUpdateOptrStnAssignmentList(checkControlValues);
    }

    return true;
}


function ValidateForDuplicateOperators(controlValues) {
    var duplicateOperator = false;
    for (var i = 0; i < controlValues.length; i++) {
        var selectedOperator = controlValues[i][1];
        for (var j = 0; j < controlValues.length; j++) {
            if (i != j) {
                if (selectedOperator == controlValues[j][1]) {
                    duplicateOperator = true;
                }
            }
        }
    }
    return duplicateOperator;
}

/* Check if the items exists */
function CheckUniqueness(title) {

    var d = $.Deferred();
    //Get the sharepoint context based on the SiteUrl
    var clientContext = new SP.ClientContext(siteUrl);
    //Find the list to fetch the operators based on the GUID
    var oList = clientContext.get_web()
        .get_lists()
        .getById(SupervisorStationAssignment);
    //Create a CAML Query
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml("<View><Query> <Where> <Eq> <FieldRef Name=\'Title\' \/> <Value Type=\'Text\'>" + title + "<\/Value> <\/Eq> <\/Where> <\/Query></View>");

    //Fetch the operator information using the CAML Query.
    UniquenessInfo = oList.getItems(camlQuery);
    clientContext.load(UniquenessInfo);

    //Make the asychronous call.
    var o = { d: d, UniquenessInfo: UniquenessInfo };
    clientContext.executeQueryAsync(Function.createDelegate(o, OnOptrAssgnmtListQuerySucceeded), Function.createDelegate(o, OnOptrAssgnmtListQueryFailed));

    return d.promise();
    //Query Succeeded.
    function OnOptrAssgnmtListQuerySucceeded() {
        var totalItemsCount = this.UniquenessInfo.get_count();
        console.log(totalItemsCount);
        var itemsArray = [];
        if (totalItemsCount == 0) {
            d.resolve('true'); //Uniqueness passed
        }
        else {
            console.log('Entered totalTrainerCount > 0');
            d.resolve('false');//Uniqueness failed
        }
    }
    //Query Failed.
    function OnOptrAssgnmtListQueryFailed() {
        console.log('Request failed in GetSupervisorPreviousValues ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}

function AddorUpdateOptrStnAssignmentList(controlValues) {

    var titleKey = controlValues[0][0];
    if (titleKey) {
        var cleanUpOperatorList = DeleteItemsWithKey(titleKey);
        cleanUpOperatorList.done(function (result) {
            //Get the sharepoint context based on the SiteUrl
            var clientContext = new SP.ClientContext(siteUrl);
            //Find the list to fetch the operators based on the GUID
            var oList = clientContext.get_web()
                .get_lists()
                .getById(OperatorStationAssignment);
            for (var i = 0; i < controlValues.length; i++) {
                var TitleKey = controlValues[i][0];
                var selectedOperator = controlValues[i][1];
                var selectedStation = controlValues[i][2];
                var isOperatorRecertifying = controlValues[i][3];
                var isOperatorTraining = controlValues[i][4];
                var hours = controlValues[i][5];
                var SelectedLevel = controlValues[i][6];
                var SelectedTrainer = controlValues[i][7];
                var dateStamp = controlValues[i][8];
                var Shift = controlValues[i][9];

                var itemCreateInfo = new SP.ListItemCreationInformation();
                var oListItem = oList.addItem(itemCreateInfo);

                oListItem.set_item('operator', selectedOperator);
                oListItem.set_item('Title', TitleKey);
                oListItem.set_item('Station', selectedStation);
                if (hours) {
                    oListItem.set_item('hours', hours);
                }
                if (isOperatorRecertifying) {
                    oListItem.set_item('recertification', isOperatorRecertifying);
                    oListItem.set_item('level', SelectedLevel);
                }
                if (isOperatorTraining) {
                    oListItem.set_item('training', isOperatorTraining);
                    oListItem.set_item('hours', hours);
                    oListItem.set_item('level', SelectedLevel);
                    //Add Trainer
                    if (SelectedTrainer) {
                        var trainer = new Array();
                        trainer.push(SP.FieldUserValue.fromUser(SelectedTrainer));
                        oListItem.set_item('trainerorsme', trainer);
                    }
                }

                oListItem.set_item('datestamp', dateStamp);
                oListItem.set_item('operatorshift', Shift);

                oListItem.update();
                clientContext.load(oListItem);
               
            }
            clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceeded), Function.createDelegate(this, this.onQueryFailed));
            function onQuerySucceeded() {
                console.log('Item created:');
            }

            function onQueryFailed(sender, args) {
                console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
            }
          
        });
    }
    
}


function DeleteItemsWithKey(titleKey) {
    //debugger;
    var d = $.Deferred();
    //Get the sharepoint context based on the SiteUrl
    var clientContext = new SP.ClientContext(siteUrl);
    //Find the list to fetch the operators based on the GUID
    var oList = clientContext.get_web()
        .get_lists()
        .getById(OperatorStationAssignment);
    //Create a CAML Query
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml("<View><Query><Where> <Eq> <FieldRef Name=\'Title\' \/> <Value Type=\'Text\'>" + titleKey + "<\/Value> <\/Eq> <\/Where> <\/Query></View>");

    //Fetch the operator information using the CAML Query.
    var deleteItemsInfo = oList.getItems(camlQuery);
    clientContext.load(deleteItemsInfo);

    //Make the asychronous call.
    var o = { d: d, deleteItemsInfo: deleteItemsInfo, clientContext: clientContext };
    clientContext.executeQueryAsync(Function.createDelegate(o, OnOptrAssgnmtListDeleteQuerySucceeded), Function.createDelegate(o, OnOptrAssgnmtListDeleteQueryFailed));

    return d.promise();
    //Query Succeeded.
    function OnOptrAssgnmtListDeleteQuerySucceeded() {
        // var listItemEnumerator = this.deleteItemsInfo.getEnumerator();
        var totalItemsCount = this.deleteItemsInfo.get_count();
        var itemsArray = [];
        if (totalItemsCount == 0) {
            d.resolve('No Cleaning Required')
            console.log('Could not fetch items that are required to delete or clean up');
        }
        else {
            //debugger;
            console.log('Entered totalTrainerCount > 0');
            for (var i = totalItemsCount - 1; i >= 0; i--) {
                var oListItem = deleteItemsInfo.itemAt(i);
                var operatorName = oListItem.get_item('operator');
                var station = oListItem.get_item('Station');
                var training = oListItem.get_item('training');
                var hours = oListItem.get_item('hours');
                //oListItem.deleteObject();
				if(training == "true"){
					hours = 0 - hours;
				}
				else{
					hours = 0 - 12;
				}					
                oListItem.set_item('hours', hours)
                oListItem.update();
                clientContext.executeQueryAsync(onQueryDeleteSucceeded, onQueryDeleteFailed);
                function onQueryDeleteSucceeded(sender, args) {
                    console.log('Item deleted');
                }
                function onQueryDeleteFailed(sender, args) {
                    console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
                }
            }
            d.resolve('Cleaning Required');
        }
    }
    //Query Failed.
    function OnOptrAssgnmtListDeleteQueryFailed() {
        console.log('Request failed in DeleteItemsWithKey ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}

//Change the default body for the Modal
function showMsg(body) {
    //Get the modal that needs to be changed
    var $msgModal = $('#errorModal').modal({
        backdrop: true,
        show: false,
        keyboard: false,
        width: 900
    });
    //Update the modal body
    $msgModal
      .find('.modal-header > h4').text('Aw, Snap! Something went wrong!').end()
      .find('.modal-body').html(body).end()
      .find('.callback-btn').off('click.callback')
      .on('click.callback', function () {
          $msgModal.modal('hide');
      }).end()
      .modal('show');
};