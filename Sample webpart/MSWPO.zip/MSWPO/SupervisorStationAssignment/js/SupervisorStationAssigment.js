﻿
var data =
     [
        { "OperatorName": 1, "Station": 2, "ReCertfication": true, "InTraining": true, "Hours": 11, "Level": 3, "Trainer": 2 },
        { "OperatorName": 2, "Station": 3, "ReCertfication": true, "InTraining": true, "Hours": 3, "Level": 2, "Trainer": 4 },
        { "OperatorName": 3, "Station": 1, "ReCertfication": false, "InTraining": false, "Hours": 4, "Level": 2, "Trainer": 1 },
        { "OperatorName": 4, "Station": 4, "ReCertfication": true, "InTraining": false, "Hours": 7, "Level": 3, "Trainer": 5 },
        { "OperatorName": 5, "Station": 2, "ReCertfication": true, "InTraining": false, "Hours": 9, "Level": 3, "Trainer": 4 },
        { "OperatorName": 6, "Station": 3, "ReCertfication": true, "InTraining": false, "Hours": 8, "Level": 3, "Trainer": 3 }
     ]

SP.SOD.executeFunc('sp.js', 'SP.ClientContext', GetOperatorInfo);
function GetOperatorInfo() {
    $("#jqGrid").jqGrid({
        url: 'data.json',
        // we set the changes to be made at client side using predefined word clientArray
        editurl: 'clientArray',
        styleUI: "Bootstrap",
        datatype: "json",
        //colNames: ['Operator Name', 'Station', 'Re Certfication', 'In Training', 'Hours', 'Level', 'Trainer'],
        colModel: [
            {
                label: 'Shift Date',
                name: 'Shift Date',
                width: 150,
                editable: true,
                edittype: "text",
                editoptions: {
                    // dataInit is the client-side event that fires upon initializing the toolbar search field for a column
                    // use it to place a third party control to customize the toolbar
                    dataInit: function (element) {
                        $(element).datepicker({
                            autoclose: true,
                            format: 'yyyy-mm-dd',
                            orientation: 'bottom'
                        });
                    }
                }
            },
            {
                label: 'Operator Name',
                name: 'OperatorName',
                key: true,
                editable: true,
                editoptions: { value: getAllOperators() },
                editrules: { required: true },
                edittype: 'select',
                formatter: 'select'
            },
            {
                label: 'Station',
                name: 'Station',
                editable: true,
                editoptions: { value: getAllStations() },
                editrules: { required: true },
                edittype: 'select',
                formatter: 'select'
            },
            {
                label: 'Re Certfication',
                name: 'ReCertfication',
                editable: true,
                edittype: 'checkbox',
                editoptions: { value: "True:False" },
                formatter: "checkbox",
                formatoptions: { disabled: false }
            },
            {
                label: 'In Training',
                name: 'InTraining',
                editable: true,
                edittype: 'checkbox',
                editoptions: { value: "True:False" },
                formatter: "checkbox",
                formatoptions: { disabled: false }
            },
            {
                label: 'Hours',
                name: 'Hours',
                editable: true
            },
            {
                label: 'Level',
                name: 'Level',
                editable: true,
                editoptions: { value: getAllLevels() },
                editrules: { required: true },
                edittype: 'select',
                formatter: 'select'
            },
            {
                label: 'Trainer',
                name: 'Trainer',
                editable: true,
                editoptions: { value: getAllTrainers() },
                editrules: { required: true },
                edittype: 'select',
                formatter: 'select'
            }
        ],
        sortname: 'OperatorName',
        sortorder: 'asc',
        loadonce: true,
        viewrecords: true,
        height: 240,
        width: 1200,
        rowNum: 10,
        pager: "#jqGridPager",
        pgbuttons: false,
        viewrecords: false,
        pgtext: "",
        pginput: false,
    });

    for (var i = 0; i <= data.length; i++)
        $("#jqGrid").jqGrid('addRowData', i + 1, data[i]);

    $('#jqGrid').navGrid('#jqGridPager',
        // the buttons to appear on the toolbar of the grid
        { edit: true, add: true, del: true, search: false, refresh: false, view: false, position: "left", cloneToTop: false },
        // options for the Edit Dialog
        {
            editCaption: "Edit Operator Station Assignment",
            recreateForm: true,
            checkOnUpdate: true,
            checkOnSubmit: true,
            closeAfterEdit: true,
            errorTextFormat: function (data) {
                return 'Error: ' + data.responseText
            }
        },
        // options for the Add Dialog
        {
            closeAfterAdd: true,
            recreateForm: true,
            errorTextFormat: function (data) {
                return 'Error: ' + data.responseText
            }
        },
        // options for the Delete Dailog
        {
            errorTextFormat: function (data) {
                return 'Error: ' + data.responseText
            }
        });
}


function getAllOperators() {
    var operators = { '0': 'Select', '1': 'Alex E. Wilson Jr.', '2': 'Ayoub Asghari', '3': 'Billy R. Jackson', '4': 'Brent Derr', '5': 'Christopher Hawthorne', '6': 'Dallas Christenbury', '7': 'David M. Robinson' };
    return operators;
}

function getAllStations() {
    var stations = { '0': 'Select', '1': 'Primary', '2': 'Secondary', '3': 'AWT', '4': 'DWB' };
    return stations;
}

function getAllLevels() {
    var stations = { '0': 'Select', '1': 'Level 1', '2': 'Level 2', '3': 'Level 3' };
    return stations;
}
function getAllTrainers() {
    var trainers = { '0': 'Select', '1': 'Alex E. Wilson Jr.', '2': 'Ayoub Asghari', '3': 'Billy R. Jackson', '4': 'Brent Derr', '5': 'Christopher Hawthorne', '6': 'Dallas Christenbury', '7': 'David M. Robinson' };
    return trainers;
}