﻿var currentFormUniqueId;
var currentFormWebPartId;
var currentLocation = window.location.href;
(function () {
    // jQuery library is required in this sample 
    document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/Shared/JQuery/jquery-2.2.4.min.js"><\/script>');
    document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/SupervisorStationAssignment/js/bootstrap.min.js"> </script>');
                                
    document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/SupervisorStationAssignment/js/jquery.loading-indicator.min.js"> </script>');

    document.write('<link href="/sites/wpcb/mswpo/SiteAssets/MSWPO/SupervisorStationAssignment/css/bootstrap.min.css" type="text/css" rel="stylesheet" />');
    document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/SupervisorStationAssignment/js/SSAPreRender.js"> </script>');

    document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/SupervisorStationAssignment/js/bootstrap-datepicker.js"> </script>');
    document.write('<script src="/sites/wpcb/mswpo/SiteAssets/MSWPO/SupervisorStationAssignment/js/bootstrapValidator.js"> </script>');
    document.write('<link href="/sites/wpcb/mswpo/SiteAssets/MSWPO/SupervisorStationAssignment/css/datepicker.css" type="text/css" rel="stylesheet" />');

   // ~site/SiteAssets/MSWPO/SupervisorStationAssignment/js/SSACore.js

    function _registerAccordionViewTemplate() {
        // Create object that have the context information about the field that we want to change it's output render  
        var saFormContext = {};
        saFormContext.Templates = {};

        // Add OnPostRender event handler to add accordion click events and style 
        saFormContext.OnPreRender = SAFormOnPreRender;
        saFormContext.OnPostRender = SAFormOnPostRender;

        SPClientTemplates.TemplateManager.RegisterTemplateOverrides(saFormContext);
    }
    function SAFormOnPreRender(ctx) {
        if (!currentFormUniqueId) {
            //Get the current form Unique ID
            currentFormUniqueId = ctx.FormUniqueId;

            //Get the Current from WebPart Id
            currentFormWebPartId = "WebPart" + ctx.FormUniqueId;

            jQuery(document).ready(function () {
                var formURL = GetFormURL();
                console.log('Writing to logn'+ formURL);
                //Add the new HTML created for accordion at the top of the web part
                $.get(formURL, function (data, status) {
                    jQuery("#" + currentFormWebPartId).prepend(data);
                });
            });
        }
    }
    function SAFormOnPostRender(ctx) {

    }
    ExecuteOrDelayUntilScriptLoaded(_registerAccordionViewTemplate, 'clienttemplates.js');
})();

function GetFormURL()
{
    return '/sites/wpcb/mswpo/SiteAssets/MSWPO/SupervisorStationAssignment/HTML/SSA.html';
}

