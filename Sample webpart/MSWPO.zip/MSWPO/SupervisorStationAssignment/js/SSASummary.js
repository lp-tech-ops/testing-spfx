﻿//List of Library IDs to loop
var siteUrl = '/sites/wpcb/mswpo';
var ListID = 'C2932C64-DF7B-4221-85D3-5E3A11FDC2D5';

SP.SOD.executeFunc('sp.js', 'SP.ClientContext', ShowOperatorStationAssignment);


function ShowOperatorStationAssignment() {
    //Selected Date Range
    var dataSet = [];
    var fetchValue = GetOperators();
    fetchValue.done(function (result) {
        var returnedValue = result;
        //Empty Dataset for data table
        if (returnedValue.length > 0) {
            debugger;
            dataSet.push(['Operator', 'Shift', 'Station']);
            for (var i = 0; i < returnedValue.length; i++) {
                var returnedArray = returnedValue[i];
                var operator = returnedArray[0];
                var shift = returnedArray[1];
                var station = returnedArray[2]
                dataSet.push([operator,shift,station]);
            }
            if (dataSet.length > 0) {
                debugger;   
                var cityTable = makeTable($('#divOperatorInfo'), dataSet);
            }
        }
        else
        {
            $('#divOperatorInfo').append('There are no items to show in this view of the "Supervisor Station Assignments" list. To add a new item, click "New"');
        }
    });
}
function makeTable(container, data) {
    var table = $("<table/>").addClass('customtable');
    $.each(data, function (rowIndex, r) {
        var row = $("<tr/>");
        $.each(r, function (colIndex, c) {
            row.append($("<t" + (rowIndex == 0 ? "h" : "d") + "/>").text(c));
        });
        table.append(row);
    });
    return container.append(table);
}
function GetShiftNames()
{  //Get the selected date and format as yyyy_mm_dd
    var strDate = new Date();
    var shiftNameArray = [];
    //Conver date to YYYY_MM_DD
    Date.prototype.yyyymmdd = function () {
        var yyyy = this.getFullYear().toString();
        var mm = (this.getMonth() + 1).toString(); // getMonth() is zero-based
        var dd = this.getDate().toString();
        return yyyy + '_' + (mm[1] ? mm : "0" + mm[0]) + '_' + (dd[1] ? dd : "0" + dd[0]); // padding
    };
    //Format the title for the item to be saved.
    var dateFormatted = strDate.yyyymmdd();
    shiftNameArray.push('SSA_' + dateFormatted + '_A');
    shiftNameArray.push('SSA_' + dateFormatted + '_B');
    shiftNameArray.push('SSA_' + dateFormatted + '_C');
    shiftNameArray.push('SSA_' + dateFormatted + '_D');
    debugger;
    return shiftNameArray;
}
function GetOperators() {
    var operatorArray = [];
    var d = $.Deferred();
    var shiftNameArray = GetShiftNames();
    var strCAML = "<View><Query> <Where> <Or> <Eq> <FieldRef Name=\'LinkTitle\' \/> <Value Type=\'Computed\'>" + shiftNameArray[0] + "<\/Value> <\/Eq> <Or> <Eq> <FieldRef Name=\'Title\' \/> <Value Type=\'Text\'>" + shiftNameArray[1] + "<\/Value> <\/Eq> <Or> <Eq> <FieldRef Name=\'Title\' \/> <Value Type=\'Text\'>" + shiftNameArray[2] + "<\/Value> <\/Eq> <Eq> <FieldRef Name=\'Title\' \/> <Value Type=\'Text\'>" + shiftNameArray[3] + "<\/Value> <\/Eq> <\/Or> <\/Or> <\/Or> <\/Where> <\/Query></View>";
    //var strCAML = "<View><Query> <Where> <Or> <Eq> <FieldRef Name=\'Title\' \/> <Value Type=\'Text\'>" + shiftNameArray[0] + "<\/Value> <\/Eq> <Eq> <FieldRef Name=\'Title\' \/> <Value Type=\'Text\'>" + shiftNameArray[1] + "<\/Value> <\/Eq> <Eq> <FieldRef Name=\'Title\' \/> <Value Type=\'Text\'>" + shiftNameArray[2] + "<\/Value> <\/Eq> <Eq> <FieldRef Name=\'Title\' \/> <Value Type=\'Text\'>" + shiftNameArray[3] + "<\/Value> <\/Eq> <\/Or> <\/Where> <\/Query></View>";
    var clientContext = new SP.ClientContext(siteUrl);
    var oList = clientContext.get_web()
         .get_lists()
        .getById(ListID);
 //   var strCAML = '<View><Query><OrderBy> <FieldRef Name=\'Created\' Ascending=\'False\' \/> <\/OrderBy><\/Query><RowLimit>20<\/RowLimit></View>';
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(strCAML);

    var itemsReturned = oList.getItems(camlQuery);
    clientContext.load(itemsReturned);

    var o = { d: d, listOfItems: itemsReturned, clientContext: clientContext };
    clientContext.executeQueryAsync(Function.createDelegate(o, successCallback), Function.createDelegate(o, failCallback));

    return d.promise();

    function successCallback() {
        var itemCount = this.listOfItems.get_count();
        debugger;
        console.log(itemCount);
        if (itemCount > 0) {
            var itemEnumerator = this.listOfItems.getEnumerator();
            while (itemEnumerator.moveNext()) {
                var oListItem = itemEnumerator.get_current();
                var operatorName = oListItem.get_item('operator');
                var Shift = oListItem.get_item('operatorshift');
                var Station = oListItem.get_item('Station');
                operatorArray.push([operatorName,Shift,Station]);
            }//end while
        }
        d.resolve(operatorArray);

    }
    function failCallback() {
        this.d.reject('something bad happened');
    }
}//end if
