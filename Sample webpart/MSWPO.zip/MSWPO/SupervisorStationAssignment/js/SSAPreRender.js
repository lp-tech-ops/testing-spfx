﻿/*
Author:      Susheel Dakoju
Date:        07/20/2016
Description: This the Prerender file for Supervisor Station Assignment
             URL : 'https://arlingtonva.sharepoint.com/sites/wpcb/mswpo/Lists/Supervisor%20Station%20Assignment'
*/

//Information on this List Forms is pulled from WPCB MSWPO Site
var siteUrl = '/sites/wpcb/mswpo/';

//Global variables
var operatorInfo;
var trainerInfo;
var supervisorPreviousInfo;
var availableOperators = [];

/*=*=*=*=**=*=*=*=**=*=*=*=*  Start List of IDs used  *=*=*=*=**=*=*=*=**=*=*=*=*/
var operatorsListID = '68C451AE-426B-4CFA-B2DC-B101D8D115DF';//Operator Certification and Employee Data : To fetch Operators
var MSWPOAccessManagementList = 'B441CA50-2EFB-425F-BF1B-E66EE18806B0'; // MSWPO Access Management List : To fetch Trainers.
var OperatorStationAssignment = 'C2932C64-DF7B-4221-85D3-5E3A11FDC2D5'; // Operator Station Assignment: List that contains the actual station assignment to Operators.
/*=*=*=*=**=*=*=*=**=*=*=*=*  End List of IDs used  *=*=*=*=**=*=*=*=**=*=*=*=*/

//Load the Activity Indicator
ExecuteOrDelayUntilBodyLoaded(LoadIndicator);

function LoadIndicator() {
    //The following line makes sure there is no conflict between version used in the SharePoint master page and version used for this page.
    $.noConflict();
    $('.ms-formtable').css("display", "none");;
    $(".ms-descriptiontext").css("display", "none");
    try {
        $(function () {
            var homeLoader = $('body').loadingIndicator({
                useImage: false,
            }).data("loadingIndicator");

            setTimeout(function () {
                homeLoader.hide();
            }, 8000);

        });
        $(document).ready(function () {
            SP.SOD.executeOrDelayUntilScriptLoaded(PopulateOperatorList, 'sp.js');
        })

    } catch (err) {
        console.log('Error at LoadIndicator' + err.message);
    }
}
//Populates the list of operators in the drop down list to be picked by Supervisors
function PopulateOperatorList() {

    //Hide the description at the bottom of the list.
    $('.ms-formtable').css("display", "none");;
    $(".ms-descriptiontext").css("display", "none");

    //Get the trainers list to be picked by Supervisor and assign it for station.
    var TrainerList = GetTrainerList();
    var TrainerListArray = [];

    TrainerList.done(function (result) {
        var returnedTrainerList = result;
        if (!$.isEmptyObject(returnedTrainerList) !== -1) {
            TrainerListArray = returnedTrainerList;
        }
        var availableOperators = PopulateOperatorListDropDown();
        var availableOperatorsArray = [];

        availableOperators.done(function (result) {
            var returnedavailableOperators = result;
            if (!$.isEmptyObject(returnedavailableOperators) !== -1) {
                availableOperatorsArray = returnedavailableOperators;
                //Use JQuery Autocomplete feature and provide with Available Operators.
                for (var i = 0; i < availableOperatorsArray.length; i++) {
                    //creates option tag
                    var text = 'Shift ' + availableOperatorsArray[i][1] + '-' + availableOperatorsArray[i][0];
                    var operatorName = availableOperatorsArray[i][0];

                    jQuery('<option/>', {
                        value: operatorName,
                        html: text
                    }).appendTo('#tdddlSelectOperator select'); //appends to select if parent td has id is dropdown

                    if (!$.isEmptyObject(TrainerListArray) !== -1) {
                        if (jQuery.inArray(operatorName, TrainerListArray) !== -1) {
                            jQuery('<option/>', {
                                value: operatorName,
                                html: text
                            }).appendTo('#tdddlselectTrainer select'); //appends to select if parent td has id is tdddlselectTrainer
                        }
                    }
                }
            }


        });
    });
}

//Query and get the list of Operators to populate in the dropdown list.
function PopulateOperatorListDropDown() {
    var d = $.Deferred();
    //Get the sharepoint context based on the SiteUrl
    var clientContext = new SP.ClientContext(siteUrl);

    //Find the list to fetch the operators based on the GUID
    var oList = clientContext.get_web()
        .get_lists()
        .getById(operatorsListID);

    //Create a CAML Query
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View><Query> <Where> <Neq><FieldRef Name="Status"></FieldRef><Value Type="Choice">Inactive</Value></Neq> </Where> <OrderBy> <FieldRef Name=\'Shift\' Ascending=\'True\' /></OrderBy></Query></View>'
    );

    //Fetch the operator information using the CAML Query.
    operatorInfo = oList.getItems(camlQuery);
    clientContext.load(operatorInfo);

    //Make the asychronous call.

    //Make the asychronous call.
    var o = { d: d, operatorInfo: operatorInfo };
    clientContext.executeQueryAsync(Function.createDelegate(o, OnOperatorListInfoQuerySucceeded), Function.createDelegate(o, OnOperatorListOperatorInfoQueryFailed));

    return d.promise();

    //Query Succeeded.
    function OnOperatorListInfoQuerySucceeded() {
        var listItemEnumerator = this.operatorInfo.getEnumerator();
        var totalOperatorCount = this.operatorInfo.get_count();
        var availableOperators = [];
        var ShiftArray = [];
        if (totalOperatorCount == 0) {
            alert('Could not fetch operator info');
        }
        else {
            console.log('Entered TotalOperatorcount > 0')
            while (listItemEnumerator.moveNext()) {
                var oListItem = listItemEnumerator.get_current();

                //Fetch the operator title.
                var operatorName = oListItem.get_item('System_x0020_Defined_x0020_Opera').get_lookupValue();
                var Shift = oListItem.get_item('Shift');

                //Check if the operator is already in the array and avoid if ture.
                if (jQuery.inArray(operatorName, availableOperators) == -1) {
                    availableOperators.push([operatorName, Shift]);
                }
            }

            d.resolve(availableOperators);
        }

    }
    //Query Failed.
    function OnOperatorListOperatorInfoQueryFailed() {
        console.log('Request failed in PopulateOperatorList ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}

//Query and get the list of Trainers to populate in the dropdown list.
function GetTrainerList() {
    var d = $.Deferred();
    //Get the sharepoint context based on the SiteUrl
    var clientContext = new SP.ClientContext(siteUrl);
    //Find the list to fetch the operators based on the GUID
    var oList = clientContext.get_web()
        .get_lists()
        .getById(MSWPOAccessManagementList);
    //Create a CAML Query
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View><Query><Where><Eq><FieldRef Name=\'Title\' \/> <Value Type=\'Text\'>Trainer<\/Value><\/Eq><\/Where><\/Query></View>');

    //Fetch the operator information using the CAML Query.
    trainerInfo = oList.getItems(camlQuery);
    clientContext.load(trainerInfo);

    //Make the asychronous call.
    var o = { d: d, trainerInfo: trainerInfo };
    clientContext.executeQueryAsync(Function.createDelegate(o, OnAccessMangementListQuerySucceeded), Function.createDelegate(o, OnAccessMangementListQueryFailed));

    return d.promise();
    //Query Succeeded.
    function OnAccessMangementListQuerySucceeded() {
        var listItemEnumerator = this.trainerInfo.getEnumerator();
        var totalTrainerCount = this.trainerInfo.get_count();
        var availableOperators = [];
        var ShiftArray = [];
        if (totalTrainerCount == 0) {
            alert('Could not fetch operator info');
        }
        else {
            console.log('Entered totalTrainerCount > 0');
            var membersArray = [];
            while (listItemEnumerator.moveNext()) {
                var oListItem = listItemEnumerator.get_current();
                //Fetch Trainer List
                var members = oListItem.get_item('Group_x0020_Members');//.get_lookupValue();
                if (!!members) {
                    console.log(members);
                    if (members.length > 0) {
                        for (var i = 0; i < members.length; i++) {
                            var operatorName = members[i].get_lookupValue();
                            membersArray.push(operatorName);
                        }
                    }
                }
            }
            d.resolve(membersArray);
        }
    }
    //Query Failed.
    function OnAccessMangementListQueryFailed() {
        console.log('Request failed in GetTrainerList ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}









