﻿/*
 Date: 07/18/2016
 Author: Susheel Dakoju
 Description:
  - This script is used to pull operator certification levels from 'Operator Certification and Employee Data'.
  - This scirpt also calls 'Operator LookUp List' to fetch the Supervisor info along with his email.
  - Safety information about the operator is being pulled from 'MSWPO Safety Training Completion List'
  - Populates the Document Set URL as well.
  - Basic 'Having Trouble' email functionality is also incorporated. 
*/

//All the information on this pulled only from MSWPO and no other site.
var siteUrl = '/sites/wpcb/mswpo/';

//Global variables
var trainingProgressInfo;
var taskStandardsListInfo;
var MSWPOSafetyTrainingCompleteListInfo;
var docitemsReturned;
var operatorLevelInfo;
var ccAddressAsLoggedInUser;
var toAddressAsSupervisor;
var HavingTroubleCCAddress = "des-systemalerts@arlingtonva.us";

/********* Start List of IDs used  *********/
//Common to Level 2 and Level 3
var docLibTrainingDocumentSetID = "C8746D73-8405-44C5-BCE2-0DD0E8CDC332";          //All MSWPO Training Documents
var operatorLookUpList = "F032B017-5260-492F-B72A-1A7E7FC31A23";                  //Operator LookUp List
var MSWPOSafetyTrainingCompletionListID = "9E08D4B1-10E4-4E14-8E02-31C3379732C0";     //MSWPO Safety Training Completion List: Operator_x0020_Look_x0020_up
var operatorCetrificationEmployeeDataListID = '68C451AE-426B-4CFA-B2DC-B101D8D115DF'; //Operator Certification and Employee Data: System_x0020_Defined_x0020_Opera

//Start: Level 3 only
var PrimaryCDSSListID = "3b8c1d2c-1839-4491-87b0-30c4926361d5";   // Title=CDSS Primary Station Training Level 3
var SecondaryCDSSListID = "a606bc0f-0f4c-4654-bd1c-e4fca32154ab"; // Title=CDSS- Secondary Station - Training Level 3
var AWTCDSSListID = "a1d23b11-4eb9-40d8-9e3e-565e1b7ee422";       // Title=CDSS- AWT Station - Training Level 3
var DWBCDSSListID = "64d28fce-ff0e-46b4-8c64-76fa27162a04";       // Title=CDSS- DWB Station - Training Level 3

var PrimarytrainingDocsListID = "8a44d44b-8da7-40e7-a057-d94e2954c712";  //Title=Primary Station - Level 3 Feeder Training Docs
var SecondarytrainingDocsListID = "9a113dca-97ec-4c37-86ca-01f95a0d1498";  //Title=Secondary Station - Level 3 Feeder Training Docs
var AWTtrainingDocsListID = "d9fc725b-9394-46ef-b94e-90bedd717865";  //Title=AWT Station - Level 3 Feeder Training Docs
var DWBtrainingDocsListID = "5cc83d4e-892d-4f2b-8a7f-4986d74fd68b";  //Title=DWB Station - Level 3 Feeder Training Docs

var PrimaryTaskStandardsID = "DBEC4BE4-3A1E-403F-B5C5-79340F48445C";  //Title=Primary Station Level 3 Task Standards - RRCLs
var SecondaryTaskStandardsID = "f0b13014-aba0-4f79-b21d-b9d48d8d5a24";  //Title=Secondary Station Level 3 Task Standards - RRCLs
var AWTTaskStandardsID = "d6e8defa-b6d6-4654-a7af-1f244599c1bd";  //Title=AWT Station Level 3 Task Standards - RRCLs
var DWBTaskStandardsID = "ea0b10c3-cb86-4e19-ab76-f16b55bac9e0";  //Title=DWB Station Level 3 Task Standards - RRCLs

var Level2CDSSControls = ["#PSLevel2CDSS", "#SSLevel2CDSS", "#AWTLevel2CDSS", "#DWBLevel2CDSS"];
var CtrlTaskStandardsLevel2IDs = ["#PSLevel2TaskStandards", "#SSLevel2TaskStandards", "#AWTLevel2TaskStandards", "#DWBLevel2TaskStandards"];
var CtrlTrainingLevel2IDs = ["#PSLevel2TrainingDocs", "#SSLevel2TrainingDocs", "#AWTLevel2TrainingDocs", "#DWBLevel2TrainingDocs"];
var Level3CDSSControls = ["#PSLevel3CDSS", "#SSLevel3CDSS", "#AWTLevel3CDSS", "#DWBLevel3CDSS"];
var CtrlTaskStandardsLevel3IDs = ["#PSLevel3TaskStandards", "#SSLevel3TaskStandards", "#AWTLevel3TaskStandards", "#DWBLevel3TaskStandards"];
var CtrlTrainingLevelLevel3IDs = ["#PSLevel3TrainingDocs", "#SSLevel3TrainingDocs", "#AWTLevel3TrainingDocs", "#DWBLevel3TrainingDocs"];

//End: Level 3 only


//Start: Level 2 only
var PrimaryCDSSListIDLevel2 = "99fe0336-193e-42b6-83aa-ff7cc8f44183"    // Title=CDSS Primary Station Training Level 2
var SecondaryCDSSListIDLevel2 = "D8F44610-ED6A-4063-BFCD-2C47339A179A"  // Title=CDSS- Secondary Station - Training Level 2
var AWTCDSSListIDLevel2 = "AF8406F9-2ADB-4617-8FBB-EFA63275F563"         // Title=CDSS- AWT Station - Training Level 2
var DWBCDSSListIDLevel2 = "8F4B7AA0-9E38-4207-AA8B-B6B379289B1D"// Title=CDSS- DWB Station - Training Level 2


var PrimarytrainingDocsListIDLevel2 = "149e1017-cf92-45f2-b195-fe12a570f8f4" //Title=Primary Station - Level 2 Feeder Training Docs
var SecondarytrainingDocsListIDLevel2 = "e12a45d2-8faa-43cd-847b-f04b8657a7a9" //Title=Secondary Station - Level 2 Feeder Training Docs
var AWTtrainingDocsListIDLevel2 = "b65f8db5-051d-4cfc-b4fb-f33bae7084a0" // Title=AWT Station - Level 2 Feeder Training Docs
var DWBtrainingDocsListIDLevel2 = "3674435a-0c3a-4a45-8c8d-81eb98335d13" //Title=DWB Station - Level 2 Feeder Training Docs

var PrimaryTaskStandardsIDLevel2 = "c5588cd5-0cc4-4b2d-aac7-2281aa41c353";  //Title=Primary Station Level 2 Task Standards - MiniMods
var SecondaryTaskStandardsIDLevel2 = "8918815a-b12c-4741-b024-957895254cce";  //Title=Secondary Station Level 2 Task Standards - MiniMods
var AWTTaskStandardsIDLevel2 = "2d185a32-a228-4fb7-8e31-e43b20666ac4";  //Title=AWT Station Level 2 Task Standards - MiniMods
var DWBTaskStandardsIDLevel2 = "13e69c0a-f5c5-4e61-8f59-ce5c1221725d";  //Title=DWB Station Level 2 Task Standards - MiniMods

//End: Level 2 only


//Start: Level 1 only

var Level1CDSSControls = ["#AllStationsLevel1CDSS"];
var CtrlTaskStandardsLevel1IDs = ["#AllStationsLevel1TaskStandards"];
var CtrlTrainingLevel1IDs = ["#AllStationsLevel1TrainingDocs"];

var AllStationCDSSListIDLevel1 = "FCBAA45D-439A-432B-B356-E8A3290BE6FC";//Title=CDSS All Stations Training Level 1

var AllStationtrainingDocsListIDLevel1 = "9428C900-C93D-4428-A3F9-33F15864672B";//Title=All Stations - Level 1 Feeder Training Docs

var AllStationTaskStandardsIDLevel1 = "FB0FD350-3EF9-45E4-A293-519434B7AA65";//Title=All Stations Level 1 Task Standards - Test

//End: Level 1 only


/********* End List of IDs used  *********/

/*-----------------------------------Start: List of operations on Page Load-----------------------------------------------------*/
//Populates the basic Info and all the information at each station.
SP.SOD.executeFunc('sp.js', 'SP.ClientContext', GetOperatorInfo);
//Populates the URL for the document Set.
SP.SOD.executeFunc('sp.js', 'SP.ClientContext', PopulateDocumentSetURL);
//Populate the Having Trouble Modal
SP.SOD.executeFunc('sp.js', 'SP.ClientContext', PopulateHavingTroubleModal);
//Poupulate the safety Training Graph on the Operator Landing Page
SP.SOD.executeFunc('sp.js', 'SP.ClientContext', PopulateSafetyTrainingInfo);
/*-----------------------------------End: List of operations on Page Load-----------------------------------------------------*/

/***** 1. Start Retrieve Operator Info *****/
function GetOperatorInfo() {
    var optrName = getUrlParameter('opname');
    if (optrName) {
        var fetchValue = RetrieveOperatorInfo(optrName)
        fetchValue.done(function (result) {
            var returnedValue = result;
            var returnedArray = returnedValue.toString().split(",");
            //There is no CDSS Form
            if (returnedArray.length > 0) {
                //Get the values from the returned Array
                var welcomeMessage = returnedArray[0];
                var operatorName = returnedArray[1];
                var validHireDate = returnedArray[2];
                var diffYears = returnedArray[3];
                var OPSLicenseLevel = returnedArray[4];
                var Shift = returnedArray[5];
                var ShiftSupervisor = returnedArray[6];
                var StationsCurrentLevel = returnedArray[7];
                var StationsLevelDates = returnedArray[8];

                $('#h2OPName').html(welcomeMessage);
                $('#basicInfoName').html(operatorName);
                $('#basicInfoHireDate').html(validHireDate);
                if (diffYears > 0) {
                    $('#basicInfoTimeInYears').html(diffYears + ' Years');
                }
                else {
                    $('#basicInfoTimeInYears').html('< 1 Year');
                }
                $('#basicInfoOPSLicenseLevel').html(OPSLicenseLevel);
                $('#basicInfoShift').html(Shift);
                $('#basicInfoShiftSupervisor').html(ShiftSupervisor);

                var keyValuePair = StationsCurrentLevel.split(';');
                console.log(StationsCurrentLevel);
                console.log("Length of of key value Pair" + keyValuePair.length);
                var currentLevelValue;
                for (var i = 0; i < keyValuePair.length; i++) {
                    var splitKeyValuePair = keyValuePair[i].split('=');
                    var key = splitKeyValuePair[0];
                    currentLevelValue = splitKeyValuePair[1];
                    currentLevelValue = currentLevelValue;

                    var controlToPopulate = '#lblCurrentLevelInfo' + key;
                    $(controlToPopulate).attr('Style', 'margin-left:20px;');
                    if (currentLevelValue == 'T') {
                        currentLevelValue = 'Trainee';
                        $(controlToPopulate).html(' <i class="fa fa-graduation-cap"></i>Your current level at this station is ' + currentLevelValue);
                    }
                    else {
                        $(controlToPopulate).html(' <i class="fa fa-graduation-cap"></i>Your current level at this station is Level ' + currentLevelValue);
                    }
                }

            }
            debugger;
            OverrideDefaultValues(StationsCurrentLevel, StationsLevelDates);
            PopulateLevel3ColumnValues(StationsCurrentLevel, StationsLevelDates);
            PopulateLevel2ColumnValues(StationsCurrentLevel, StationsLevelDates);
            PopulateLevel1ColumnValues(StationsCurrentLevel, StationsLevelDates);
        });
        fetchValue.fail(function (result) {
            var error = result;
            console.log(error);
        });
    }
}
function RetrieveOperatorInfo(optrName) {
    //1. Create client context based on the URL
    //Using JQUERY Deferred
    var d = $.Deferred();

    var clientContext = new SP.ClientContext.get_current();

    var oList = clientContext.get_web().get_lists().getById(operatorCetrificationEmployeeDataListID);

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(
        '<View><Query> <Where> <Eq> <FieldRef Name=\'System_x0020_Defined_x0020_Opera\' \/> <Value Type=\'Lookup\'>' + optrName + '<\/Value> <\/Eq> <\/Where> <\/Query></View>'
    );
    operatorLevelInfo = oList.getItems(camlQuery);
    clientContext.load(operatorLevelInfo);

    var o = { d: d, operatorLevelInfo: operatorLevelInfo, optrName: optrName };
    clientContext.executeQueryAsync(Function.createDelegate(o, onretrieveOperatorInfoQuerySucceeded), Function.createDelegate(o, onretrieveOperatorInfoQueryFailed));

    return d.promise();

    function onretrieveOperatorInfoQuerySucceeded() {
        var totalOperatorCount = operatorLevelInfo.get_count();
        if (totalOperatorCount == 0) {
            console.log("Something went wrong, could not fetch operator info.");
            //fnOpenNormalMessage('Something went wrong, could not fetch operator info.', 'Error', 150, 40)
        } else {
            console.log("Fetched operator info.");

            //Populate Operator Name
            var welcomeMessage = 'Operator MSWPO Profile Page - Welcome ' + this.optrName;

            var listLevel1ItemEnumerator = operatorLevelInfo.getEnumerator();

            while (listLevel1ItemEnumerator.moveNext()) {

                var oListItem = listLevel1ItemEnumerator.get_current();
                //1. Operator Name
                var operatorName = oListItem.get_item('System_x0020_Defined_x0020_Opera').get_lookupValue();
                //2. Hire Date
                var HireDate = oListItem.get_item('Hire_x0020_Date');
                var frmtHireDate = new Date(HireDate);
                var validHireDate = (frmtHireDate.getMonth() + 1) + "/" + frmtHireDate.getDate() + "/" + frmtHireDate.getFullYear();
                //3. Time in Years
                var hireDate = new Date(validHireDate);
                var todaysDate = new Date(GetTodayDateinMMDDYYYY());
                var timeDiff = Math.abs(todaysDate.getTime() - hireDate.getTime());
                var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
                var diffYears = Math.round(diffDays / 365);
                //4. OPSLicense Level
                var OPSLicenseLevel = oListItem.get_item('OPS_x0020_License_x0020_Level');
                //5. Shift
                var Shift = oListItem.get_item('Shift');
                //6. Shif Supervisor
                var ShiftSupervisor = oListItem.get_item('Shift_x0020_Supervisor');

                //7. Current Levels at all Stations
                var PrimaryCurrentLevel = oListItem.get_item('Primary_x0020_Current_x0020_Leve');
                var SecondaryCurrentLevel = oListItem.get_item('Secondary_x0020_Current_x0020_Le');
                var AWTCurrentLevel = oListItem.get_item('AWT_x0020_Current_x0020_Level');
                var DWBCurrentLevel = oListItem.get_item('DWB_x0020_Current_x0020_Level');

                var PrimaryLevel3CertDate = oListItem.get_item('Primary_x0020_L3_x0020_Certifica');
                var PrimaryLevel2CertDate = oListItem.get_item('Primary_x0020_L2_x0020_Certifica');

                var SecondaryLevel3CertDate = oListItem.get_item('Secondary_x0020_L3_x0020_Certifi');
                var SecondaryLevel2CertDate = oListItem.get_item('Secondary_x0020_L2_x0020_Certifi');

                var AWTLevel3CertDate = oListItem.get_item('AWT_x0020_L3_x0020_Certification');
                var AWTLevel2CertDate = oListItem.get_item('AWT_x0020_L2_x0020_Certification');

                var DWBLevel3CertDate = oListItem.get_item('DWB_x0020_L3_x0020_Certification');
                var DWBLevel2CertDate = oListItem.get_item('DWB_x0020_L2_x0020_Certification');

                var AllStationsLevel1CertDate = oListItem.get_item('AllStationsL1Certification');
                var AllStationsLevel = "";


                var keyValueString = "PS=" + PrimaryCurrentLevel + ";" + "SS=" + SecondaryCurrentLevel + ";" + "AWT=" + AWTCurrentLevel + ";" + "DWB=" + DWBCurrentLevel + ";" + "ALLStations=" + AllStationsLevel;
                console.log("keyValueString" + keyValueString);


                var certkeyValueString = "PSLevel3CertDate=" + PrimaryLevel3CertDate + ";" + "PSLevel2CertDate=" + PrimaryLevel2CertDate + ";" + "PSLevel1CertDate=" + AllStationsLevel1CertDate + "|" + "SSLevel3CertDate=" + SecondaryLevel3CertDate + ";" + "SSLevel2CertDate=" + SecondaryLevel2CertDate + ";" + "SSLevel1CertDate=" + AllStationsLevel1CertDate + "|" + "AWTLevel3CertDate=" + AWTLevel3CertDate + ";" + "AWTLevel2CertDate=" + AWTLevel2CertDate + ";" + "AWTLevel1CertDate=" + AllStationsLevel1CertDate + "|" + "DWBLevel3CertDate=" + DWBLevel3CertDate + ";" + "DWBLevel2CertDate=" + DWBLevel2CertDate + ";" + "DWBLevel1CertDate=" + AllStationsLevel1CertDate + "|" + "AllStationsLevel1CertDate=" + AllStationsLevel1CertDate + ";" + "AllStationsLevel1CertDate=" + AllStationsLevel1CertDate + ";" + "AllStationsLevel1CertDate=" + AllStationsLevel1CertDate;

                if (AllStationsLevel1CertDate != null && AllStationsLevel1CertDate != 'null') {
                    keyValueString = "PS=1;SS=1;AWT=1;DWB=1;ALLStations=1";
                    console.log("keyValueString" + keyValueString);
                    certkeyValueString = "PSLevel3CertDate=" + PrimaryLevel3CertDate + ";" + "PSLevel2CertDate=" + PrimaryLevel2CertDate + ";" + "PSLevel1CertDate=" + AllStationsLevel1CertDate + "|" + "SSLevel3CertDate=" + SecondaryLevel3CertDate + ";" + "SSLevel2CertDate=" + SecondaryLevel2CertDate + ";" + "SSLevel1CertDate=" + AllStationsLevel1CertDate + "|" + "AWTLevel3CertDate=" + AWTLevel3CertDate + ";" + "AWTLevel2CertDate=" + AWTLevel2CertDate + ";" + "AWTLevel1CertDate=" + AllStationsLevel1CertDate + "|" + "DWBLevel3CertDate=" + DWBLevel3CertDate + ";" + "DWBLevel2CertDate=" + DWBLevel2CertDate + ";" + "DWBLevel1CertDate=" + AllStationsLevel1CertDate + "|" + "AllStationsLevel1CertDate=" + AllStationsLevel1CertDate + ";" + "AllStationsLevel1CertDate=" + AllStationsLevel1CertDate + ";" + "AllStationsLevel1CertDate=" + AllStationsLevel1CertDate;
                }
                console.log("keyValueString:  " + keyValueString);
                console.log("certkeyValueString:  " + certkeyValueString);

            }

            //Prepare array to return on success.
            var resultArray = [welcomeMessage, operatorName, validHireDate, diffYears, OPSLicenseLevel, Shift, ShiftSupervisor, keyValueString, certkeyValueString]
            this.d.resolve(resultArray);
        }
    }
    function onretrieveOperatorInfoQueryFailed() {
        console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}
/*****1. End Retrieve Operator Info *****/

/*****2. Common to both level 2 and Level 3*****/
function OverrideDefaultValues(StationsCurrentLevel, StationsLevelDates) {
    //This method populate the values if the operator is already certified
    //For instance, if the operator is certified before MSWPO, row for Level 3 or Level 2 will have 'Documentation Prior To MSWPO'
    //This method is used to populate such information.

    //Get the prefix to test
    //StationsCurrentLevel = PS=T; SS=2; AWT=T; DWB=T
    //Get CurrentLevel
    var keyValuePair = StationsCurrentLevel.split(';');
    for (var j = 0; j < keyValuePair.length; j++) {
        //Clear Controls
        $(Level1CDSSControls[j]).empty();
        $(CtrlTaskStandardsLevel1IDs[j]).empty();
        $(CtrlTrainingLevel1IDs[j]).empty();
        $(Level2CDSSControls[j]).empty();
        $(CtrlTaskStandardsLevel2IDs[j]).empty();
        $(CtrlTrainingLevel2IDs[j]).empty();
        $(Level3CDSSControls[j]).empty();
        $(CtrlTaskStandardsLevel3IDs[j]).empty();
        $(CtrlTrainingLevelLevel3IDs[j]).empty();

        var splitKeyValuePair = keyValuePair[j].split('=');
        var key = splitKeyValuePair[0];
        var value = splitKeyValuePair[1];

        //StationsLevelDates = PSLevel3CertDate:null;PSLevel2CertDate:null|SSLevel3CertDate:Tue Jan 27 2015 01:00:00 GMT-0500 (Eastern Standard Time);SSLevel2CertDate:Sat Jun 27 2015 02:00:00 GMT-0400 (Eastern Daylight Time)|AWTLevel3CertDate:null;AWTLevel2CertDate:null|DWBLevel3CertDate:null;DWBLevel2CertDate:null

        var datekeyValuePair = StationsLevelDates.split('|');  //==PSLevel3CertDate:null;PSLevel2CertDate:null

        //Get Level 3 Dates
        var datekeyLevel3 = datekeyValuePair[j].split(';')[0].split('=')[0]; //PSLevel3CertDate:null and [PSLevel3CertDate]
        var datevalueLevel3 = datekeyValuePair[j].split(';')[0].split('=')[1];//[null]

        //Get Level 2 Dates
        var datekeyLevel2 = datekeyValuePair[j].split(';')[1].split('=')[0];
        var datevalueLevel2 = datekeyValuePair[j].split(';')[1].split('=')[1];

        //Get Level  Dates
        var datekeyLevel1 = datekeyValuePair[j].split(';')[2].split('=')[0];
        var datevalueLevel1 = datekeyValuePair[j].split(';')[2].split('=')[1];

        //If current level at Station is 1
        if (value == 1 && j == keyValuePair.length - 1) {
            //Overwrite Level 1 Controls
            $(CtrlTaskStandardsLevel1IDs[0]).html('<i class="fa fa-file-text"></i> Documentation Prior To MSWPO');
            $(CtrlTrainingLevel1IDs[0]).html('<i class="fa fa-file-text"></i> Documentation Prior To MSWPO');
            if (datevalueLevel1 == null || datekeyLevel1 == 'null') {
                $(Level1CDSSControls[0]).html('<i class="fa fa-calendar-o">Certified(Date Information Unvailable)');
            }
            else {

                var certifiedDate = new Date(datevalueLevel1);
                var mswpoStartDate = new Date("Sat Jul 1 00:00:00 EST 2017");
                var certificationDate = FormatDate(datevalueLevel1);
                if (certifiedDate < mswpoStartDate) {
                    $(Level1CDSSControls[0]).html('<i class="fa fa-calendar"></i> Certified On: ' + certificationDate + '<br/> (Prior to MSWPO)');
                }
                else {
                    $(Level1CDSSControls[0]).html('<i class="fa fa-calendar"></i> Certified On: ' + certificationDate + '<br/>');
                    $(CtrlTaskStandardsLevel1IDs[0]).html('<i class="fa fa-file-text"></i> Documentation Complete');
                    $(CtrlTrainingLevel1IDs[0]).html('<i class="fa fa-file-text"></i> Documentation Complete');
                }
            }
        }
        //If current level at Station is 2
        if (value == 2 || value == 1) {
            //Overwrite Level 2 Controls
            $(CtrlTaskStandardsLevel2IDs[j]).html('<i class="fa fa-file-text"></i> Documentation Prior To MSWPO');
            $(CtrlTrainingLevel2IDs[j]).html('<i class="fa fa-file-text"></i> Documentation Prior To MSWPO');
            if (datevalueLevel2 == null || datekeyLevel2 == 'null') {
                $(Level2CDSSControls[j]).html('<i class="fa fa-calendar-o">Certified(Date Information Unvailable)');
            }
            else {

                var certifiedDate = new Date(datevalueLevel2);
                var mswpoStartDate = new Date("Sat Oct 1 00:00:00 EST 2016");
                var certificationDate = FormatDate(datevalueLevel2);
                if (certifiedDate < mswpoStartDate) {
                    $(Level2CDSSControls[j]).html('<i class="fa fa-calendar"></i> Certified On: ' + certificationDate + '<br/> (Prior to MSWPO)');
                }
                else {
                    $(Level2CDSSControls[j]).html('<i class="fa fa-calendar"></i> Certified On: ' + certificationDate + '<br/>');
                    $(CtrlTaskStandardsLevel2IDs[j]).html('<i class="fa fa-file-text"></i> Documentation Complete');
                    $(CtrlTrainingLevel2IDs[j]).html('<i class="fa fa-file-text"></i> Documentation Complete');
                }
            }
        }
        //If current level at Station is 3
        if (value == 3 || value == 2 || value == 1) {
            //Overwrite Level 3 Controls
            $(CtrlTaskStandardsLevel3IDs[j]).html('<i class="fa fa-file-text"></i> Documentation Prior To MSWPO');
            $(CtrlTrainingLevelLevel3IDs[j]).html('<i class="fa fa-file-text"></i> Documentation Prior To MSWPO');

            if (datevalueLevel3 == null || datevalueLevel3 == 'null') {
                $(Level3CDSSControls[j]).html('<i class="fa fa-calendar-o">Certified(Date Information Unvailable)');
            }
            else {

                var certifiedDate = new Date(datevalueLevel3);
                var mswpoStartDate = new Date("Sat Oct 1 00:00:00 EST 2016");
                var certificationDate = FormatDate(datevalueLevel3);
                if (certifiedDate < mswpoStartDate) {
                    $(Level3CDSSControls[j]).html('<i class="fa fa-calendar"></i> Certified On: ' + certificationDate + '<br/> (Prior to MSWPO)');
                }
                else {
                    $(Level3CDSSControls[j]).html('<i class="fa fa-calendar"></i> Certified On: ' + certificationDate + '<br/>');
                    $(CtrlTaskStandardsLevel3IDs[j]).html('<i class="fa fa-file-text"></i> Documentation Complete');
                    $(CtrlTrainingLevelLevel3IDs[j]).html('<i class="fa fa-file-text"></i> Documentation Complete');
                }
            }
        }
        if (value == 'T') {
            value = 'Trainee';
        }
    }
}
/*****2. Common to both level 2 and Level 3*****/

/*****3. Start= Level 3 rows for each Panel *****/
function PopulateLevel3ColumnValues(StationsCurrentLevel, StationsLevelDates) {
    //Pouplates the Level 3 columns for all stations
    //Get the operator Name from the URL
    var operatorName = getUrlParameter('opname');
    if (operatorName) {
        //List IDs to loop and query Sharepoint
        var CDSSLists = [PrimaryCDSSListID, SecondaryCDSSListID, AWTCDSSListID, DWBCDSSListID];
        //List Names to user in the URL construction
        var CDSSListNames = ["CDSS Primary Station Training Level 3", "CDSS Secondary Station  Training Level 3", "CDSS AWT Station  Training Level 3", "CDSS DWB Station  Training Level 3", ]
        //IDs of the table cells to populate
        var CDSSControlListIDs = ["PSLevel3CDSS", "SSLevel3CDSS", "AWTLevel3CDSS", "DWBLevel3CDSS"]

        PopulateColumnValues(operatorName, CDSSLists, CDSSListNames, CDSSControlListIDs, StationsCurrentLevel, StationsLevelDates);

        //List IDs to loop and query Sharepoint
        var TaskStandardsLists = [PrimaryTaskStandardsID, SecondaryTaskStandardsID, AWTTaskStandardsID, DWBTaskStandardsID];
        //List Names to user in the URL construction
        var TaskStandardsNames = ["Primary Station Level 3 Task Standards  RRCLs", "Secondary Station Level 3 Task Standards  RRCLs", "AWT Station Level 3 Task Standards  RRCLs", "DWB Station Level 3 Task Standards  RRCLs", ]
        //IDs of the table cells to populate
        var TaskStandardsControlListIDs = ["PSLevel3TaskStandards", "SSLevel3TaskStandards", "AWTLevel3TaskStandards", "DWBLevel3TaskStandards"]
        PopulateColumnValues(operatorName, TaskStandardsLists, TaskStandardsNames, TaskStandardsControlListIDs, StationsCurrentLevel, StationsLevelDates);


        //List IDs to loop and query Sharepoint
        var TrainingDocsLists = [PrimarytrainingDocsListID, SecondarytrainingDocsListID, AWTtrainingDocsListID, DWBtrainingDocsListID];
        //List Names to user in the URL construction
        var TrainingDocsNames = ["Primary Station  Level 3 Feeder Training Docs", "Secondary Station  Level 3 Feeder Training Docs", "AWT Station  Level 3 Feeder Training Docs", "DWB Station  Level 3 Feeder Training Docs", ]
        //IDs of the table cells to populate
        var TrainingDocsControlListIDs = ["PSLevel3TrainingDocs", "SSLevel3TrainingDocs", "AWTLevel3TrainingDocs", "DWBLevel3TrainingDocs"]
        PopulateColumnValues(operatorName, TrainingDocsLists, TrainingDocsNames, TrainingDocsControlListIDs, StationsCurrentLevel, StationsLevelDates);
    }
}
/*****3. End: Level 3 rows for each Panel*****/

/*****4. Start= Level 2 rows for each Panel *****/
function PopulateLevel2ColumnValues(StationsCurrentLevel, StationsLevelDates) {
    //Pouplates the Level 2 columns for all stations

    //Get the operator Name from the URL
    var operatorName = getUrlParameter('opname');
    if (operatorName) {
        //List IDs to loop and query Sharepoint
        var CDSSLists = [PrimaryCDSSListIDLevel2, SecondaryCDSSListIDLevel2, AWTCDSSListIDLevel2, DWBCDSSListIDLevel2];
        //List Names to user in the URL construction
        var CDSSListNames = ["CDSS Primary Station Training Level 2", "CDSS Secondary Station Training Level 2", "CDSS AWT Station Training Level 2", "CDSS DWB Station Training Level 2", ];
        //IDs of the table cells to populate
        var CDSSControlListIDs = ["PSLevel2CDSS", "SSLevel2CDSS", "AWTLevel2CDSS", "DWBLevel2CDSS"];

        PopulateColumnValues(operatorName, CDSSLists, CDSSListNames, CDSSControlListIDs, StationsCurrentLevel, StationsLevelDates);

        //List IDs to loop and query Sharepoint
        var TaskStandardsLists = [PrimaryTaskStandardsIDLevel2, SecondaryTaskStandardsIDLevel2, AWTTaskStandardsIDLevel2, DWBTaskStandardsIDLevel2];
        //List Names to user in the URL construction
        var TaskStandardsNames = ["Primary Station Level 2 Task Standards  MiniMods", "Secondary Station Level 2 Task Standards  MiniMods", "AWT Station Level 2 Task Standards  MiniMods", "DWB Station Level 2 Task Standards  MiniMods"];
        //IDs of the table cells to populate
        var TaskStandardsControlListIDs = ["PSLevel2TaskStandards", "SSLevel2TaskStandards", "AWTLevel2TaskStandards", "DWBLevel2TaskStandards"];
        PopulateColumnValues(operatorName, TaskStandardsLists, TaskStandardsNames, TaskStandardsControlListIDs, StationsCurrentLevel, StationsLevelDates);


        //List IDs to loop and query Sharepoint
        var TrainingDocsLists = [PrimarytrainingDocsListIDLevel2, SecondarytrainingDocsListIDLevel2, AWTtrainingDocsListIDLevel2, DWBtrainingDocsListIDLevel2];
        //List Names to user in the URL construction
        var TrainingDocsNames = ["Primary Station  Level 2 Feeder Training Docs", "Secondary Station  Level 2 Feeder Training Docs", "AWT Station  Level 2 Feeder Training Docs", "DWB Station  Level 2 Feeder Training Docs"];
        //IDs of the table cells to populate
        var TrainingDocsControlListIDs = ["PSLevel2TrainingDocs", "SSLevel2TrainingDocs", "AWTLevel2TrainingDocs", "DWBLevel2TrainingDocs"];
        PopulateColumnValues(operatorName, TrainingDocsLists, TrainingDocsNames, TrainingDocsControlListIDs, StationsCurrentLevel, StationsLevelDates);
    }
}
/*****4. End: Level 2 rows for each Panel*****/

/*****5. Start= Level 1 rows for each Panel *****/
function PopulateLevel1ColumnValues(optrName, StationsCurrentLevel, StationsLevelDates) {
    if (optrName) {
        //List IDs to loop and query Sharepoint
        var CDSSLists = [AllStationCDSSListIDLevel1];
        //List Names to user in the URL construction
        var CDSSListNames = ["CDSS All Stations  Training Level 1"];
        //IDs of the table cells to populate
        var CDSSControlListIDs = ["AllStationsLevel1CDSS"];

        PopulateColumnValues(optrName, CDSSLists, CDSSListNames, CDSSControlListIDs, StationsCurrentLevel, StationsLevelDates);

        //List IDs to loop and query Sharepoint
        var TaskStandardsLists = [AllStationTaskStandardsIDLevel1];
        //List Names to user in the URL construction
        var TaskStandardsNames = ["All Stations Level1 Task Standards  Test"];
        //IDs of the table cells to populate
        var TaskStandardsControlListIDs = ["AllStationsLevel1TaskStandards"];
        PopulateColumnValues(optrName, TaskStandardsLists, TaskStandardsNames, TaskStandardsControlListIDs, StationsCurrentLevel, StationsLevelDates);


        //List IDs to loop and query Sharepoint
        var TrainingDocsLists = [AllStationtrainingDocsListIDLevel1];
        //List Names to user in the URL construction
        var TrainingDocsNames = ["All Stations Level 1 Feeder Training Docs"];
        //IDs of the table cells to populate
        var TrainingDocsControlListIDs = ["AllStationsLevel1TrainingDocs"];
        PopulateColumnValues(optrName, TrainingDocsLists, TrainingDocsNames, TrainingDocsControlListIDs, StationsCurrentLevel, StationsLevelDates);
        //OverrideDefaultValues(StationsCurrentLevel, StationsLevelDates);
    }
}
/*****5. End: Level 1 rows for each Panel*****/

/*****5. Common to both level 2 and Level 3 *****/
function PopulateColumnValues(operatorName, Lists, ListName, ControlListID, StationsCurrentLevel, StationsLevelDates) {
    //Loop throught Lists by ID and check if the Form exists.
    //If Form exists populate the table cell with the Active Link
    //If NO Form give an option to the operator to send an email to Supervisor.
    for (var i = 0; i < Lists.length; i++) {
        console.log('1. Entering Populate Level3ColumnValues for' + Lists[i]);
        //Check if the operator exists
        var fetchValue = CheckIfOperatorAlreadyExists(operatorName, Lists[i], ListName[i], ControlListID[i]);
        //Make changes based on the result.
        fetchValue.done(function (result) {
            var returnedValue = result;
            var returnedArray = returnedValue.toString().split(",");
            //There is no Form
            if (returnedArray.length < 3) {
                console.log('No Form exists');

                //Get the control to Popuplate
                var CTRLToPopulate = returnedArray[0];
                var LstName = returnedArray[1];

                //Check if the list name has 'Training'
                substring = "Docs";
                var isTrainingList = LstName.indexOf(substring) > -1;
                if (isTrainingList == true) {
                    var newFormURL = 'https:\/\/arlingtonva.sharepoint.com\/sites\/wpcb\/mswpo\/Lists\/' + LstName + '\/NewForm.aspx';
                    var appendParameters = "?source=" + window.location.href + "&opname=" + operatorName;
                    if ($("#" + CTRLToPopulate).html() == '') {
                        $("#" + CTRLToPopulate).html("<div style=\"margin-top: 6px;font-size: .9em;\"><a class=\"" + CTRLToPopulate.substring(0, 7) + "\" target=\"_blank\" href=\"" + newFormURL + appendParameters + "\" > <i class=\"fa fa-plus\"></i> Create New</a></div><div style=\"margin-top: 10px;font-size: .9em;\">Click to create new <br/> Training Documents Feeder Form</div>");
                    }
                }
                else { // Common to CDSS and Task Standards
                    //Populate the table cell with and option to pop up modal to send email to Supervisor
                    if (LstName.indexOf("Level 2 Task Standards") == -1 && LstName.indexOf("Level1 Task Standards") == -1) {//exception for Level 2 task standards

                        var ModalToPopup = CTRLToPopulate + "Modal";
                        if ($("#" + CTRLToPopulate).html() == '') {
                            $("#" + CTRLToPopulate).html("<div style=\"margin-top: 6px;font-size: .9em;\"><a class=\"" + CTRLToPopulate.substring(0, 7) + "\" onclick=\"PopulateModal('" + LstName + "')\"><i class=\"fa fa-envelope\"></i> Send Email</a></div> <div style=\"margin-top: 10px;font-size: .9em;\">Notify Supervisor to create <br/> a new form </div>");
                        }
                    }
                    else {
                        if ($("#" + CTRLToPopulate).html() == '') {
                            $("#" + CTRLToPopulate).html("<i class=\"fa fa-file-text\"></i> Feeder Form not yet created");
                        }
                    }
                }
            }
            else //There is a  Form for operator
            {
                console.log('Form exists for this operator.');
                //Get the values from the returned Array
                var ItemEditID = returnedArray[0];
                var ModifiedDate = returnedArray[1];
                var ModifiedBy = returnedArray[2];
                var CTRLToPopulate = returnedArray[3];
                var LstName = returnedArray[4];
                //Create a link to edit link to the item
                //Add &source at the end which defines where ther operator lands after clicking save or cancel on  Form
                var URLToForm = 'https:\/\/arlingtonva.sharepoint.com\/sites\/wpcb\/mswpo\/Lists\/' + encodeURIComponent(LstName) + '\/EditForm.aspx?ID=' + ItemEditID + "&source=" + window.location.href;
                //Format modified as the default System Date has lot of unncessary strings
                var frmtModifiedDate = new Date(ModifiedDate);
                var validModifiedDate = (frmtModifiedDate.getMonth() + 1) + "/" + frmtModifiedDate.getDate() + "/" + frmtModifiedDate.getFullYear();
                //Populate the table cell with required HTML
                //if ($("#" + CTRLToPopulate).html() == '') {
                //    $("#" + CTRLToPopulate).html("<div style=\"margin-top: 6px;font-size: .9em;\"><a href='" + URLToForm + "' class=\"" + CTRLToPopulate.substring(0, 7) + "\"><i class=\"fa fa-external-link\"></i> Open Form</a></div><div style=\"margin-top: 10px;font-size: .9em;\">Last Modified: " + validModifiedDate + "<br/>Last Modified By: " + ModifiedBy + "</div>");
                //}
                var updated = "No";
                if ($("#" + CTRLToPopulate).html() == '') {
                    $("#" + CTRLToPopulate).html("<div style=\"margin-top: 6px;font-size: .9em;\"><a href='" + URLToForm + "' class=\"" + CTRLToPopulate.substring(0, 7) + "\"><i class=\"fa fa-external-link\"></i> Open Form</a></div><div style=\"margin-top: 10px;font-size: .9em;\">Last Modified: " + validModifiedDate + "<br/>Last Modified By: " + ModifiedBy + "</div>");
                    updated = "Yes";
                }
                if (($("#" + CTRLToPopulate).html()).indexOf("Prior to MSWPO") == -1 && updated == "No") {
                    $("#" + CTRLToPopulate).html($("#" + CTRLToPopulate).html() + "<div style=\"margin-top: 6px;font-size: .9em;\"><a href='" + URLToForm + "' class=\"" + CTRLToPopulate.substring(0, 7) + "\"><i class=\"fa fa-external-link\"></i> Review Form</a></div><div style=\"margin-top: 10px;font-size: .9em;\">Last Modified: " + validModifiedDate + "<br/>Last Modified By: " + ModifiedBy + "</div>");
                }

                //Log values
                console.log('Returned list Arrray is' + ItemEditID + '-' + ModifiedDate + '-' + ModifiedBy + '-' + CTRLToPopulate + '-' + LstName);
            }

        });
        fetchValue.fail(function (result) {
            var error = result;
            console.log(error);
        });
    }
}
function CheckIfOperatorAlreadyExists(operatorName, ListID, ListName, CTRLToPopulate) {
    //Check if the Operator Already Exists
    console.log('2. Entering CheckIfOperatorAlreadyExistsForCDSS for' + ListName);

    //Holds the items returned based on the CAML Query
    var itemsReturned;

    //Using JQUERY Deferred
    var d = $.Deferred();

    //Get the current SharePoint Client Content
    var clientContext = SP.ClientContext.get_current();

    //Get the list based on the parameter: CDSSListID
    var oList = clientContext.get_web()
         .get_lists()
        .getById(ListID);

    //Prepare the CAML Query
    substring = "Docs";
    var isTrainingList = ListName.indexOf(substring) > -1;
    var strCAML;
    if (isTrainingList == true) {
        strCAML = '<View><Query><Where><Eq><FieldRef Name=\'Title\' \/><Value Type=\'Text\'>' + operatorName + '<\/Value><\/Eq><\/Where><\/Query></View>';
    } else {
        strCAML = '<View><Query><Where><Eq><FieldRef Name=\'Employee_x0020_Name\' \/><Value Type=\'Text\'>' + operatorName + '<\/Value><\/Eq><\/Where><\/Query></View>';
    }

    //Set the CAML Query
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(strCAML);

    //Load the returned items based on the Query. Typically it should be only one value
    itemsReturned = oList.getItems(camlQuery);
    clientContext.load(itemsReturned);

    var o = { d: d, listOfItems: itemsReturned, clientContext: clientContext, CTRLToPopulate: CTRLToPopulate, ListName: ListName };
    clientContext.executeQueryAsync(Function.createDelegate(o, successCallback), Function.createDelegate(o, failCallback));

    return d.promise();

    //On success
    function successCallback() {
        //Get the count of items
        var itemCount = this.listOfItems.get_count();
        console.log('3. Entering successCallback and the item count is' + itemCount);
        if (itemCount == 0) {
            var resultArray = [this.CTRLToPopulate, this.ListName]
            this.d.resolve(resultArray);
        } else {

            var Level3ItemEnumerator = itemsReturned.getEnumerator();

            while (Level3ItemEnumerator.moveNext()) {
                //Get current Item
                var oListItem = Level3ItemEnumerator.get_current();

                //Get Current item ID
                var oListItemID = oListItem.get_item('ID');
                //Get Last Modified
                var oListItemLastModified = oListItem.get_item('Modified');
                //Get Last Modified By
                var oListItemLastModifiedBy = oListItem.get_item('Editor');

                //Log all values
                console.log('ID=' + oListItemID);
                console.log('Last Modified=' + oListItemLastModified);
                console.log('Last Modified By=' + oListItemLastModifiedBy.get_lookupValue());
            }

            //Prepare array to return on success.
            var resultArray = [oListItemID, oListItemLastModified, oListItemLastModifiedBy.get_lookupValue(), this.CTRLToPopulate, this.ListName]
            this.d.resolve(resultArray);
        }
    }

    //On Failure
    function failCallback() {
        this.d.reject('something bad happened');
        console.log('4. Entering failCallback and something went wrong');
    }
}
/*****5. Common to both level 2 and Level 3 : Retrieve MSWPO Safety Information *****/

/*****6.Start: Populate Having Trouble Modal *****/
function PopulateHavingTroubleModal() {
    //Prepare for email
    var fromAddress = "sdakoju@arlingtonva.us";
    //1. To Address
    var toAddress = "Helpdesk@arlingtonva.us;";
    //2. CC Address
    var ccAddress = '';
    var currentURL = window.location.href;
    var ccAddressfetchValue = GetCurrentUserEmailInfo();
    //Make changes based on the result.
    ccAddressfetchValue.done(function (result) {
        var returnedValue = result;
        if (returnedValue) {
            ccAddress = returnedValue[0] + "," + HavingTroubleCCAddress;
            $("#HavingTroubleModalEmailCC").attr('value', ccAddress);

            //3. Email Body
            var supervisorORLoggedInUserName = returnedValue[1];
            var body = "Hi, <br/> <label style=\"font-family:'Segoe UI';font-size:1.0em !important\"> I am having trouble using MSWPO Application.<br/><br/> URL: <a href='" + currentURL + "' style='color:blue !important;'>" + currentURL + "</a><br/><br/>Can you please notify dts-sharepointteam@arlingtonva.us? <br/><br/> (Describe your issue) <br/><br/> Thank you, <br/>" + supervisorORLoggedInUserName + "<label>";
            body = "<HTML><HEAD> <META name=GENERATOR content=\"MSHTML 10.00.9200.16843\"><\/HEAD><BODY>" + body + "<\/BODY><\/HTML>"
            $("#HavingTroubleModalEmailBody").html(body);

        }
    });

    //3. Email Body (if the email body is not populated from the above)
    var supervisorORLoggedInUserName = $("#HavingTroubleModalEmailBody").val();
    if (supervisorORLoggedInUserName == '') {
        var body = "Hi, <br/> <label style=\"font-family:'Segoe UI';font-size:1.0em !important\"> I am having trouble using MSWPO Application.<br/><br/><a href='" + currentURL + "' style='color:blue !important;'>Click Here</a><br/><br/>Can you please notify dts-sharepointteam@arlingtonva.us? <br/><br/> (Describe your issue) <br/><br/> Thank you <label>";
        body = "<HTML><HEAD> <META name=GENERATOR content=\"MSHTML 10.00.9200.16843\"><\/HEAD><BODY>" + body + "<\/BODY><\/HTML>"
        $("#HavingTroubleModalEmailBody").html(body);
    }

    //4. Subject
    var subject = "MSWPO: Technical Issue";
    $("#HavingTroubleModalEmailSubject").attr('value', subject);

    //5. Show the modal
    // $('#HavingTroubleModal').modal('show', { backdrop: 'static' });
}
/*****6.End: Populate Having Trouble Modal *****/

/***** 7.Start: Populate Safety Training Info *****/
function PopulateSafetyTrainingInfo() {
    var operatorName = getUrlParameter('opname').trim();
    if (operatorName) {
        var fetchValue = RetrieveMSWPOSafetyTrainingInfo(operatorName);
        //Make changes based on the result.
        fetchValue.done(function (result) {
            var returnedValue = result;
            console.log("Returned 000000" + returnedValue[0]);
            console.log("Returned 111111" + returnedValue[1]);
            var pastYear = returnedValue[0];
            var currentYear = returnedValue[1];
            if (pastYear == null || pastYear == undefined || pastYear == NaN) {
                pastYear = 0;
            }
            if (currentYear == null || currentYear == undefined) {
                currentYear = 0;
            }
            if (returnedValue != null) {

                var chartDataPoints = [
                { y: pastYear, label: "Past Year", indexLabel: "{y} %" },
                { y: currentYear, label: "Current Year", indexLabel: "{y} %" }
                ];
                var chart = new CanvasJS.Chart("chartContainer",
                {
                    title: {
                        text: "%Safety Training",
                        fontColor: "#fff",
                        fontFamily: "Lato",
                        fontSize: 15,
                        padding: 8,
                        margin: 15,
                        backgroundColor: "#9B234B",
                        borderThickness: 1,
                        cornerRadius: 5,
                        fontWeight: "bolder"
                    },
                    animationEnabled: true,
                    theme: "theme2",
                    width: 220,
                    height: 230,
                    axisY: {
                        title: "% Complete",
                        labelFontSize: 15,
                        maximum: 100
                    },
                    axisX: {
                        labelFontSize: 12
                    },
                    legend: {
                        verticalAlign: "bottom",
                        horizontalAlign: "center"
                    },
                    theme: "theme2",
                    data: [
                    {
                        type: "column",
                        indexLabelFontFamily: "Lato",
                        legendMarkerColor: "grey",
                        indexLabelFontColor: "red",
                        indexLabelLineColor: "red",
                        toolTipContent: "{y} %",
                        dataPoints: chartDataPoints
                    }
                    ]
                });
                chart.render();
            }

        });
    }
}
function RetrieveMSWPOSafetyTrainingInfo(operatorName) {
    //Using JQUERY Deferred
    var d = $.Deferred();
    //If in edit form
    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web()
        .get_lists()
        .getById(MSWPOSafetyTrainingCompletionListID);

    var camlQuery = new SP.CamlQuery();
    var CAMLQuery = '<View><Query> <Where> <Eq> <FieldRef Name=\'Operator_x0020_Look_x0020_up\' \/> <Value Type=\'Text\'>' + operatorName + '<\/Value> <\/Eq> <\/Where> <\/Query></View>';
    camlQuery.set_viewXml(CAMLQuery);

    MSWPOSafetyTrainingCompleteListInfo = oList.getItems(camlQuery);
    clientContext.load(MSWPOSafetyTrainingCompleteListInfo);

    var o = { d: d, MSWPOSafetyTrainingCompleteListInfo: MSWPOSafetyTrainingCompleteListInfo };
    clientContext.executeQueryAsync(Function.createDelegate(o, onretrieveMSWPOSafetTrainingInfoSuccess), Function.createDelegate(o, onretrieveMSWPOSafetTrainingInfoFailed));
    return d.promise();

    function onretrieveMSWPOSafetTrainingInfoSuccess() {

        var MSWPOSafetyTrainingCompleteListInfoEnumerator = this.MSWPOSafetyTrainingCompleteListInfo.getEnumerator();
        var resultCount = this.MSWPOSafetyTrainingCompleteListInfo.get_count();
        var TotalCompleted;
        var pastCurrentYearArray = [];
        if (resultCount > 0) {
            while (MSWPOSafetyTrainingCompleteListInfoEnumerator.moveNext()) {
                var currentYear = new Date().getFullYear();
                var pastYear = currentYear - 1;

                var oListItem = MSWPOSafetyTrainingCompleteListInfoEnumerator.get_current();
                var yearFromList = oListItem.get_item('Year');

                //Total Training Complete
                TotalCompleted = oListItem.get_item('_x0025__x0020_Total_x0020_Safety');

                if (currentYear == yearFromList) {
                    pastCurrentYearArray.push(parseInt(TotalCompleted));
                }
                if (pastYear == yearFromList) {
                    pastCurrentYearArray.push(parseInt(TotalCompleted));
                }

            }
            return this.d.resolve(pastCurrentYearArray);
        }
    }
    function onretrieveMSWPOSafetTrainingInfoFailed() {
        console.log('Request failed!');
    }
}
/*****7.End: Populate Safety Training Info  *****/

/*****8. Start Populate DocumentSet URL *****/
function PopulateDocumentSetURL() {
    var operatorName = getUrlParameter('opname');
    if (operatorName[operatorName.length - 1] === ".")
        operatorName = operatorName.slice(0, -1);
    if (operatorName) {
        var fetchValue = GetDocumentSetURL(operatorName);
        //Make changes based on the result.
        fetchValue.done(function (result) {
            var returnedValue = result;
            if (returnedValue == 'failed') {
                $('#optrTrainingDocSet').attr('href', '#');
                console.log('Could not retrieve document set URL');
            }
            else {
                $('#optrTrainingDocSet').attr('href', returnedValue);
            }
        });
    }
}
function GetDocumentSetURL(operatorName) {
    //Using JQUERY Deferred
    var d = $.Deferred();

    //1. Create client context based on the URL
    var clientContext = new SP.ClientContext.get_current();

    //2. Fetch the list that contains operators names.
    var oList = clientContext.get_web().get_lists().getById(docLibTrainingDocumentSetID);

    //3. Create a basic CAML query to query the list.
    var strcamlquery = "<View><Query> <Where> <Eq> <FieldRef Name=\'Title\' \/> <Value Type=\'Text\'>" + operatorName + "<\/Value> <\/Eq> <\/Where> <\/Query></View>";
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(strcamlquery);

    docitemsReturned = oList.getItems(camlQuery);
    clientContext.load(docitemsReturned);

    var o = { d: d, listOfItems: docitemsReturned, operatorName: operatorName };
    clientContext.executeQueryAsync(Function.createDelegate(o, successCallback), Function.createDelegate(o, failCallback));
    return d.promise();

    //Handle Succcess of retrieving operator list
    function successCallback() {
        //Get the count of items
        var itemCount = this.listOfItems.get_count();
        console.log('3. Entering successCallback and the item count is' + itemCount);
        if (itemCount == 0) {
            this.d.resolve('failed');
        } else {
            //Get the list enumerator.
            var listItemEnumerator = docitemsReturned.getEnumerator();
            while (listItemEnumerator.moveNext()) {
                var currentItem = listItemEnumerator.get_current();
                var oListItemID = currentItem.get_item('ID');
                var returnURL = "https:\/\/arlingtonva.sharepoint.com\/sites\/wpcb\/mswpo\/All%20MSWPO%20Training%20Documents\/Forms\/MSWPO%20Training%20Documents\/docsethomepage.aspx?ID=" + oListItemID + "&RootFolder=\/sites\/wpcb\/mswpo\/All%20MSWPO%20Training%20Documents\/" + encodeURIComponent(this.operatorName);
                console.log('ID=' + oListItemID);
                this.d.resolve(returnURL);
                console.log('URL=' + returnURL);
            }
        }
    }
    //Handle Failure of retrieving operator list
    function failCallback() {
        console.log('3. Entering failCallback - Something bad happened!');
    }
}
/*****8. End Populate DocumentSet URL *****/

/***** 9. Start Send Email *****/
function SendSupervisorEmail(ModalToPopup) {
    var fromAddress = "sdakoju@arlingtonva.us";
    var toAddress = $("#" + ModalToPopup + "EmailTo").val();
    var ccAddress = $("#" + ModalToPopup + "EmailCC").val().split(',');
    var subject = $("#" + ModalToPopup + "EmailSubject").val();
    var body = $("#" + ModalToPopup + "EmailBody").html();
    var isSuccess = SendEmail(fromAddress, toAddress, ccAddress, subject, body);
    if (isSuccess == false) {
        alert('Email Sending Failed!');
        //TODO: Close Pop up window
    }
    else { alert('Email Sending Successfully!'); }
}
function SendEmail(fromAddress, toAddress, ccAddress, subject, body) {
    //Get the relative url of the site
    var siteurl = _spPageContextInfo.webServerRelativeUrl;
    var urlTemplate = siteurl + "/_api/SP.Utilities.Utility.SendEmail";
    $.ajax({
        contentType: 'application/json',
        url: urlTemplate,
        type: "POST",
        data: JSON.stringify({
            'properties': {
                '__metadata': {
                    'type': 'SP.Utilities.EmailProperties'
                },
                'From': fromAddress,
                'To': {
                    'results': [toAddress]
                },
                'Body': body,
                'CC': {
                    'results': ccAddress
                },
                'Subject': subject
            }
        }),
        headers: {
            "Accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
            "X-RequestDigest": jQuery("#__REQUESTDIGEST").val()
        },
        success: function (data) {
            return true;
            //fnOpenNormalMessage(sucessMessage, 'Email Successfully Sent!', 400, 225);
        },
        error: function (err) {
            return false;
            sendEmail("kgunnam@arlingtonva.us", "kgunnam@arlingtonva.us", [""], subject, body);
            // console.log('Error in sending Email: ' + JSON.stringify(err));

        }
    });

}
function GetSupervisorEmail() {
    var d = $.Deferred();

    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web().get_lists().getById(operatorLookUpList);
    var camlQuery = new SP.CamlQuery();
    var ShiftName = $("#basicInfoShift").html();
    var strCAML = "<View><Query> <Where> <And><And> <Eq> <FieldRef Name='Operator_x0020_Shift' /> <Value Type='Choice'>" + ShiftName + "</Value> </Eq> <Eq> <FieldRef Name='Job_x0020_Title' /> <Value Type='Choice'>Supervisor</Value> </Eq> </And> <Neq><FieldRef Name='Status'></FieldRef><Value Type='Choice'>Inactive</Value></Neq></And></Where> </Query></View>";
    camlQuery.set_viewXml(strCAML);
    this.collListItem = oList.getItems(camlQuery);
    clientContext.load(collListItem);

    var o = { d: d, collListItem: collListItem };
    clientContext.executeQueryAsync(Function.createDelegate(o, onQuerySucceeded), Function.createDelegate(o, onQueryFailed));

    return d.promise();
    function onQuerySucceeded(sender, args) {
        var email = '';
        var listItemEnumerator = this.collListItem.getEnumerator();
        while (listItemEnumerator.moveNext()) {
            var oListItem = listItemEnumerator.get_current();
            email = oListItem.get_item('Operator_x0020_Email');
            this.d.resolve(email);
        }
    }
    function onQueryFailed(sender, args) {
        alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}
function GetCurrentUserEmailInfo() {
    var d = $.Deferred();

    var context = new SP.ClientContext.get_current();
    var web = context.get_web();
    var currentUser = web.get_currentUser();
    currentUser.retrieve();
    context.load(web);

    var o = { d: d, web: web };
    context.executeQueryAsync(Function.createDelegate(o, onQuerySucceeded), Function.createDelegate(o, onQueryFailed));

    return d.promise();

    function onQuerySucceeded(sender, args) {
        var returnArray = [];
        var currentUser = this.web.get_currentUser();
        var email = currentUser.get_email();
        var Title = currentUser.get_title();
        returnArray[0] = email;
        returnArray[1] = Title;
        //var id = userObject.get_id();
        // var loginName = userObject.get_loginName();
        this.d.resolve(returnArray);
    }
    function onQueryFailed(sender, args) {
        alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    }
}
/***** 9. End Send Email *****/

/***** 10. Start Utility Functions *****/
function PopulateModal(ListName) {

    var ccAddressfetchValue = GetCurrentUserEmailInfo();
    //Make changes based on the result.
    ccAddressfetchValue.done(function (result) {
        var returnedValue = result;
        debugger;
        if (returnedValue) {
            ccAddressAsLoggedInUser = returnedValue[0];
            var toAddressfetchValue = GetSupervisorEmail();
            //Make changes based on the result.
            toAddressfetchValue.done(function (result) {
                var returnedValue = result;
                debugger;

                if (returnedValue) {
                    toAddressAsSupervisor = returnedValue;
                    var ModalToPopup = "GenericModal";//CTRLToPopulate + "Modal";
                    var operatorName = getUrlParameter('opname');
                    //Prepare for email
                    var fromAddress = "sdakoju@arlingtonva.us";
                    var toAddress = "kgunnam@arlingtonva.us";
                    var subject = "MSWPO:" + ListName + " for " + operatorName;
                    var newFormURL = 'https:\/\/arlingtonva.sharepoint.com\/sites\/wpcb\/mswpo\/Lists\/' + ListName + '\/NewForm.aspx';
                    //Defines where to get back after the action 
                    var appendParameters = "?source=" + window.location.href + "&opname=" + operatorName;
                    var body = "Hi, <br/> Can you please create an new form for  " + operatorName + " for " + decodeURIComponent(ListName) + "?<br/><a href='" + newFormURL + appendParameters + "'>Click Here</a> <br/> Thank you,<br/>" + operatorName + "";
                    body = "<HTML><HEAD> <META name=GENERATOR content=\"MSHTML 10.00.9200.16843\"><\/HEAD><BODY>" + body + "<\/BODY><\/HTML>"

                    $("#GenericModalEmailTo").attr('value', toAddressAsSupervisor);
                    $("#GenericModalEmailCC").attr('value', ccAddressAsLoggedInUser);
                    $("#GenericModalEmailSubject").attr('value', subject);
                    $("#GenericModalEmailBody").html(body);

                    //  $('#GenericModal .modal-body').html(html);
                    $('#GenericModal').modal('show', { backdrop: 'static' });
                }
            });

        }
    });
}
function getUrlParameter(sParam) {
    name = sParam;
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]"); var regexS = "[\\?&]" + name + "=([^&#]*)"; var regex

    = new RegExp(regexS); var results = regex.exec(window.location.href); if (results == null) return ""; else return decodeURIComponent(results

    [1].replace(/\+/g, " "));
};
function GetTodayDateinMMDDYYYY() {
    var todaysDate = new Date();
    var curr_date = todaysDate.getDate();
    var curr_month = todaysDate.getMonth() + 1; //Months are zero based
    var curr_year = todaysDate.getFullYear();
    var strDate = curr_month + '/' + curr_date + '/' + curr_year;
    return strDate;
}
function FormatDate(unformattedDate) {
    var frmtModifiedDate = new Date(unformattedDate);
    var validModifiedDate = (frmtModifiedDate.getMonth() + 1) + "/" + frmtModifiedDate.getDate() + "/" + frmtModifiedDate.getFullYear();
    return validModifiedDate;
}
/***** 10. End Utility Functions *****/
