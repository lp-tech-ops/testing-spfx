# Shared helpers: runtime state, logging, reports, CSOM execution, resume state.

$script:Mig = @{}

function Initialize-MigrationRuntime {
    param([hashtable]$Config, [string]$RunLabel)

    $work = $Config.WorkFolder
    $dirs = @($work, (Join-Path $work 'state'), (Join-Path $work 'logs'), (Join-Path $work 'reports'))
    foreach ($d in $dirs) {
        if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
    }
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $script:Mig.Config     = $Config
    $script:Mig.StateDir   = Join-Path $work 'state'
    $script:Mig.ReportDir  = Join-Path $work 'reports'
    $script:Mig.LogFile    = Join-Path (Join-Path $work 'logs') "$RunLabel-$stamp.log"
    $script:Mig.ReportFile = Join-Path $script:Mig.ReportDir "$RunLabel-$stamp-report.csv"
    $script:Mig.ErrorFile  = Join-Path $script:Mig.ReportDir "$RunLabel-$stamp-errors.csv"
    $script:Mig.ItemMaps   = @{}
    $script:Mig.WarnedOnce = @{}
    $script:Mig.Stats      = @{ Created = 0; Updated = 0; Skipped = 0; Errors = 0; Warnings = 0 }
}

function Write-MigLog {
    param(
        [string]$Message,
        [ValidateSet('INFO', 'WARN', 'ERROR', 'DEBUG', 'OK')][string]$Level = 'INFO'
    )
    $line = '{0} [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    if ($Level -eq 'WARN') { $script:Mig.Stats.Warnings++ }
    if ($Level -eq 'ERROR') { $script:Mig.Stats.Errors++ }
    if ($Level -ne 'DEBUG' -or $script:Mig.Config.VerboseLogging) {
        $color = switch ($Level) { 'WARN' { 'Yellow' } 'ERROR' { 'Red' } 'OK' { 'Green' } 'DEBUG' { 'DarkGray' } default { 'Gray' } }
        Write-Host $line -ForegroundColor $color
    }
    Add-Content -Path $script:Mig.LogFile -Value $line -Encoding utf8
}

# Logs a warning only the first time a given key is seen (avoids flooding the log per item).
function Write-MigWarnOnce {
    param([string]$Key, [string]$Message)
    if ($script:Mig.WarnedOnce.ContainsKey($Key)) { return }
    $script:Mig.WarnedOnce[$Key] = $true
    Write-MigLog $Message WARN
}

function Add-MigReport {
    param(
        [string]$List, [string]$Object, [string]$SourceId, [string]$TargetId,
        [string]$Action, [ValidateSet('OK', 'Warning', 'Error', 'Skipped')][string]$Status, [string]$Message
    )
    $row = [pscustomobject]@{
        Time = (Get-Date -Format 's'); List = $List; Object = $Object; SourceId = $SourceId
        TargetId = $TargetId; Action = $Action; Status = $Status; Message = $Message
    }
    $row | Export-Csv -Path $script:Mig.ReportFile -Append -NoTypeInformation -Encoding utf8
    if ($Status -eq 'Error') { $row | Export-Csv -Path $script:Mig.ErrorFile -Append -NoTypeInformation -Encoding utf8 }
}

# Executes the pending CSOM batch. Uses PnP.Framework's ExecuteQueryRetry when available,
# which honours Retry-After on 429/503 and safely re-sends the same request.
function Invoke-MigQuery {
    param([Parameter(Mandatory)]$Context)
    if (-not $script:Mig.ContainsKey('RetryMethod')) {
        # Resolved by reflection because the optional parameters differ between PnP.Framework versions.
        $t = 'Microsoft.SharePoint.Client.ClientContextExtensions' -as [type]
        $script:Mig.RetryMethod = if ($t) {
            $t.GetMethods() |
                Where-Object { $_.Name -eq 'ExecuteQueryRetry' -and $_.GetParameters()[0].ParameterType.Name -eq 'ClientRuntimeContext' } |
                Sort-Object { $_.GetParameters().Count } | Select-Object -First 1
        }
        if (-not $script:Mig.RetryMethod) { Write-MigLog 'ExecuteQueryRetry not found; using plain ExecuteQuery (no throttling back-off)' WARN }
    }
    $m = $script:Mig.RetryMethod
    if (-not $m) { $Context.ExecuteQuery(); return }

    $callArgs = foreach ($p in $m.GetParameters()) {
        if ($p.Position -eq 0) { $Context }
        elseif ($p.Name -eq 'retryCount') { [int]$script:Mig.Config.MaxRetries }
        elseif ($p.HasDefaultValue) { $p.DefaultValue }
        else { [Type]::Missing }
    }
    try { [void]$m.Invoke($null, [object[]]@($callArgs)) }
    catch {
        # Unwrap reflection/PowerShell wrappers so callers see the real SharePoint error.
        $e = $_.Exception
        while (($e -is [System.Management.Automation.MethodInvocationException] -or
                $e -is [System.Reflection.TargetInvocationException]) -and $e.InnerException) { $e = $e.InnerException }
        throw $e
    }
}

function Connect-MigrationSites {
    $c = $script:Mig.Config
    $common = @{ ClientId = $c.ClientId; Interactive = $true; ReturnConnection = $true }
    if ($c.Tenant) { $common.Tenant = $c.Tenant }

    Write-MigLog "Connecting to source $($c.SourceUrl)"
    $script:Mig.Src = Connect-PnPOnline -Url $c.SourceUrl @common
    Write-MigLog "Connecting to target $($c.TargetUrl)"
    $script:Mig.Tgt = Connect-PnPOnline -Url $c.TargetUrl @common

    $script:Mig.SrcCtx = $script:Mig.Src.Context
    $script:Mig.TgtCtx = $script:Mig.Tgt.Context
    $script:Mig.SrcWeb = $script:Mig.SrcCtx.Web
    $script:Mig.TgtWeb = $script:Mig.TgtCtx.Web
    $script:Mig.SrcCtx.Load($script:Mig.SrcWeb)
    $script:Mig.TgtCtx.Load($script:Mig.TgtWeb)
    Invoke-MigQuery $script:Mig.SrcCtx
    Invoke-MigQuery $script:Mig.TgtCtx
    Write-MigLog "Source web '$($script:Mig.SrcWeb.Title)' -> target web '$($script:Mig.TgtWeb.Title)'" OK
}

# Applies properties one at a time so a single rejected value does not block the rest.
function Set-ClientObjectProperties {
    param($Object, [System.Collections.IDictionary]$Values, [string]$Label)
    foreach ($k in $Values.Keys) {
        try {
            $Object.$k = $Values[$k]
            $Object.Update()
            Invoke-MigQuery $Object.Context
        }
        catch {
            Write-MigLog "[$Label] could not set $k = '$($Values[$k])': $($_.Exception.Message)" WARN
        }
    }
}

# ---------------------------------------------------------------------------
# URL helpers
# ---------------------------------------------------------------------------
function Get-WebRelativeUrl {
    param([string]$ServerRelativeUrl, [string]$WebServerRelativeUrl)
    $web = $WebServerRelativeUrl.TrimEnd('/')
    if ($web -and $ServerRelativeUrl.StartsWith("$web/", [StringComparison]::OrdinalIgnoreCase)) {
        return $ServerRelativeUrl.Substring($web.Length + 1)
    }
    $ServerRelativeUrl.TrimStart('/')
}

# Maps a server-relative URL inside a source list to the matching URL in the target list.
function Convert-ToTargetUrl {
    param($Pair, [string]$SourceServerRelativeUrl)
    $sRoot = $Pair.SourceRootUrl.TrimEnd('/')
    $tRoot = $Pair.TargetRootUrl.TrimEnd('/')
    if ($SourceServerRelativeUrl.Equals($sRoot, [StringComparison]::OrdinalIgnoreCase)) { return $tRoot }
    $tRoot + $SourceServerRelativeUrl.Substring($sRoot.Length)
}

function New-ResourcePath {
    param([string]$DecodedUrl)
    [Microsoft.SharePoint.Client.ResourcePath]::FromDecodedUrl($DecodedUrl)
}

# ---------------------------------------------------------------------------
# Resume state: one CSV per source list with SourceId -> TargetId and the last
# migrated source Modified/version, so re-runs skip unchanged items and only
# replay newer versions of changed ones.
# ---------------------------------------------------------------------------
function Get-StatePath {
    param([string]$Name)
    Join-Path $script:Mig.StateDir "$Name.csv"
}

function Get-ItemMap {
    param([Guid]$SourceListId)
    $key = $SourceListId.ToString()
    if (-not $script:Mig.ItemMaps.ContainsKey($key)) {
        $map = @{}
        $path = Get-StatePath "items-$key"
        if (Test-Path $path) {
            foreach ($r in Import-Csv $path) { $map[[int]$r.SourceId] = $r }   # later rows win
        }
        $script:Mig.ItemMaps[$key] = $map
    }
    $script:Mig.ItemMaps[$key]
}

function Set-ItemMapEntry {
    param([Guid]$SourceListId, [int]$SourceId, [int]$TargetId, [datetime]$SourceModified, [string]$SourceVersion)
    $row = [pscustomobject]@{
        SourceId = $SourceId; TargetId = $TargetId
        SourceModified = $SourceModified.ToUniversalTime().ToString('o'); SourceVersion = $SourceVersion
    }
    (Get-ItemMap $SourceListId)[$SourceId] = $row
    $row | Export-Csv -Path (Get-StatePath "items-$SourceListId") -Append -NoTypeInformation -Encoding utf8
}

function ConvertFrom-StateDate {
    param([string]$Value)
    [datetime]::Parse($Value, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::RoundtripKind).ToUniversalTime()
}

function ConvertTo-VersionNumber {
    param([string]$Label)
    $v = $null
    if ([version]::TryParse($Label, [ref]$v)) { return $v }
    [version]'0.0'
}

# Reads a CSOM stream result fully into a seekable MemoryStream.
function Read-ClientStream {
    param($ClientResult)
    $ms = [System.IO.MemoryStream]::new()
    $ClientResult.Value.CopyTo($ms)
    $ms.Position = 0
    $ms
}
