# Site columns and list columns: recreated with the same ID, internal name and display name.

$script:SkipFieldNames = @('TaxCatchAll', 'TaxCatchAllLabel')
$script:SkipFieldTypes = @('WorkflowStatus', 'Computed', 'Counter', 'File', 'ModStat', 'Attachments', 'ContentTypeId', 'Guid')

# Creation order matters: lookups need their target lists, dependent lookups need the
# primary lookup, calculated columns need the columns their formula references.
function Get-FieldCreationRank {
    param($Info)
    if ($Info.Type -eq 'Calculated') { return 4 }
    if ($Info.Type -like 'Lookup*' -and $Info.PrimaryRef) { return 3 }
    if ($Info.Type -like 'Lookup*') { return 2 }
    if (Test-IsTaxonomyType $Info.Type) { return 1 }
    0
}

# Returns the target list id (with braces) for a lookup's List attribute, or $null.
function Resolve-TargetLookupListId {
    param([string]$ListAttr, [string]$OwnSourceListId)
    $pair = $null
    if ($ListAttr -eq 'Self' -and $OwnSourceListId) { $pair = $script:Mig.Pairs[$OwnSourceListId] }
    else {
        $g = [guid]::Empty
        if ([guid]::TryParse($ListAttr, [ref]$g)) { $pair = $script:Mig.Pairs[$g.ToString()] }
        else { $pair = $script:Mig.Pairs.Values | Where-Object { $_.WebRelUrl -eq $ListAttr.Trim('/') } | Select-Object -First 1 }
    }
    if ($pair -and $pair.Target) { return '{' + $pair.Target.Id.ToString() + '}' }
    $null
}

# Strips instance-specific attributes and sets DisplayName to the decoded internal name
# so SharePoint derives exactly the original internal name. The real title is set after.
function Get-CleanFieldXml {
    param([string]$SchemaXml, [hashtable]$Overrides = @{})
    $doc = [xml]$SchemaXml
    $f = $doc.DocumentElement
    foreach ($a in 'SourceID', 'Version', 'ColName', 'RowOrdinal', 'ColName2', 'RowOrdinal2', 'WebId') {
        $f.RemoveAttribute($a)
    }
    $f.SetAttribute('DisplayName', [System.Xml.XmlConvert]::DecodeName($f.GetAttribute('Name')))
    foreach ($k in $Overrides.Keys) { $f.SetAttribute($k, $Overrides[$k]) }
    $f.OuterXml
}

# Creates one field in the target web ($TargetList = $null) or list. Returns the new field or $null.
function New-TargetField {
    param($SourceField, $TargetList, [string]$OwnSourceListId)
    $info = Get-FieldXmlInfo $SourceField.SchemaXml
    $ctx = $script:Mig.TgtCtx
    $scope = if ($TargetList) { "list '$($TargetList.Title)'" } else { 'site columns' }

    if (Test-IsTaxonomyType $info.Type) {
        $anchor = $info.Props['AnchorId']
        $itemId = if ($anchor -and [guid]$anchor -ne [guid]::Empty) { $anchor } else { $info.Props['TermSetId'] }
        if (-not $itemId -or [guid]$itemId -eq [guid]::Empty) {
            Write-MigLog "[$scope] managed metadata column '$($info.Name)' has no term set; skipped" WARN
            return $null
        }
        $p = @{
            DisplayName = $SourceField.Title; InternalName = $info.Name; TaxonomyItemId = [guid]$itemId
            Id = [guid]$info.Id; MultiValue = $info.Mult; Required = $SourceField.Required; Connection = $script:Mig.Tgt
        }
        if ($TargetList) { $p.List = $TargetList.Id } else { $p.Group = $SourceField.Group }
        Add-PnPTaxonomyField @p | Out-Null
    }
    else {
        $over = @{}
        if ($info.Type -like 'Lookup*') {
            $listId = Resolve-TargetLookupListId $info.List $OwnSourceListId
            if (-not $listId) {
                Write-MigLog "[$scope] lookup '$($info.Name)' points to a list that is not migrated ($($info.List)); skipped" WARN
                return $null
            }
            $over.List = $listId
            $over.WebId = $script:Mig.TgtWeb.Id.ToString()
        }
        $xml = Get-CleanFieldXml $SourceField.SchemaXml $over
        $coll = if ($TargetList) { $TargetList.Fields } else { $ctx.Web.Fields }
        $null = $coll.AddFieldAsXml($xml, $false, [Microsoft.SharePoint.Client.AddFieldOptions]::AddFieldInternalNameHint)
        Invoke-MigQuery $ctx
    }

    $coll = if ($TargetList) { $TargetList.Fields } else { $ctx.Web.Fields }
    $new = $coll.GetById([guid]$info.Id)
    $ctx.Load($new)
    Invoke-MigQuery $ctx
    if ($new.InternalName -ne $info.Name) {
        Write-MigLog "[$scope] '$($info.Name)' was created with internal name '$($new.InternalName)'" WARN
    }
    Sync-FieldProperties -Source $SourceField -Target $new -Label "$scope/$($info.Name)"
    Write-MigLog "[$scope] created column '$($SourceField.Title)' ($($info.Name), $($info.Type))" OK
    $new
}

# Brings display name and behaviour of an existing target field in line with the source.
function Sync-FieldProperties {
    param($Source, $Target, [string]$Label)
    $isOotb = (Get-FieldXmlInfo $Source.SchemaXml).IsOotb
    $v = [ordered]@{}
    if ($Target.Title -cne $Source.Title) { $v.Title = $Source.Title }
    if ("$($Target.Description)" -cne "$($Source.Description)") { $v.Description = $Source.Description }
    if ($Target.Required -ne $Source.Required) { $v.Required = $Source.Required }
    if (-not (Test-IsTaxonomyType $Source.TypeAsString) -and "$($Target.DefaultValue)" -cne "$($Source.DefaultValue)") { $v.DefaultValue = $Source.DefaultValue }
    if ($Target.Indexed -ne $Source.Indexed) { $v.Indexed = $Source.Indexed }
    if ($Target.EnforceUniqueValues -ne $Source.EnforceUniqueValues) { $v.EnforceUniqueValues = $Source.EnforceUniqueValues }
    if ("$($Target.ValidationFormula)" -cne "$($Source.ValidationFormula)") {
        $v.ValidationFormula = $Source.ValidationFormula
        $v.ValidationMessage = $Source.ValidationMessage
    }
    if (-not $isOotb -and $Target.Hidden -ne $Source.Hidden) { $v.Hidden = $Source.Hidden }
    if ($v.Count) { Set-ClientObjectProperties -Object $Target -Values $v -Label $Label }

    if ($Source.TypeAsString -in 'Choice', 'MultiChoice') { Sync-FieldChoices -Source $Source -Target $Target -Label $Label }
}

function Sync-FieldChoices {
    param($Source, $Target, [string]$Label)
    $sDoc = [xml]$Source.SchemaXml
    $tDoc = [xml]$Target.SchemaXml
    $sc = $sDoc.DocumentElement.SelectSingleNode('CHOICES')
    $tc = $tDoc.DocumentElement.SelectSingleNode('CHOICES')
    if (-not $sc -or ($tc -and $tc.OuterXml -eq $sc.OuterXml)) { return }
    $imported = $tDoc.ImportNode($sc, $true)
    if ($tc) { [void]$tDoc.DocumentElement.ReplaceChild($imported, $tc) } else { [void]$tDoc.DocumentElement.AppendChild($imported) }
    foreach ($a in 'Format', 'FillInChoice') {
        if ($sDoc.DocumentElement.HasAttribute($a)) { $tDoc.DocumentElement.SetAttribute($a, $sDoc.DocumentElement.GetAttribute($a)) }
    }
    try {
        $Target.SchemaXml = $tDoc.DocumentElement.OuterXml
        $Target.Update()
        Invoke-MigQuery $Target.Context
    }
    catch { Write-MigLog "[$Label] could not update choices: $($_.Exception.Message)" WARN }
}

# ---------------------------------------------------------------------------
# Site columns
# ---------------------------------------------------------------------------
function Initialize-SiteColumnCache {
    $sctx = $script:Mig.SrcCtx; $tctx = $script:Mig.TgtCtx
    $sWebFields = $sctx.Web.Fields; $sAvail = $sctx.Web.AvailableFields; $tAvail = $tctx.Web.AvailableFields
    $sctx.Load($sWebFields); $sctx.Load($sAvail); $tctx.Load($tAvail)
    Invoke-MigQuery $sctx; Invoke-MigQuery $tctx
    $script:Mig.SrcWebFields   = @($sWebFields)
    $script:Mig.SrcAvailFields = @{}; foreach ($f in $sAvail) { $script:Mig.SrcAvailFields[$f.Id.ToString()] = $f }
    $script:Mig.TgtAvailFields = @{}; foreach ($f in $tAvail) { $script:Mig.TgtAvailFields[$f.Id.ToString()] = $f }
}

# Creates the source site column with this id in the target web if it is missing.
function Confirm-SiteColumn {
    param([string]$FieldId)
    $FieldId = ([guid]$FieldId).ToString()
    if ($script:Mig.TgtAvailFields.ContainsKey($FieldId)) { return $true }
    $src = $script:Mig.SrcAvailFields[$FieldId]
    if (-not $src) { return $false }
    try {
        $new = New-TargetField -SourceField $src -TargetList $null
        if ($new) { $script:Mig.TgtAvailFields[$FieldId] = $new; return $true }
    }
    catch {
        Write-MigLog "[site columns] failed to create '$($src.InternalName)': $($_.Exception.Message)" ERROR
        Add-MigReport -Object 'SiteColumn' -SourceId $src.InternalName -Action 'Create' -Status Error -Message $_.Exception.Message
    }
    $false
}

# Site columns defined on Site A plus any (non built-in) site columns used by migrated lists.
function Copy-SiteColumns {
    param($Pairs)
    Initialize-SiteColumnCache
    $needed = @{}
    foreach ($f in $script:Mig.SrcWebFields) {
        if (-not (Get-FieldXmlInfo $f.SchemaXml).IsOotb) { $needed[$f.Id.ToString()] = $f }
    }
    foreach ($p in $Pairs) {
        foreach ($lf in (Get-PairFields $p)) {
            $site = $script:Mig.SrcAvailFields[$lf.Id.ToString()]
            if ($site -and -not (Get-FieldXmlInfo $site.SchemaXml).IsOotb) { $needed[$lf.Id.ToString()] = $site }
        }
    }
    $todo = $needed.Values | Where-Object { $_.InternalName -notin $script:SkipFieldNames -and $_.TypeAsString -notin $script:SkipFieldTypes } |
        Sort-Object { Get-FieldCreationRank (Get-FieldXmlInfo $_.SchemaXml) }
    $noteIds = Get-TaxonomyNoteFieldIds $needed.Values
    foreach ($f in $todo) {
        if ($noteIds.ContainsKey($f.Id.ToString())) { continue }
        [void](Confirm-SiteColumn $f.Id)
    }
    Write-MigLog "Site columns checked: $(@($todo).Count) custom column(s) considered" OK
}

# ---------------------------------------------------------------------------
# List columns
# ---------------------------------------------------------------------------
function Get-TargetFieldIndex {
    param($List)
    $ctx = $List.Context
    $fields = $List.Fields
    $ctx.Load($fields)
    Invoke-MigQuery $ctx
    $byName = @{}; $byId = @{}
    foreach ($f in $fields) { $byName[$f.InternalName] = $f; $byId[$f.Id.ToString()] = $f }
    [pscustomobject]@{ ByName = $byName; ById = $byId }
}

function Copy-ListFields {
    param($Pair)
    $tl = $Pair.Target; $tctx = $script:Mig.TgtCtx
    $label = "list '$($Pair.Title)'"
    $srcFields = Get-PairFields $Pair
    $noteIds = Get-TaxonomyNoteFieldIds $srcFields
    $idx = Get-TargetFieldIndex $tl

    $todo = $srcFields | Where-Object {
        -not $idx.ByName.ContainsKey($_.InternalName) -and -not $idx.ById.ContainsKey($_.Id.ToString()) -and
        $_.InternalName -notin $script:SkipFieldNames -and $_.TypeAsString -notin $script:SkipFieldTypes -and
        -not $noteIds.ContainsKey($_.Id.ToString())
    } | Sort-Object { Get-FieldCreationRank (Get-FieldXmlInfo $_.SchemaXml) }

    foreach ($sf in $todo) {
        $info = Get-FieldXmlInfo $sf.SchemaXml
        try {
            if ($script:Mig.TgtAvailFields.ContainsKey($sf.Id.ToString())) {
                # Site column exists in Site B: link it, then apply list-level overrides (e.g. renamed title).
                $added = $tl.Fields.Add($script:Mig.TgtAvailFields[$sf.Id.ToString()])
                $tctx.Load($added)
                Invoke-MigQuery $tctx
                Sync-FieldProperties -Source $sf -Target $added -Label "$label/$($sf.InternalName)"
                Write-MigLog "[$label] added site column '$($sf.Title)' ($($sf.InternalName))" OK
            }
            elseif ($info.IsOotb) {
                if (-not $sf.Hidden) { Write-MigLog "[$label] built-in column '$($sf.InternalName)' does not exist in Site B; skipped" WARN }
            }
            else {
                [void](New-TargetField -SourceField $sf -TargetList $tl -OwnSourceListId $Pair.Source.Id.ToString())
            }
        }
        catch {
            Write-MigLog "[$label] failed to create column '$($sf.InternalName)': $($_.Exception.Message)" ERROR
            Add-MigReport -List $Pair.Title -Object 'Field' -SourceId $sf.InternalName -Action 'Create' -Status Error -Message $_.Exception.Message
        }
    }

    # Reconcile columns that already existed (display names, required, choices...).
    $idx = Get-TargetFieldIndex $tl
    foreach ($sf in $srcFields) {
        $tf = $idx.ByName[$sf.InternalName]
        if (-not $tf -or $sf.InternalName -in $script:SkipFieldNames) { continue }
        $ootb = (Get-FieldXmlInfo $sf.SchemaXml).IsOotb
        if ($ootb -and ($sf.Hidden -or $sf.ReadOnlyField)) { continue }
        Sync-FieldProperties -Source $sf -Target $tf -Label "$label/$($sf.InternalName)"
    }
}
