# Finds the lists to migrate, pairs them with target lists, parses field XML, and writes the dry-run inventory.

$script:ListIncludes = @(
    'RootFolder', 'IsSystemList', 'IsSiteAssetsLibrary', 'IsCatalog', 'IsPrivate', 'OnQuickLaunch',
    'ReadSecurity', 'WriteSecurity', 'ValidationFormula', 'ValidationMessage', 'DraftVersionVisibility',
    'MajorVersionLimit', 'MajorWithMinorVersionsLimit', 'TemplateFeatureId', 'ItemCount', 'Direction',
    'EnableVersioning', 'EnableMinorVersions', 'EnableModeration', 'ForceCheckout', 'EnableAttachments',
    'EnableFolderCreation', 'ContentTypesEnabled', 'NoCrawl', 'Description', 'BaseTemplate', 'BaseType', 'Hidden'
)

function Get-SourceListSelection {
    $c = $script:Mig.Config
    $webUrl = $script:Mig.SrcWeb.ServerRelativeUrl
    $result = @()
    foreach ($l in (Get-PnPList -Connection $script:Mig.Src -Includes $script:ListIncludes)) {
        $rel = Get-WebRelativeUrl $l.RootFolder.ServerRelativeUrl $webUrl
        $reason = $null
        if ($c.IncludeListUrls -and @($c.IncludeListUrls).Count -and $rel -notin $c.IncludeListUrls) { $reason = 'not in IncludeListUrls' }
        elseif ($rel -in $c.ExcludeListUrls) { $reason = 'excluded by URL' }
        elseif ([int]$l.BaseTemplate -in $c.ExcludeBaseTemplates) { $reason = "excluded template $([int]$l.BaseTemplate)" }
        elseif ($l.Hidden) { $reason = 'hidden list' }
        elseif ($l.IsCatalog -or $l.IsSystemList -or $l.IsPrivate) { $reason = 'system/catalog list' }
        $result += [pscustomobject]@{ List = $l; WebRelUrl = $rel; Excluded = $reason }
    }
    $result
}

function Get-TargetListByUrl {
    param([string]$WebRelUrl)
    $ctx = $script:Mig.TgtCtx
    $url = $script:Mig.TgtWeb.ServerRelativeUrl.TrimEnd('/') + '/' + $WebRelUrl
    try {
        $l = $ctx.Web.GetList($url)
        $ctx.Load($l)
        $ctx.Load($l.RootFolder)
        Invoke-MigQuery $ctx
        return $l
    }
    catch { return $null }
}

# Builds one "pair" object per migrated list. Target is $null until the schema phase creates it.
function Get-ListPairs {
    $pairs = [ordered]@{}
    foreach ($s in (Get-SourceListSelection)) {
        if ($s.Excluded) {
            Write-MigLog "Skipping '$($s.List.Title)' ($($s.WebRelUrl)): $($s.Excluded)" DEBUG
            continue
        }
        $l = $s.List
        $t = Get-TargetListByUrl $s.WebRelUrl
        $pairs[$l.Id.ToString()] = [pscustomobject]@{
            Title         = $l.Title
            WebRelUrl     = $s.WebRelUrl
            Source        = $l
            Target        = $t
            SourceRootUrl = $l.RootFolder.ServerRelativeUrl
            TargetRootUrl = if ($t) { $t.RootFolder.ServerRelativeUrl } else { $null }
            IsLibrary     = ($l.BaseType -eq 'DocumentLibrary')
            SourceFields  = $null
            Fields        = $null
            CtMap         = $null
        }
    }
    $script:Mig.Pairs = $pairs
    $pairs
}

function Get-PairFields {
    # Loads (once) the source list's fields.
    param($Pair)
    if (-not $Pair.SourceFields) {
        $ctx = $Pair.Source.Context
        $f = $Pair.Source.Fields
        $ctx.Load($f)
        Invoke-MigQuery $ctx
        $Pair.SourceFields = @($f)
    }
    $Pair.SourceFields
}

# Parses a field's SchemaXml into the bits the migration needs.
function Get-FieldXmlInfo {
    param([string]$SchemaXml)
    $f = ([xml]$SchemaXml).DocumentElement
    $props = @{}
    foreach ($p in $f.SelectNodes('Customization/ArrayOfProperty/Property')) {
        $n = $p.SelectSingleNode('Name'); $v = $p.SelectSingleNode('Value')
        if ($n -and $v) { $props[$n.InnerText] = $v.InnerText }
    }
    [pscustomobject]@{
        Id          = $f.GetAttribute('ID')
        Name        = $f.GetAttribute('Name')
        DisplayName = $f.GetAttribute('DisplayName')
        Type        = $f.GetAttribute('Type')
        List        = $f.GetAttribute('List')
        WebId       = $f.GetAttribute('WebId')
        ShowField   = $f.GetAttribute('ShowField')
        PrimaryRef  = $f.GetAttribute('FieldRef')      # set on dependent (projected) lookups
        Mult        = ($f.GetAttribute('Mult') -eq 'TRUE')
        SourceID    = $f.GetAttribute('SourceID')
        IsOotb      = $f.GetAttribute('SourceID') -like 'http://schemas.microsoft.com/*'
        Props       = $props                            # taxonomy: SspId, TermSetId, AnchorId, TextField, ...
    }
}

function Test-IsTaxonomyType { param([string]$Type) $Type -like 'TaxonomyFieldType*' }

# Note fields that back taxonomy fields; SharePoint maintains them itself.
function Get-TaxonomyNoteFieldIds {
    param($Fields)
    $ids = @{}
    foreach ($f in $Fields) {
        if (Test-IsTaxonomyType $f.TypeAsString) {
            $tf = (Get-FieldXmlInfo $f.SchemaXml).Props['TextField']
            if ($tf) { $ids[([guid]$tf).ToString()] = $true }
        }
    }
    $ids
}

function Export-Inventory {
    param($Selection)
    $rows = foreach ($s in $Selection) {
        $l = $s.List
        $row = [ordered]@{
            Title = $l.Title; Url = $s.WebRelUrl; Template = [int]$l.BaseTemplate; IsLibrary = ($l.BaseType -eq 'DocumentLibrary')
            ItemCount = $l.ItemCount; Migrate = (-not $s.Excluded); ExcludedReason = $s.Excluded
            ExistsInTarget = ''; Versioning = $l.EnableVersioning; MinorVersions = $l.EnableMinorVersions
            ContentApproval = $l.EnableModeration; ContentTypes = ''; CustomFields = ''; Lookups = ''; Taxonomy = ''; Views = ''
        }
        if (-not $s.Excluded) {
            $ctx = $l.Context
            $fields = $l.Fields; $cts = $l.ContentTypes; $views = $l.Views
            $ctx.Load($fields); $ctx.Load($cts); $ctx.Load($views)
            Invoke-MigQuery $ctx
            $infos = @($fields | ForEach-Object { Get-FieldXmlInfo $_.SchemaXml })
            $custom = @($infos | Where-Object { -not $_.IsOotb })
            $row.ExistsInTarget = [bool](Get-TargetListByUrl $s.WebRelUrl)
            $row.ContentTypes = (@($cts | ForEach-Object Name) -join '; ')
            $row.CustomFields = (@($custom | ForEach-Object Name) -join '; ')
            $row.Lookups = (@($infos | Where-Object { $_.Type -like 'Lookup*' -and $_.Name -ne 'TaxCatchAll' -and $_.Name -ne 'TaxCatchAllLabel' } | ForEach-Object Name) -join '; ')
            $row.Taxonomy = (@($infos | Where-Object { Test-IsTaxonomyType $_.Type } | ForEach-Object Name) -join '; ')
            $row.Views = (@($views | Where-Object { -not $_.Hidden } | ForEach-Object Title) -join '; ')
        }
        [pscustomobject]$row
    }
    $path = Join-Path $script:Mig.ReportDir "inventory-$(Get-Date -Format 'yyyyMMdd-HHmmss').csv"
    $rows | Export-Csv -Path $path -NoTypeInformation -Encoding utf8
    $rows | Format-Table Title, Url, Template, ItemCount, Migrate, ExcludedReason, ExistsInTarget -AutoSize | Out-String | Write-Host
    Write-MigLog "Inventory written to $path" OK
}
