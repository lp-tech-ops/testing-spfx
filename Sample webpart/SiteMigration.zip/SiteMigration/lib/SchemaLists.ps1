# Lists, list settings, views, regional settings, and the schema/finalize phase drivers.

function Copy-RegionalSettings {
    $sctx = $script:Mig.SrcCtx; $tctx = $script:Mig.TgtCtx
    $s = $sctx.Web.RegionalSettings; $t = $tctx.Web.RegionalSettings
    $sctx.Load($s); $sctx.Load($s.TimeZone); $tctx.Load($t); $tctx.Load($t.TimeZone)
    Invoke-MigQuery $sctx; Invoke-MigQuery $tctx

    $v = [ordered]@{}
    foreach ($p in 'LocaleId', 'Time24', 'FirstDayOfWeek', 'FirstWeekOfYear', 'CalendarType', 'ShowWeeks', 'WorkDays', 'WorkDayStartHour', 'WorkDayEndHour') {
        if ($t.$p -ne $s.$p) { $v[$p] = $s.$p }
    }
    if ($t.TimeZone.Id -ne $s.TimeZone.Id) { $v.TimeZone = $t.TimeZones.GetById($s.TimeZone.Id) }
    if ($v.Count) {
        Set-ClientObjectProperties -Object $t -Values $v -Label 'regional settings'
        Write-MigLog "Regional settings copied (time zone: $($s.TimeZone.Description))" OK
    }
}

function New-TargetList {
    param($Pair)
    $s = $Pair.Source; $ctx = $script:Mig.TgtCtx
    $make = {
        param([bool]$UseFeature, [int]$Template)
        $lci = [Microsoft.SharePoint.Client.ListCreationInformation]::new()
        $lci.Title = $s.Title
        $lci.Url = $Pair.WebRelUrl
        $lci.TemplateType = $Template
        $lci.Description = $s.Description
        if ($UseFeature -and $s.TemplateFeatureId -ne [guid]::Empty) { $lci.TemplateFeatureId = $s.TemplateFeatureId }
        $l = $ctx.Web.Lists.Add($lci)
        $ctx.Load($l); $ctx.Load($l.RootFolder)
        Invoke-MigQuery $ctx
        $l
    }
    try { return (& $make $true ([int]$s.BaseTemplate)) }
    catch {
        # Custom/sandboxed list templates don't exist in Site B: fall back to the generic base template.
        $fallback = if ($Pair.IsLibrary) { 101 } else { 100 }
        Write-MigLog "[list '$($Pair.Title)'] template $([int]$s.BaseTemplate) failed ($($_.Exception.Message)); using $fallback" WARN
        return (& $make $false $fallback)
    }
}

# Settings applied before data load. Content approval, required check-out and list
# validation are deferred to Finalize so they don't interfere with the copy.
function Set-TargetListSettings {
    param($Pair)
    $s = $Pair.Source; $t = $Pair.Target
    $v = [ordered]@{
        Title = $s.Title; Description = $s.Description; EnableVersioning = $s.EnableVersioning
        EnableFolderCreation = $s.EnableFolderCreation; NoCrawl = $s.NoCrawl
        OnQuickLaunch = $s.OnQuickLaunch; Direction = $s.Direction; EnableModeration = $false
    }
    if ($Pair.IsLibrary) {
        $v.ForceCheckout = $false
        $v.EnableMinorVersions = $s.EnableMinorVersions
        if ($s.EnableMinorVersions) {
            $v.MajorWithMinorVersionsLimit = $s.MajorWithMinorVersionsLimit
            $v.DraftVersionVisibility = $s.DraftVersionVisibility
        }
    }
    else {
        $v.EnableAttachments = $s.EnableAttachments
        $v.ReadSecurity = $s.ReadSecurity; $v.WriteSecurity = $s.WriteSecurity
    }
    if ($s.EnableVersioning) { $v.MajorVersionLimit = $s.MajorVersionLimit }

    $changed = [ordered]@{}
    foreach ($k in $v.Keys) {
        try { if ("$($t.$k)" -ne "$($v[$k])") { $changed[$k] = $v[$k] } } catch { $changed[$k] = $v[$k] }
    }
    if ($changed.Count) { Set-ClientObjectProperties -Object $t -Values $changed -Label "list '$($Pair.Title)'" }
}

function Copy-ListViews {
    param($Pair)
    $label = "list '$($Pair.Title)'"
    $sl = $Pair.Source; $tl = $Pair.Target
    $sctx = $sl.Context; $tctx = $tl.Context
    $sViews = $sl.Views; $tViews = $tl.Views
    $sctx.Load($sViews); $tctx.Load($tViews)
    Invoke-MigQuery $sctx; Invoke-MigQuery $tctx
    $tFieldNames = (Get-TargetFieldIndex $tl).ByName

    foreach ($sv in $sViews) {
        if ($sv.Hidden -or $sv.PersonalView) { continue }
        try {
            $sctx.Load($sv.ViewFields)
            Invoke-MigQuery $sctx
            $fields = @($sv.ViewFields | Where-Object { $tFieldNames.ContainsKey($_) })
            $missing = @($sv.ViewFields | Where-Object { -not $tFieldNames.ContainsKey($_) })
            if ($missing.Count) { Write-MigLog "[$label] view '$($sv.Title)': columns not in Site B skipped: $($missing -join ', ')" WARN }

            $leaf = [System.IO.Path]::GetFileNameWithoutExtension($sv.ServerRelativeUrl)
            $tv = $tViews | Where-Object { $_.Title -eq $sv.Title -or [System.IO.Path]::GetFileNameWithoutExtension($_.ServerRelativeUrl) -eq $leaf } | Select-Object -First 1
            if (-not $tv) {
                $kind = [Microsoft.SharePoint.Client.ViewType]::Html
                try { $kind = [Enum]::Parse([Microsoft.SharePoint.Client.ViewType], $sv.ViewType, $true) } catch { }
                $vci = [Microsoft.SharePoint.Client.ViewCreationInformation]::new()
                $vci.Title = $leaf              # creates the same URL as Site A; renamed below
                $vci.ViewTypeKind = $kind
                $vci.Query = $sv.ViewQuery
                $vci.RowLimit = $sv.RowLimit
                $vci.Paged = $sv.Paged
                $vci.PersonalView = $false
                $vci.SetAsDefaultView = $sv.DefaultView
                $vci.ViewFields = [string[]]$fields
                $tv = $tViews.Add($vci)
                $tctx.Load($tv)
                Invoke-MigQuery $tctx
                Write-MigLog "[$label] created view '$($sv.Title)'" OK
            }
            else {
                $tv.ViewFields.RemoveAll()
                foreach ($f in $fields) { $tv.ViewFields.Add($f) }
                $tv.Update()
                Invoke-MigQuery $tctx
            }

            $v = [ordered]@{ Title = $sv.Title; ViewQuery = $sv.ViewQuery; RowLimit = $sv.RowLimit; Paged = $sv.Paged; Scope = $sv.Scope }
            foreach ($p in 'ViewData', 'Aggregations', 'AggregationsStatus', 'ViewJoins', 'ViewProjectedFields') {
                if ($sv.$p) { $v[$p] = $sv.$p }
            }
            if ($sv.DefaultView) { $v.DefaultView = $true }
            $diff = [ordered]@{}
            foreach ($k in $v.Keys) { if ("$($tv.$k)" -ne "$($v[$k])") { $diff[$k] = $v[$k] } }
            if ($diff.Count) { Set-ClientObjectProperties -Object $tv -Values $diff -Label "$label/view '$($sv.Title)'" }
        }
        catch {
            Write-MigLog "[$label] view '$($sv.Title)' failed: $($_.Exception.Message)" ERROR
            Add-MigReport -List $Pair.Title -Object 'View' -SourceId $sv.Title -Action 'Copy' -Status Error -Message $_.Exception.Message
        }
    }
}

function Invoke-SchemaPhase {
    param($Pairs)
    Write-MigLog '===== SCHEMA PHASE ====='
    if ($script:Mig.Config.CopyRegionalSettings) { Copy-RegionalSettings }

    # 1. Lists first, so lookup columns can point at them.
    foreach ($p in $Pairs) {
        if ($p.Target) { Write-MigLog "[list '$($p.Title)'] already exists in Site B; merging"; continue }
        try {
            $p.Target = New-TargetList $p
            $p.TargetRootUrl = $p.Target.RootFolder.ServerRelativeUrl
            Write-MigLog "[list '$($p.Title)'] created at $($p.TargetRootUrl)" OK
            Add-MigReport -List $p.Title -Object 'List' -SourceId $p.Source.Id -TargetId $p.Target.Id -Action 'Create' -Status OK
        }
        catch {
            Write-MigLog "[list '$($p.Title)'] creation failed: $($_.Exception.Message)" ERROR
            Add-MigReport -List $p.Title -Object 'List' -SourceId $p.Source.Id -Action 'Create' -Status Error -Message $_.Exception.Message
        }
    }
    $ready = @($Pairs | Where-Object Target)

    # 2-4. Site columns, site content types, list content types.
    Copy-SiteColumns $ready
    Copy-SiteContentTypes $ready
    foreach ($p in $ready) { Copy-ListContentTypes $p }

    # 5-7. List columns, settings, views.
    foreach ($p in $ready) { Copy-ListFields $p }
    foreach ($p in $ready) { Set-TargetListSettings $p }
    foreach ($p in $ready) { Copy-ListViews $p }
    Write-MigLog 'Schema phase complete' OK
}

# Turns on the settings that would have blocked the data copy, and restores approval status.
function Invoke-FinalizePhase {
    param($Pairs)
    Write-MigLog '===== FINALIZE PHASE ====='
    foreach ($p in @($Pairs | Where-Object Target)) {
        $s = $p.Source
        $v = [ordered]@{}
        if ($s.EnableModeration) { $v.EnableModeration = $true }
        if ($p.IsLibrary -and $s.ForceCheckout) { $v.ForceCheckout = $true }
        if ($s.ValidationFormula) { $v.ValidationFormula = $s.ValidationFormula; $v.ValidationMessage = $s.ValidationMessage }
        if ($v.Count) { Set-ClientObjectProperties -Object $p.Target -Values $v -Label "list '$($p.Title)'" }
        if ($s.EnableModeration) { Restore-ModerationStatus $p }
    }
    Write-MigLog 'Finalize phase complete' OK
}

# Enabling content approval marks everything Approved; put back Pending/Rejected/Draft items.
function Restore-ModerationStatus {
    param($Pair)
    $map = Get-ItemMap $Pair.Source.Id
    $q = '<View Scope="RecursiveAll"><Query><Where><Neq><FieldRef Name="_ModerationStatus"/><Value Type="ModStat">0</Value></Neq></Where></Query></View>'
    try { $items = Get-PnPListItem -List $Pair.Source.Id -Query $q -PageSize $script:Mig.Config.PageSize -Connection $script:Mig.Src }
    catch {
        # Filtering a non-indexed column can hit the list view threshold; scan everything instead.
        $items = Get-PnPListItem -List $Pair.Source.Id -PageSize $script:Mig.Config.PageSize -Connection $script:Mig.Src |
            Where-Object { [int]$_['_ModerationStatus'] -ne 0 }
    }
    $ctx = $Pair.Target.Context
    foreach ($si in $items) {
        $row = $map[[int]$si.Id]
        if (-not $row) { continue }
        try {
            $ti = $Pair.Target.GetItemById([int]$row.TargetId)
            $ti['_ModerationStatus'] = [int]$si['_ModerationStatus']
            if ($si['_ModerationComments']) { $ti['_ModerationComments'] = $si['_ModerationComments'] }
            $ti['Modified'] = $si['Modified']
            $ed = Resolve-PrincipalId $si['Editor'].LookupId
            if ($ed) { $ti['Editor'] = [Microsoft.SharePoint.Client.FieldUserValue]@{ LookupId = $ed } }
            $ti.UpdateOverwriteVersion()
            Invoke-MigQuery $ctx
        }
        catch { Write-MigLog "[list '$($Pair.Title)'] approval status for item $($si.Id) not restored: $($_.Exception.Message)" WARN }
    }
}
