# Site content types (same IDs) and list content type bindings / order.

# List content types are "<site content type id>00<32 hex>"; returns the site content type id.
function Get-ParentContentTypeId {
    param([string]$Id)
    if ($Id.Length -gt 34 -and $Id.Substring($Id.Length - 34, 2) -eq '00') { return $Id.Substring(0, $Id.Length - 34) }
    $Id
}

function Copy-SiteContentTypes {
    param($Pairs)
    $sctx = $script:Mig.SrcCtx; $tctx = $script:Mig.TgtCtx
    $sAvail = $sctx.Web.AvailableContentTypes; $sWeb = $sctx.Web.ContentTypes; $tAvail = $tctx.Web.AvailableContentTypes
    $sctx.Load($sAvail); $sctx.Load($sWeb); $tctx.Load($tAvail)
    Invoke-MigQuery $sctx; Invoke-MigQuery $tctx

    $srcById = @{}; foreach ($ct in $sAvail) { $srcById[$ct.StringId] = $ct }
    $tgtIds = @{}; foreach ($ct in $tAvail) { $tgtIds[$ct.StringId] = $true }

    # Content types defined on Site A itself + those (and their ancestors) used by migrated lists.
    $wanted = @{}
    foreach ($ct in $sWeb) { $wanted[$ct.StringId] = $true }
    foreach ($p in $Pairs) {
        $lcts = $p.Source.ContentTypes
        $sctx.Load($lcts)
        Invoke-MigQuery $sctx
        foreach ($lct in $lcts) { $wanted[(Get-ParentContentTypeId $lct.StringId)] = $true }
    }
    $needed = @{}
    foreach ($id in @($wanted.Keys)) {
        foreach ($k in $srcById.Keys) {
            if ($id.StartsWith($k, [StringComparison]::OrdinalIgnoreCase) -and -not $tgtIds.ContainsKey($k)) { $needed[$k] = $true }
        }
    }

    foreach ($id in ($needed.Keys | Sort-Object Length)) {
        $s = $srcById[$id]
        try {
            Add-PnPContentType -Name $s.Name -ContentTypeId $id -Group $s.Group -Description $s.Description -Connection $script:Mig.Tgt | Out-Null
            Write-MigLog "[content types] created '$($s.Name)' ($id)" OK
            Sync-ContentTypeFieldLinks -SourceCt $s -TargetCtId $id
        }
        catch {
            Write-MigLog "[content types] failed to create '$($s.Name)': $($_.Exception.Message)" ERROR
            Add-MigReport -Object 'ContentType' -SourceId $id -Action 'Create' -Status Error -Message $_.Exception.Message
        }
    }
}

function Sync-ContentTypeFieldLinks {
    param($SourceCt, [string]$TargetCtId)
    $sctx = $script:Mig.SrcCtx; $tctx = $script:Mig.TgtCtx
    $sLinks = $SourceCt.FieldLinks
    $sctx.Load($sLinks)
    Invoke-MigQuery $sctx
    $tCt = $tctx.Web.ContentTypes.GetById($TargetCtId)
    $tLinks = $tCt.FieldLinks
    $tctx.Load($tLinks)
    Invoke-MigQuery $tctx
    $have = @{}; foreach ($l in $tLinks) { $have[$l.Id.ToString()] = $true }

    foreach ($l in $sLinks) {
        if ($have.ContainsKey($l.Id.ToString())) { continue }
        if (-not (Confirm-SiteColumn $l.Id)) {
            Write-MigLog "[content types] '$($SourceCt.Name)': column '$($l.Name)' not available in Site B; link skipped" WARN
            continue
        }
        try {
            Add-PnPFieldToContentType -Field $l.Id -ContentType $TargetCtId -Required:$l.Required -Hidden:$l.Hidden -Connection $script:Mig.Tgt
        }
        catch { Write-MigLog "[content types] '$($SourceCt.Name)': could not add column '$($l.Name)': $($_.Exception.Message)" WARN }
    }
}

# Source list CT id -> target list CT id (matched by parent site CT, then by name).
function Get-ContentTypeMap {
    param($Pair)
    $sctx = $Pair.Source.Context; $tctx = $Pair.Target.Context
    $s = $Pair.Source.ContentTypes; $t = $Pair.Target.ContentTypes
    $sctx.Load($s); $tctx.Load($t)
    Invoke-MigQuery $sctx; Invoke-MigQuery $tctx
    $map = @{}
    foreach ($sct in $s) {
        $parent = Get-ParentContentTypeId $sct.StringId
        $m = @($t | Where-Object { (Get-ParentContentTypeId $_.StringId) -eq $parent }) + @($t | Where-Object { $_.Name -eq $sct.Name })
        if ($m.Count) { $map[$sct.StringId] = $m[0] }
    }
    $Pair.CtMap = $map
    $map
}

function Copy-ListContentTypes {
    param($Pair)
    $label = "list '$($Pair.Title)'"
    $tl = $Pair.Target; $sl = $Pair.Source
    $tctx = $tl.Context; $sctx = $sl.Context

    if ($sl.ContentTypesEnabled -and -not $tl.ContentTypesEnabled) {
        Set-ClientObjectProperties -Object $tl -Values ([ordered]@{ ContentTypesEnabled = $true }) -Label $label
    }

    $sCts = $sl.ContentTypes; $tCts = $tl.ContentTypes
    $sctx.Load($sCts); $tctx.Load($tCts)
    Invoke-MigQuery $sctx; Invoke-MigQuery $tctx

    foreach ($sct in $sCts) {
        $parent = Get-ParentContentTypeId $sct.StringId
        $exists = $tCts | Where-Object { (Get-ParentContentTypeId $_.StringId) -eq $parent -or $_.Name -eq $sct.Name }
        if ($exists) { continue }
        try {
            Add-PnPContentTypeToList -List $tl.Id -ContentType $parent -Connection $script:Mig.Tgt
            Write-MigLog "[$label] added content type '$($sct.Name)'" OK
        }
        catch { Write-MigLog "[$label] could not add content type '$($sct.Name)': $($_.Exception.Message)" WARN }
    }

    # Remove target-only content types (e.g. default Item/Document when Site A used custom ones).
    $tctx.Load($tCts)
    Invoke-MigQuery $tctx
    $sParents = @($sCts | ForEach-Object { Get-ParentContentTypeId $_.StringId })
    $sNames = @($sCts | ForEach-Object Name)
    foreach ($tct in @($tCts)) {
        $tp = Get-ParentContentTypeId $tct.StringId
        if ($tp -in $sParents -or $tct.Name -in $sNames -or $tp -like '0x0120*') { continue }
        try {
            $tct.DeleteObject()
            Invoke-MigQuery $tctx
            Write-MigLog "[$label] removed content type '$($tct.Name)' (not used in Site A)"
        }
        catch { Write-MigLog "[$label] could not remove content type '$($tct.Name)': $($_.Exception.Message)" WARN }
    }

    # New-button order and default content type.
    $map = Get-ContentTypeMap $Pair
    $order = Get-PnPProperty -ClientObject $sl.RootFolder -Property UniqueContentTypeOrder -Connection $script:Mig.Src
    if (-not $order) { $order = Get-PnPProperty -ClientObject $sl.RootFolder -Property ContentTypeOrder -Connection $script:Mig.Src }
    $ids = [System.Collections.Generic.List[Microsoft.SharePoint.Client.ContentTypeId]]::new()
    foreach ($o in @($order)) {
        $t = $map[$o.StringValue]
        if ($t) { $ids.Add($t.Id) }
    }
    if ($ids.Count) {
        try {
            $tl.RootFolder.UniqueContentTypeOrder = $ids
            $tl.RootFolder.Update()
            Invoke-MigQuery $tctx
        }
        catch { Write-MigLog "[$label] could not set content type order: $($_.Exception.Message)" WARN }
    }
}
