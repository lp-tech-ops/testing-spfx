# List items (with version history and attachments), folders, deferred lookups and the data phase driver.

# Decides what to do with a source item based on the resume state.
function Get-ItemAction {
    param($Map, $SourceItem)
    $row = $Map[[int]$SourceItem.Id]
    if (-not $row) { return 'Create' }
    if ($script:Mig.RefreshExisting) { return 'Refresh' }
    $srcMod = ([datetime]$SourceItem['Modified']).ToUniversalTime()
    if ($srcMod -gt (ConvertFrom-StateDate $row.SourceModified).AddSeconds(1)) { return 'Delta' }
    'Skip'
}

# Snapshots (oldest first) to replay: every version, or only versions newer than $AfterVersion.
function Get-SourceSnapshots {
    param($Pair, $SourceItem, [string]$AfterVersion, [switch]$CurrentOnly)
    $current = [pscustomobject]@{
        Label = "$($SourceItem['_UIVersionString'])"; Values = $SourceItem.FieldValues
        Modified = $SourceItem['Modified']; Editor = $SourceItem['Editor']; FileVersion = $null; IsCurrent = $true
    }
    if ($CurrentOnly -or -not $script:Mig.Config.MigrateVersions -or -not $Pair.Source.EnableVersioning) { return , @($current) }

    $ctx = $Pair.Source.Context
    $li = $Pair.Source.GetItemById([int]$SourceItem.Id)
    $vers = $li.Versions
    $ctx.Load($vers)
    $fileVers = $null
    if ($Pair.IsLibrary) { $fileVers = $li.File.Versions; $ctx.Load($fileVers) }
    Invoke-MigQuery $ctx

    $snaps = @($vers | Sort-Object { ConvertTo-VersionNumber $_.VersionLabel } | ForEach-Object {
            $fv = $_.FieldValues
            $label = $_.VersionLabel
            [pscustomobject]@{
                Label       = $label
                Values      = $fv
                Modified    = if ($fv.ContainsKey('Modified')) { $fv['Modified'] } else { $_.Created }
                Editor      = if ($fv.ContainsKey('Editor')) { $fv['Editor'] } else { $SourceItem['Editor'] }
                FileVersion = if ($fileVers) { $fileVers | Where-Object { $_.VersionLabel -eq $label } | Select-Object -First 1 } else { $null }
                IsCurrent   = $_.IsCurrentVersion
            }
        })
    if (-not $snaps.Count) { $snaps = @($current) }
    if ($AfterVersion) {
        $after = ConvertTo-VersionNumber $AfterVersion
        $snaps = @($snaps | Where-Object { (ConvertTo-VersionNumber $_.Label) -gt $after })
    }
    , $snaps
}

function Get-SnapshotSystemValues {
    param($SourceItem, $Snapshot, [switch]$IncludeCreated)
    Get-SystemValues -Values @{
        Modified = $Snapshot.Modified; Editor = $Snapshot.Editor
        Created = $SourceItem['Created']; Author = $SourceItem['Author']
    } -IncludeCreated:$IncludeCreated
}

function Get-TargetContentTypeId {
    param($Pair, $SourceItem)
    $sct = $SourceItem['ContentTypeId']
    if (-not $sct) { return $null }
    $t = $Pair.CtMap["$($sct.StringValue)"]
    if ($t) { $t.StringId } else { $null }
}

function Copy-ItemAttachments {
    param($Pair, [int]$SourceId, $TargetItem)
    $sctx = $Pair.Source.Context; $tctx = $Pair.Target.Context
    $att = $Pair.Source.GetItemById($SourceId).AttachmentFiles
    $sctx.Load($att)
    $tAtt = $TargetItem.AttachmentFiles
    $tctx.Load($tAtt)
    Invoke-MigQuery $sctx; Invoke-MigQuery $tctx
    $have = @{}; foreach ($a in $tAtt) { $have[$a.FileName] = $true }
    $added = 0
    foreach ($a in $att) {
        if ($have.ContainsKey($a.FileName)) { continue }
        $file = $sctx.Web.GetFileByServerRelativePath((New-ResourcePath $a.ServerRelativeUrl))
        $data = $file.OpenBinaryStream()
        Invoke-MigQuery $sctx
        $aci = [Microsoft.SharePoint.Client.AttachmentCreationInformation]::new()
        $aci.FileName = $a.FileName
        $aci.ContentStream = Read-ClientStream $data
        $null = $TargetItem.AttachmentFiles.Add($aci)
        Invoke-MigQuery $tctx
        $added++
    }
    $added
}

function Add-DeferredLookup {
    param($Pair, [int]$SourceId, [string[]]$Fields)
    [pscustomobject]@{ SourceListId = $Pair.Source.Id; SourceId = $SourceId; Fields = (($Fields | Select-Object -Unique) -join ';') } |
        Export-Csv -Path (Get-StatePath 'deferred-lookups') -Append -NoTypeInformation -Encoding utf8
}

function Copy-ListItemWithVersions {
    param($Pair, $SourceItem, [string]$Action)
    $tctx = $Pair.Target.Context
    $srcId = [int]$SourceItem.Id
    $map = Get-ItemMap $Pair.Source.Id
    $row = $map[$srcId]

    $snaps = switch ($Action) {
        'Create' { Get-SourceSnapshots -Pair $Pair -SourceItem $SourceItem }
        'Delta' { Get-SourceSnapshots -Pair $Pair -SourceItem $SourceItem -AfterVersion $row.SourceVersion }
        'Refresh' { Get-SourceSnapshots -Pair $Pair -SourceItem $SourceItem -CurrentOnly }
    }
    if ($Action -eq 'Delta' -and -not @($snaps).Count) {
        # Changed without a new version (e.g. system update): re-apply current values in place.
        $snaps = Get-SourceSnapshots -Pair $Pair -SourceItem $SourceItem -CurrentOnly
        $Action = 'Refresh'
    }

    if ($Action -eq 'Create') {
        $ici = [Microsoft.SharePoint.Client.ListItemCreationInformation]::new()
        $folder = Convert-ToTargetUrl $Pair $SourceItem['FileDirRef']
        if ($folder -ne $Pair.TargetRootUrl.TrimEnd('/')) { $ici.FolderUrl = $folder }
        $ti = $Pair.Target.AddItem($ici)
    }
    else {
        $ti = $Pair.Target.GetItemById([int]$row.TargetId)
    }

    $deferred = @()
    $first = ($Action -eq 'Create')
    foreach ($s in @($snaps)) {
        $sys = Get-SnapshotSystemValues -SourceItem $SourceItem -Snapshot $s -IncludeCreated:$first
        $ct = if ($first) { Get-TargetContentTypeId $Pair $SourceItem } else { $null }
        $d = Set-TargetItemValues -Pair $Pair -Item $ti -Values $s.Values -System $sys -ContentTypeId $ct
        if ($s.IsCurrent) { $deferred = $d }
        if ($Action -eq 'Refresh') { $ti.UpdateOverwriteVersion() } else { $ti.Update() }
        if ($first) { $tctx.Load($ti) }
        Invoke-MigQuery $tctx
        $first = $false
    }

    if ($Pair.Source.EnableAttachments -and $SourceItem['Attachments']) {
        $n = Copy-ItemAttachments -Pair $Pair -SourceId $srcId -TargetItem $ti
        if ($n) {
            # Adding attachments stamps the migration account; put back the last editor/time.
            $last = @($snaps)[-1]
            $sys = Get-SnapshotSystemValues -SourceItem $SourceItem -Snapshot $last
            foreach ($k in $sys.Keys) { $ti[$k] = $sys[$k] }
            $ti.UpdateOverwriteVersion()
            Invoke-MigQuery $tctx
        }
    }

    if ($deferred) { Add-DeferredLookup -Pair $Pair -SourceId $srcId -Fields $deferred }
    $targetId = if ($row -and $Action -ne 'Create') { [int]$row.TargetId } else { $ti.Id }
    Set-ItemMapEntry -SourceListId $Pair.Source.Id -SourceId $srcId -TargetId $targetId -SourceModified $SourceItem['Modified'] -SourceVersion "$($SourceItem['_UIVersionString'])"
    Add-MigReport -List $Pair.Title -Object 'Item' -SourceId $srcId -TargetId $targetId -Action $Action -Status OK -Message "$(@($snaps).Count) version(s)"
}

function Copy-FolderItem {
    param($Pair, $SourceItem, [string]$Action)
    $ctx = $Pair.Target.Context
    $tUrl = Convert-ToTargetUrl $Pair $SourceItem['FileRef']
    $null = Resolve-PnPFolder -SiteRelativePath (Get-WebRelativeUrl $tUrl $script:Mig.TgtWeb.ServerRelativeUrl) -Connection $script:Mig.Tgt
    $ti = $ctx.Web.GetFolderByServerRelativePath((New-ResourcePath $tUrl)).ListItemAllFields
    $ctx.Load($ti)
    Invoke-MigQuery $ctx

    $snap = (Get-SourceSnapshots -Pair $Pair -SourceItem $SourceItem -CurrentOnly)[0]
    $sys = Get-SnapshotSystemValues -SourceItem $SourceItem -Snapshot $snap -IncludeCreated
    $d = Set-TargetItemValues -Pair $Pair -Item $ti -Values $snap.Values -System $sys -ContentTypeId (Get-TargetContentTypeId $Pair $SourceItem)
    $ti.UpdateOverwriteVersion()
    Invoke-MigQuery $ctx
    if ($d) { Add-DeferredLookup -Pair $Pair -SourceId $SourceItem.Id -Fields $d }
    Set-ItemMapEntry -SourceListId $Pair.Source.Id -SourceId $SourceItem.Id -TargetId $ti.Id -SourceModified $SourceItem['Modified'] -SourceVersion "$($SourceItem['_UIVersionString'])"
    Add-MigReport -List $Pair.Title -Object 'Folder' -SourceId $SourceItem.Id -TargetId $ti.Id -Action $Action -Status OK -Message $tUrl
}

# Lookup columns whose target item did not exist yet when the item was copied.
function Complete-DeferredLookups {
    $path = Get-StatePath 'deferred-lookups'
    if (-not (Test-Path $path)) { return }
    $rows = @(Import-Csv $path)
    Write-MigLog "Fixing up $($rows.Count) deferred lookup value(s)"
    foreach ($r in $rows) {
        $pair = $script:Mig.Pairs[$r.SourceListId]
        if (-not $pair -or -not $pair.Target) { continue }
        $row = (Get-ItemMap $pair.Source.Id)[[int]$r.SourceId]
        if (-not $row) { continue }
        try {
            $si = Get-PnPListItem -List $pair.Source.Id -Id ([int]$r.SourceId) -Connection $script:Mig.Src
            $ti = $pair.Target.GetItemById([int]$row.TargetId)
            foreach ($name in ($r.Fields -split ';')) {
                $d = Get-MigratableFields $pair | Where-Object Name -EQ $name
                if (-not $d) { continue }
                $c = ConvertTo-TargetValue -Desc $d -Value $si[$name] -Pair $pair
                if ($c.Deferred) { Write-MigLog "[list '$($pair.Title)'] item $($r.SourceId): '$name' references items that were not migrated" WARN }
                Set-TargetFieldValue -Item $ti -Desc $d -Value $c.Value
            }
            $sys = Get-SystemValues -Values @{ Modified = $si['Modified']; Editor = $si['Editor'] }
            foreach ($k in $sys.Keys) { $ti[$k] = $sys[$k] }
            $ti.UpdateOverwriteVersion()
            Invoke-MigQuery $pair.Target.Context
        }
        catch { Write-MigLog "[list '$($pair.Title)'] lookup fix-up for item $($r.SourceId) failed: $($_.Exception.Message)" ERROR }
    }
    Move-Item $path (Get-StatePath "deferred-lookups.done-$(Get-Date -Format 'yyyyMMdd-HHmmss')")
}

# Lists that are lookup targets go first so fewer lookups need deferring.
function Get-ListOrderByLookups {
    param($Pairs)
    $deps = @{}
    foreach ($p in $Pairs) {
        $deps[$p.Source.Id.ToString()] = @(Get-MigratableFields $p | Where-Object { $_.LookupList -and $_.LookupList -ne $p.Source.Id.ToString() } | ForEach-Object LookupList)
    }
    $done = [ordered]@{}
    $visit = $null
    $visit = {
        param($id, $stack)
        if ($done.Contains($id) -or $id -in $stack -or -not $deps.ContainsKey($id)) { return }
        foreach ($d in $deps[$id]) { & $visit $d (@($stack) + $id) }
        $done[$id] = $true
    }
    foreach ($p in $Pairs) { & $visit $p.Source.Id.ToString() @() }
    @($done.Keys | ForEach-Object { $script:Mig.Pairs[$_] })
}

function Copy-ListData {
    param($Pair)
    $label = "list '$($Pair.Title)'"
    if (-not $Pair.CtMap) { [void](Get-ContentTypeMap $Pair) }
    $map = Get-ItemMap $Pair.Source.Id
    Write-MigLog "[$label] reading source items"
    $items = @(Get-PnPListItem -List $Pair.Source.Id -PageSize $script:Mig.Config.PageSize -Connection $script:Mig.Src)
    $folders = @($items | Where-Object { "$($_['FSObjType'])" -eq '1' } | Sort-Object { ("$($_['FileRef'])" -split '/').Count })
    $entries = @($items | Where-Object { "$($_['FSObjType'])" -ne '1' } | Sort-Object { [int]$_.Id })
    Write-MigLog "[$label] $($folders.Count) folder(s), $($entries.Count) item(s)"

    $all = @($folders) + @($entries)
    $n = 0
    foreach ($si in $all) {
        $n++
        Write-Progress -Activity "Migrating $($Pair.Title)" -Status "$n / $($all.Count)" -PercentComplete ($n * 100 / [math]::Max(1, $all.Count))
        $action = Get-ItemAction -Map $map -SourceItem $si
        if ($action -eq 'Skip') { $script:Mig.Stats.Skipped++; continue }
        try {
            if ("$($si['FSObjType'])" -eq '1') { Copy-FolderItem -Pair $Pair -SourceItem $si -Action $action }
            elseif ($Pair.IsLibrary) { Copy-LibraryFile -Pair $Pair -SourceItem $si -Action $action }
            else { Copy-ListItemWithVersions -Pair $Pair -SourceItem $si -Action $action }
            if ($action -eq 'Create') { $script:Mig.Stats.Created++ } else { $script:Mig.Stats.Updated++ }
        }
        catch {
            Write-MigLog "[$label] item $($si.Id) ($($si['FileRef'])) failed: $($_.Exception.Message)" ERROR
            Add-MigReport -List $Pair.Title -Object 'Item' -SourceId $si.Id -Action $action -Status Error -Message $_.Exception.Message
        }
    }
    Write-Progress -Activity "Migrating $($Pair.Title)" -Completed
    Write-MigLog "[$label] data copied" OK
}

function Invoke-DataPhase {
    param($Pairs)
    Write-MigLog '===== DATA PHASE ====='
    $missing = @($Pairs | Where-Object { -not $_.Target })
    foreach ($p in $missing) { Write-MigLog "[list '$($p.Title)'] does not exist in Site B; run the Schema phase first" ERROR }
    $ready = @($Pairs | Where-Object Target)
    foreach ($p in (Get-ListOrderByLookups $ready)) { Copy-ListData $p }
    Complete-DeferredLookups
    Write-MigLog 'Data phase complete' OK
}
