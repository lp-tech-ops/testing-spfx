# Resolves people and groups from Site A to principal IDs in Site B.
# Order: UserMapping.csv -> same login/group name in target -> FallbackUser -> empty.

function Initialize-UserResolver {
    $c = $script:Mig.Config
    $script:Mig.UserCache     = @{}   # source principal id -> target principal id (or $null)
    $script:Mig.SrcPrincipals = @{}   # source principal id -> principal info
    $script:Mig.UserMapping   = @{}
    $script:Mig.UnresolvedFile = Join-Path $script:Mig.ReportDir 'unresolved-principals.csv'

    if ($c.UserMappingCsv -and (Test-Path $c.UserMappingCsv)) {
        foreach ($r in Import-Csv $c.UserMappingCsv) {
            if ($r.Source -and $r.Target -and -not $r.Source.StartsWith('#')) {
                $script:Mig.UserMapping[$r.Source.Trim().ToLowerInvariant()] = $r.Target.Trim()
            }
        }
        Write-MigLog "Loaded $($script:Mig.UserMapping.Count) user mapping(s) from $($c.UserMappingCsv)"
    }

    $script:Mig.FallbackId = $null
    if ($c.FallbackUser) {
        $script:Mig.FallbackId = Resolve-TargetPrincipal $c.FallbackUser
        if (-not $script:Mig.FallbackId) { throw "Fallback user '$($c.FallbackUser)' could not be resolved in the target site." }
        Write-MigLog "Fallback principal '$($c.FallbackUser)' resolved to id $($script:Mig.FallbackId)"
    }
}

function Get-SourcePrincipal {
    param([int]$Id)
    if ($script:Mig.SrcPrincipals.ContainsKey($Id)) { return $script:Mig.SrcPrincipals[$Id] }
    $ctx = $script:Mig.SrcCtx
    $info = $null
    try {
        $u = $ctx.Web.SiteUsers.GetById($Id)
        $ctx.Load($u)
        Invoke-MigQuery $ctx
        $info = [pscustomobject]@{ Id = $Id; LoginName = $u.LoginName; Email = $u.Email; Title = $u.Title; IsGroup = $false }
    }
    catch {
        try {
            $g = $ctx.Web.SiteGroups.GetById($Id)
            $ctx.Load($g)
            Invoke-MigQuery $ctx
            $info = [pscustomobject]@{ Id = $Id; LoginName = $g.LoginName; Email = ''; Title = $g.Title; IsGroup = $true }
        }
        catch { }
    }
    $script:Mig.SrcPrincipals[$Id] = $info
    $info
}

function Find-UserMapping {
    param($Principal)
    $keys = @()
    if ($Principal.IsGroup) { $keys += "group:$($Principal.Title)" }
    else {
        $keys += $Principal.LoginName
        if ($Principal.LoginName -match '\|([^|]+)$') { $keys += $Matches[1] }
        $keys += $Principal.Email
    }
    $keys += $Principal.Title
    foreach ($k in $keys) {
        if (-not $k) { continue }
        $hit = $script:Mig.UserMapping[$k.ToLowerInvariant()]
        if ($hit) { return $hit }
    }
    $null
}

function Resolve-TargetPrincipal {
    # Accepts a login/UPN/email, or "group:<SharePoint group name>".
    param([string]$Value)
    $ctx = $script:Mig.TgtCtx
    try {
        if ($Value -like 'group:*') {
            $p = $ctx.Web.SiteGroups.GetByName($Value.Substring(6))
        }
        else {
            $p = $ctx.Web.EnsureUser($Value)
        }
        $ctx.Load($p)
        Invoke-MigQuery $ctx
        return $p.Id
    }
    catch { return $null }
}

# Returns the target principal id for a source principal id (cached).
function Resolve-PrincipalId {
    param([int]$SourceId)
    if ($script:Mig.UserCache.ContainsKey($SourceId)) { return $script:Mig.UserCache[$SourceId] }

    $p = Get-SourcePrincipal $SourceId
    $target = $null
    if ($p) {
        $mapped = Find-UserMapping $p
        if ($mapped) { $target = Resolve-TargetPrincipal $mapped }
        elseif ($p.IsGroup) { $target = Resolve-TargetPrincipal "group:$($p.Title)" }
        else { $target = Resolve-TargetPrincipal $p.LoginName }
    }

    if (-not $target) {
        $target = $script:Mig.FallbackId
        $name = if ($p) { "$($p.Title) <$($p.LoginName)>" } else { "principal id $SourceId (not found in Site A)" }
        $to = if ($target) { "fallback '$($script:Mig.Config.FallbackUser)'" } else { 'empty value' }
        Write-MigLog "Unresolved principal $name -> $to" WARN
        [pscustomobject]@{
            SourceId = $SourceId; Title = $p.Title; LoginName = $p.LoginName; Email = $p.Email
            IsGroup = $p.IsGroup; UsedInstead = $to
        } | Export-Csv -Path $script:Mig.UnresolvedFile -Append -NoTypeInformation -Encoding utf8
    }
    $script:Mig.UserCache[$SourceId] = $target
    $target
}
