# Document library files: every version is uploaded in order, then stamped with that
# version's metadata (values, Created/Author/Modified/Editor) via UpdateOverwriteVersion.

function Get-SnapshotContent {
    param($Snapshot, $SourceFile, [byte[]]$Previous)
    $ctx = $SourceFile.Context
    $stream = $null
    if ($Snapshot.FileVersion) { $stream = $Snapshot.FileVersion.OpenBinaryStream() }
    elseif ($Snapshot.IsCurrent -or -not $Previous) { $stream = $SourceFile.OpenBinaryStream() }
    if (-not $stream) { return $Previous }   # metadata-only version: reuse previous content
    Invoke-MigQuery $ctx
    (Read-ClientStream $stream).ToArray()
}

function Copy-LibraryFile {
    param($Pair, $SourceItem, [string]$Action)
    $tctx = $Pair.Target.Context
    $srcId = [int]$SourceItem.Id
    $row = (Get-ItemMap $Pair.Source.Id)[$srcId]
    $label = "list '$($Pair.Title)'"

    $snaps = switch ($Action) {
        'Create' { Get-SourceSnapshots -Pair $Pair -SourceItem $SourceItem }
        'Delta' { Get-SourceSnapshots -Pair $Pair -SourceItem $SourceItem -AfterVersion $row.SourceVersion }
        'Refresh' { Get-SourceSnapshots -Pair $Pair -SourceItem $SourceItem -CurrentOnly }
    }
    if ($Action -eq 'Delta' -and -not @($snaps).Count) {
        $snaps = Get-SourceSnapshots -Pair $Pair -SourceItem $SourceItem -CurrentOnly
        $Action = 'Refresh'
    }
    $ctId = Get-TargetContentTypeId $Pair $SourceItem
    $deferred = @()

    if ($Action -eq 'Refresh') {
        # Metadata only (user re-mapping, system updates): no new version.
        $ti = $Pair.Target.GetItemById([int]$row.TargetId)
        $s = @($snaps)[0]
        $sys = Get-SnapshotSystemValues -SourceItem $SourceItem -Snapshot $s -IncludeCreated
        $deferred = Set-TargetItemValues -Pair $Pair -Item $ti -Values $s.Values -System $sys -ContentTypeId $ctId
        $ti.UpdateOverwriteVersion()
        Invoke-MigQuery $tctx
        $targetId = [int]$row.TargetId
    }
    else {
        $folderUrl = Convert-ToTargetUrl $Pair $SourceItem['FileDirRef']
        $leaf = "$($SourceItem['FileLeafRef'])"
        $tFolder = $tctx.Web.GetFolderByServerRelativePath((New-ResourcePath $folderUrl))
        $srcFile = $Pair.Source.GetItemById($srcId).File
        $minorEnabled = [bool]$Pair.Target.EnableMinorVersions
        $bytes = $null

        foreach ($s in @($snaps)) {
            $bytes = Get-SnapshotContent -Snapshot $s -SourceFile $srcFile -Previous $bytes
            $p = [Microsoft.SharePoint.Client.FileCollectionAddParameters]::new()
            $p.Overwrite = $true
            $tFile = $tFolder.Files.AddUsingPath((New-ResourcePath $leaf), $p, [System.IO.MemoryStream]::new($bytes))
            $tctx.Load($tFile)
            Invoke-MigQuery $tctx

            # With minor versions on, an upload is a draft; publish to reproduce major versions (x.0).
            if ($minorEnabled -and (ConvertTo-VersionNumber $s.Label).Minor -eq 0) {
                $tFile.Publish('')
                Invoke-MigQuery $tctx
            }

            $ti = $tFile.ListItemAllFields
            $sys = Get-SnapshotSystemValues -SourceItem $SourceItem -Snapshot $s -IncludeCreated
            $d = Set-TargetItemValues -Pair $Pair -Item $ti -Values $s.Values -System $sys -ContentTypeId $ctId
            if ($s.IsCurrent) { $deferred = $d }
            $ti.UpdateOverwriteVersion()
            $tctx.Load($ti)
            Invoke-MigQuery $tctx
        }
        $targetId = $ti.Id
        Write-MigLog "[$label] $($SourceItem['FileRef']) -> $(@($snaps).Count) version(s)" DEBUG
    }

    if ($deferred) { Add-DeferredLookup -Pair $Pair -SourceId $srcId -Fields $deferred }
    Set-ItemMapEntry -SourceListId $Pair.Source.Id -SourceId $srcId -TargetId $targetId -SourceModified $SourceItem['Modified'] -SourceVersion "$($SourceItem['_UIVersionString'])"
    Add-MigReport -List $Pair.Title -Object 'File' -SourceId $srcId -TargetId $targetId -Action $Action -Status OK -Message "$($SourceItem['FileRef']) ($(@($snaps).Count) version(s))"
}
