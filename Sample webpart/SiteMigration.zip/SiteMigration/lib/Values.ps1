# Decides which columns carry data, converts source values to target values, and writes them.

# System columns that are handled explicitly (or must never be written).
$script:ValueDenyList = @(
    'ContentType', 'ContentTypeId', 'Attachments', 'FileLeafRef', 'FileRef', 'FileDirRef', 'MetaInfo',
    'Created', 'Modified', 'Author', 'Editor', '_ModerationStatus', '_ModerationComments', '_CopySource',
    'TaxCatchAll', 'TaxCatchAllLabel', 'ID', 'GUID', 'UniqueId', 'owshiddenversion', 'FSObjType', 'Order'
)
# Hidden built-in columns that still carry real data for calendar (106) lists.
$script:CalendarExtras = @('fRecurrence', 'RecurrenceData', 'EventType', 'UID', 'RecurrenceID', 'MasterSeriesItemID', 'TimeZone', 'XMLTZone', 'Duration', 'fAllDayEvent')

function Get-MigratableFields {
    param($Pair)
    if ($Pair.Fields) { return $Pair.Fields }
    $src = Get-PairFields $Pair
    $tIdx = (Get-TargetFieldIndex $Pair.Target).ByName
    $noteIds = Get-TaxonomyNoteFieldIds $src
    $isCalendar = ([int]$Pair.Source.BaseTemplate -eq 106)
    $list = @()
    foreach ($f in $src) {
        $name = $f.InternalName
        if ($name -in $script:ValueDenyList -or $noteIds.ContainsKey($f.Id.ToString())) { continue }
        if ($f.TypeAsString -in $script:SkipFieldTypes -or $f.TypeAsString -eq 'Calculated') { continue }
        $info = Get-FieldXmlInfo $f.SchemaXml
        $extra = $isCalendar -and $name -in $script:CalendarExtras
        if ($f.ReadOnlyField -and -not $extra) { continue }
        if ($f.Hidden -and $info.IsOotb -and -not $extra) { continue }
        if (-not $tIdx.ContainsKey($name)) {
            Write-MigWarnOnce "nofield|$($Pair.Title)|$name" "[list '$($Pair.Title)'] column '$name' not in Site B; its values are skipped"
            continue
        }
        $type = $f.TypeAsString
        $lookupList = $null
        if ($type -like 'Lookup*') {
            $lookupList = if ($info.List -eq 'Self' -or -not $info.List) { $Pair.Source.Id.ToString() } else { ([guid]$info.List).ToString() }
        }
        $list += [pscustomobject]@{
            Name = $name; Type = $type; TargetField = $tIdx[$name]; LookupList = $lookupList
            Multi = ($type -in 'MultiChoice', 'LookupMulti', 'UserMulti', 'TaxonomyFieldTypeMulti') -or $info.Mult
        }
    }
    $Pair.Fields = $list
    $list
}

function Get-LookupIdFromValue {
    param($Value)
    if ($null -eq $Value) { return $null }
    if ($Value -is [Microsoft.SharePoint.Client.FieldLookupValue]) { return $Value.LookupId }
    if ($Value -is [System.Collections.IDictionary]) { return [int]$Value['LookupId'] }
    if ($Value -is [int]) { return $Value }
    if ("$Value" -match '^(\d+);#') { return [int]$Matches[1] }
    $null
}

# Normalises any shape of managed metadata value into @{Label; Guid} pairs.
function ConvertTo-TermPairs {
    param($Value)
    $out = @()
    foreach ($v in @($Value)) {
        if ($null -eq $v) { continue }
        if ($v -is [Microsoft.SharePoint.Client.Taxonomy.TaxonomyFieldValueCollection]) { $out += ConvertTo-TermPairs @($v) ; continue }
        if ($v -is [Microsoft.SharePoint.Client.Taxonomy.TaxonomyFieldValue]) {
            if ($v.TermGuid) { $out += [pscustomobject]@{ Label = $v.Label; Guid = $v.TermGuid } }
            continue
        }
        if ($v -is [System.Collections.IDictionary]) {
            if ($v['TermGuid']) { $out += [pscustomobject]@{ Label = $v['Label']; Guid = $v['TermGuid'] } }
            continue
        }
        foreach ($m in [regex]::Matches("$v", '(?:-?\d+;#)?([^;#|]+)\|([0-9a-fA-F]{8}-[0-9a-fA-F-]{27})')) {
            $out += [pscustomobject]@{ Label = $m.Groups[1].Value; Guid = $m.Groups[2].Value }
        }
    }
    $out
}

# Returns @{ Value = <converted>; Deferred = <bool> }. Deferred means a lookup pointed at an
# item that has not been migrated yet; it is fixed up at the end of the data phase.
function ConvertTo-TargetValue {
    param($Desc, $Value, $Pair)
    $r = [pscustomobject]@{ Value = $null; Deferred = $false }
    if ($null -eq $Value) { return $r }

    switch -Regex ($Desc.Type) {
        '^User(Multi)?$' {
            $ids = @(foreach ($v in @($Value)) {
                    $sid = Get-LookupIdFromValue $v
                    if ($sid) { Resolve-PrincipalId $sid }
                }) | Where-Object { $_ }
            $vals = @($ids | ForEach-Object { [Microsoft.SharePoint.Client.FieldUserValue]@{ LookupId = [int]$_ } })
            if ($vals.Count) { $r.Value = if ($Desc.Multi) { [Microsoft.SharePoint.Client.FieldUserValue[]]$vals } else { $vals[0] } }
            return $r
        }
        '^Lookup(Multi)?$' {
            $lp = $script:Mig.Pairs[$Desc.LookupList]
            if (-not $lp) {
                Write-MigWarnOnce "lookup|$($Pair.Title)|$($Desc.Name)" "[list '$($Pair.Title)'] lookup '$($Desc.Name)' targets a list that is not migrated; values skipped"
                return $r
            }
            $map = Get-ItemMap ([guid]$Desc.LookupList)
            $vals = @()
            foreach ($v in @($Value)) {
                $sid = Get-LookupIdFromValue $v
                if (-not $sid) { continue }
                $row = $map[[int]$sid]
                if ($row) { $vals += [Microsoft.SharePoint.Client.FieldLookupValue]@{ LookupId = [int]$row.TargetId } }
                else { $r.Deferred = $true }
            }
            if ($vals.Count) { $r.Value = if ($Desc.Multi) { [Microsoft.SharePoint.Client.FieldLookupValue[]]$vals } else { $vals[0] } }
            return $r
        }
        '^TaxonomyFieldType' {
            $pairs = @(ConvertTo-TermPairs $Value)
            if ($pairs.Count) { $r.Value = [pscustomobject]@{ IsTaxonomy = $true; Pairs = $pairs } }
            return $r
        }
        '^MultiChoice$' {
            $r.Value = if ($Value -is [string]) { [string[]]@($Value -split ';#' | Where-Object { $_ }) } else { [string[]]@($Value) }
            return $r
        }
        '^URL$' {
            if ($Value -is [System.Collections.IDictionary]) {
                $r.Value = [Microsoft.SharePoint.Client.FieldUrlValue]@{ Url = $Value['Url']; Description = $Value['Description'] }
            }
            else { $r.Value = $Value }
            return $r
        }
        '^Integer$|^Number$' {
            # Calendar recurrence exceptions point at their series by item ID.
            if ($Desc.Name -eq 'MasterSeriesItemID') {
                $row = (Get-ItemMap $Pair.Source.Id)[[int]$Value]
                if ($row) { $r.Value = [int]$row.TargetId } else { $r.Deferred = $true }
                return $r
            }
            $r.Value = $Value
            return $r
        }
        default { $r.Value = $Value; return $r }
    }
}

function Get-TaxonomyFieldObject {
    param($Desc)
    if (-not $Desc.PSObject.Properties['TaxField']) {
        $ctx = $Desc.TargetField.Context
        $m = [Microsoft.SharePoint.Client.ClientRuntimeContext].GetMethod('CastTo').MakeGenericMethod([Microsoft.SharePoint.Client.Taxonomy.TaxonomyField])
        $Desc | Add-Member -NotePropertyName TaxField -NotePropertyValue ($m.Invoke($ctx, @($Desc.TargetField)))
    }
    $Desc.TaxField
}

# Queues the value on the target item (no ExecuteQuery here).
function Set-TargetFieldValue {
    param($Item, $Desc, $Value)
    if ($Value -and $Value.PSObject.Properties['IsTaxonomy']) {
        $tf = Get-TaxonomyFieldObject $Desc
        if ($Desc.Multi) {
            $coll = [Microsoft.SharePoint.Client.Taxonomy.TaxonomyFieldValueCollection]::new($Item.Context, $null, $tf)
            $coll.PopulateFromLabelGuidPairs((@($Value.Pairs | ForEach-Object { "$($_.Label)|$($_.Guid)" }) -join ';'))
            $tf.SetFieldValueByValueCollection($Item, $coll)
        }
        else {
            $tv = [Microsoft.SharePoint.Client.Taxonomy.TaxonomyFieldValue]::new()
            $tv.Label = $Value.Pairs[0].Label; $tv.TermGuid = $Value.Pairs[0].Guid; $tv.WssId = -1
            $tf.SetFieldValueByValue($Item, $tv)
        }
        return
    }
    $Item[$Desc.Name] = $Value
}

# Applies one snapshot of source values (a version or the current item) to a target item.
# Returns the names of lookup columns that need a later fix-up.
function Set-TargetItemValues {
    param($Pair, $Item, $Values, [hashtable]$System, [string]$ContentTypeId)
    $deferred = @()
    foreach ($d in (Get-MigratableFields $Pair)) {
        if (-not $Values.ContainsKey($d.Name)) { continue }
        $c = ConvertTo-TargetValue -Desc $d -Value $Values[$d.Name] -Pair $Pair
        if ($c.Deferred) { $deferred += $d.Name }
        try { Set-TargetFieldValue -Item $Item -Desc $d -Value $c.Value }
        catch { Write-MigWarnOnce "set|$($Pair.Title)|$($d.Name)" "[list '$($Pair.Title)'] could not set '$($d.Name)': $($_.Exception.Message)" }
    }
    if ($ContentTypeId) { $Item['ContentTypeId'] = $ContentTypeId }
    foreach ($k in $System.Keys) { if ($null -ne $System[$k]) { $Item[$k] = $System[$k] } }
    $deferred
}

# Created/Author/Modified/Editor for a snapshot (people resolved to Site B).
function Get-SystemValues {
    param($Values, [switch]$IncludeCreated)
    $sys = @{ Modified = $Values['Modified'] }
    $ed = Get-LookupIdFromValue $Values['Editor']
    if ($ed) { $id = Resolve-PrincipalId $ed; if ($id) { $sys.Editor = [Microsoft.SharePoint.Client.FieldUserValue]@{ LookupId = $id } } }
    if ($IncludeCreated) {
        $sys.Created = $Values['Created']
        $au = Get-LookupIdFromValue $Values['Author']
        if ($au) { $id = Resolve-PrincipalId $au; if ($id) { $sys.Author = [Microsoft.SharePoint.Client.FieldUserValue]@{ LookupId = $id } } }
    }
    $sys
}
