#Requires -Version 7.2
#Requires -Modules PnP.PowerShell
<#
.SYNOPSIS
    Migrates lists, libraries, site columns, content types, views, settings and data
    (with full version history) from Site A (classic subsite) to Site B (modern site). No permissions.

.EXAMPLE
    ./Start-SiteMigration.ps1 -DryRun                     # inventory only, nothing is written
    ./Start-SiteMigration.ps1                             # schema + data + finalize
    ./Start-SiteMigration.ps1 -Phase Data                 # re-run data only (delta, resumes)
    ./Start-SiteMigration.ps1 -ListUrls 'Lists/Projects'  # restrict to one list
    ./Start-SiteMigration.ps1 -Phase Data -RefreshExisting -FallbackUser someone@contoso.com
#>
[CmdletBinding()]
param(
    [string]$ConfigPath = (Join-Path $PSScriptRoot 'config/Migration.config.psd1'),

    # All = Schema, then Data, then Finalize. Phases can be run separately and repeatedly.
    [ValidateSet('All', 'Schema', 'Data', 'Finalize')]
    [string]$Phase = 'All',

    # Web-relative list URLs to restrict this run to (overrides IncludeListUrls in the config).
    [string[]]$ListUrls,

    # Writes an inventory of what would be migrated and stops.
    [switch]$DryRun,

    # Re-applies current values to already-migrated items without adding versions
    # (use after changing UserMapping.csv / FallbackUser).
    [switch]$RefreshExisting,

    # Overrides FallbackUser from the config file for this run.
    [string]$FallbackUser
)

$ErrorActionPreference = 'Stop'
foreach ($f in 'Common', 'Users', 'Discovery', 'SchemaFields', 'SchemaContentTypes', 'SchemaLists', 'Values', 'Items', 'Files') {
    . (Join-Path $PSScriptRoot "lib/$f.ps1")
}

# --- configuration -----------------------------------------------------------
$ConfigPath = (Resolve-Path $ConfigPath).Path
$config = Import-PowerShellDataFile $ConfigPath
$configDir = Split-Path $ConfigPath -Parent
foreach ($k in 'WorkFolder', 'UserMappingCsv') {
    if ($config[$k] -and -not [System.IO.Path]::IsPathRooted($config[$k])) {
        $config[$k] = [System.IO.Path]::GetFullPath((Join-Path $configDir $config[$k]))
    }
}
if ($PSBoundParameters.ContainsKey('ListUrls')) { $config.IncludeListUrls = @($ListUrls | ForEach-Object { $_.Trim('/') }) }
if ($PSBoundParameters.ContainsKey('FallbackUser')) { $config.FallbackUser = $FallbackUser }
foreach ($k in 'SourceUrl', 'TargetUrl', 'ClientId') {
    if (-not $config[$k] -or $config[$k] -match '<.+>') { throw "Set '$k' in $ConfigPath before running." }
}

$runLabel = if ($DryRun) { 'dryrun' } else { $Phase.ToLowerInvariant() }
Initialize-MigrationRuntime -Config $config -RunLabel $runLabel
$script:Mig.RefreshExisting = [bool]$RefreshExisting
$started = Get-Date
Write-MigLog "Run '$runLabel' started. Log: $($script:Mig.LogFile)"

try {
    Connect-MigrationSites

    if ($DryRun) {
        Export-Inventory (Get-SourceListSelection)
        return
    }

    $pairs = @((Get-ListPairs).Values)
    Write-MigLog "$($pairs.Count) list(s) selected: $(($pairs | ForEach-Object WebRelUrl) -join ', ')"
    Initialize-UserResolver

    if ($Phase -in 'All', 'Schema') { Invoke-SchemaPhase $pairs }
    if ($Phase -in 'All', 'Data') { Invoke-DataPhase $pairs }
    if ($Phase -in 'All', 'Finalize') { Invoke-FinalizePhase $pairs }
}
catch {
    Write-MigLog "Run aborted: $($_.Exception.Message)`n$($_.ScriptStackTrace)" ERROR
    throw
}
finally {
    $st = $script:Mig.Stats
    Write-MigLog ("Finished in {0:hh\:mm\:ss}. Created {1}, updated {2}, unchanged {3}, warnings {4}, errors {5}" -f
        ((Get-Date) - $started), $st.Created, $st.Updated, $st.Skipped, $st.Warnings, $st.Errors) OK
    if (Test-Path $script:Mig.ReportFile) { Write-MigLog "Report: $($script:Mig.ReportFile)" }
    if (Test-Path $script:Mig.ErrorFile) { Write-MigLog "Errors: $($script:Mig.ErrorFile)" WARN }
}
