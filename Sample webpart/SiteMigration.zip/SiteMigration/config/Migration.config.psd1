@{
    # ---------------------------------------------------------------------------
    # Connection (interactive sign-in with your Entra ID app registration)
    # ---------------------------------------------------------------------------
    SourceUrl = 'https://<tenant>.sharepoint.com/sites/<siteA-parent>/<siteA-subsite>'   # Site A (classic subsite)
    TargetUrl = 'https://<tenant>.sharepoint.com/sites/<siteB>'                        # Site B (modern root site)
    ClientId  = '<app-client-id-guid>'
    Tenant    = '<tenant>.onmicrosoft.com'

    # ---------------------------------------------------------------------------
    # People
    # ---------------------------------------------------------------------------
    # Used when a person/group from Site A cannot be resolved in Site B (left the
    # company, deleted group...). Leave empty ('') to blank the value instead.
    # Can be overridden per run with -FallbackUser.
    FallbackUser   = 'migration.fallback@<tenant>.onmicrosoft.com'

    # Explicit Source -> Target mappings, checked before normal resolution.
    # Relative paths are resolved against this config file's folder.
    UserMappingCsv = 'UserMapping.csv'

    # ---------------------------------------------------------------------------
    # Scope
    # ---------------------------------------------------------------------------
    # Web-relative URLs of lists to migrate. Empty = all user-created lists/libraries.
    # Example: @('Lists/Projects', 'Shared Documents')
    IncludeListUrls = @()

    # Web-relative URLs that are never migrated.
    ExcludeListUrls = @(
        'SitePages', 'Pages', 'Style Library', 'FormServerTemplates', 'SiteCollectionImages',
        'SiteCollectionDocuments', 'Lists/Workflow History', 'WorkflowTasks', 'Lists/Workflow Tasks',
        '_catalogs/masterpage', '_catalogs/wp', '_catalogs/design', '_catalogs/theme', '_catalogs/lt',
        '_catalogs/solutions', '_catalogs/wfpub', 'Lists/PublishedFeed', 'Lists/TaxonomyHiddenList'
    )

    # List template IDs that are never migrated:
    # 119 = Site Pages (wiki), 140 = Workflow History, 850 = Publishing Pages,
    # 175 = Maintenance logs, 4501 = Workflow tasks (SP2013 variant)
    ExcludeBaseTemplates = @(119, 140, 850, 175, 4501)

    # ---------------------------------------------------------------------------
    # Behaviour
    # ---------------------------------------------------------------------------
    CopyRegionalSettings = $true    # copy locale/time zone first so date-only values land on the same day
    MigrateVersions      = $true    # replay full version history for items and files
    PageSize             = 2000     # read page size (keeps queries under the 5000 list view threshold)
    MaxRetries           = 10       # CSOM retry count on throttling (429/503)

    # Working folder for state (resume/delta), logs and reports.
    # Relative paths are resolved against this config file's folder.
    WorkFolder = '..\work'

    VerboseLogging = $false
}
