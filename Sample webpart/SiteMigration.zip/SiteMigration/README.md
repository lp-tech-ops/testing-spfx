# Site A → Site B migration (PnP.PowerShell)

Copies lists and libraries from a classic subsite (Site A) to a modern site (Site B). It moves:

- **Site columns** and **content types**, keeping the same IDs, internal names and display names.
- **List columns**, including lookup, dependent lookup, calculated, managed metadata and person columns.
- **Views** and **list settings**.
- **Data**: folders, items, files, attachments and the **full version history**. Created, Created By, Modified and Modified By are kept.

Permissions, pages, workflows, InfoPath forms and JSLink are not migrated.

## Requirements

- PowerShell 7.4+ and PnP.PowerShell 2.x or 3.x (`Install-Module PnP.PowerShell -Scope CurrentUser`).
- An Entra ID app (client ID) that can sign in interactively to both sites, with full control of Site B.
- Both sites in the same tenant. Managed metadata values and people are resolved directly.

## Setup

1. Edit `config/Migration.config.psd1`: `SourceUrl`, `TargetUrl`, `ClientId`, `Tenant`, `FallbackUser`.
2. Optional: add rows to `config/UserMapping.csv`, with columns `Source` and `Target`.
   - `Source` can be a login name, UPN, email or display name.
   - For SharePoint groups, use `group:<name>` on both sides.

## Run

```powershell
./Start-SiteMigration.ps1 -DryRun          # inventory only -> work/reports/inventory-*.csv
./Start-SiteMigration.ps1                  # Schema -> Data -> Finalize
```

Phases can also be run on their own: `-Phase Schema`, `-Phase Data` and `-Phase Finalize`.

| Phase | What it does |
|---|---|
| Schema | Copies the regional settings and creates the lists. Then it handles site columns, site content types, list content types (with their order and default), list columns (display name, required, choices, validation, index), views and list settings. |
| Data | Copies folders and items (or files) in lookup-dependency order, replaying every version. Then it fixes up lookups that pointed at items not copied yet. |
| Finalize | Turns on content approval, required check-out and list validation. Then it restores the approval status of items that were not Approved. |

## Re-running, delta and resume

`work/state/items-<listId>.csv` records Source ID → Target ID, plus the last migrated source Modified time and version. On every run:

- Items that haven't changed are skipped.
- Items changed since the last run get **only their new versions** replayed.
- Items not yet migrated are created. An interrupted run picks up where it stopped.

**Changing people later:** edit `UserMapping.csv` or `FallbackUser`, then run:

```powershell
./Start-SiteMigration.ps1 -Phase Data -RefreshExisting
```

This rewrites the current values of migrated items in place and adds no versions. People who couldn't be resolved are listed in `work/reports/unresolved-principals.csv`. That file has the same shape you need for the mapping file.

**Start over:** delete Site B's lists and the `work/state` folder.

## Output

- `work/logs/*.log`: full log of the run.
- `work/reports/*-report.csv`: one row per object or item.
- `work/reports/*-errors.csv`: errors only.

## Known limitations

- **Item IDs are not kept.** Lookups are re-mapped through the state files.
- **Adding attachments creates one extra version.** That version carries the source's last editor and time.
- **Historical versions can lose lookup values.** If an item's lookup points to an item copied *later* (self-references or circular lookups), older versions keep that lookup empty. The current version is fixed up at the end.
- **Version numbers can drift.** Items in libraries without minor versions keep matching numbers. When minor versions are on, majors are reproduced by publishing.
- **Your tenant's version limits still apply.** Site B's library version limits can trim history while it is replayed, as can automatic version history limits set at tenant or site level.
- **Special lists are best effort.** Calendar recurrence, discussion boards, surveys and document sets are copied as items and folders with their content types.
- **Large files are not chunked.** Files are uploaded in one request, which suits files up to roughly 250 MB.
- **Checked-out files are copied from their last checked-in version.**
